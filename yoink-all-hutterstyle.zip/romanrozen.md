# scratch/gemma/yoink/romanrozen-pull.json v2 cells=48

<div style="background:linear-gradient(120deg,#1A73E8 0%,#6A3DE8 50%,#D93025 100%);padding:30px 32px;border-radius:16px;color:#fff">
  <div style="font-size:13px;letter-spacing:2px;opacity:.85;color:#fff">GOOGLE · THE GEMMA 4 DEVELOPER AGENT COMPETITION</div>
  <h1 style="color:#fff;margin:6px 0 4px 0;font-size:34px">🤖 Universal Starter: EDA → Localization → ADK Agent → <code style="background:rgba(255,255,255,.18);color:#fff;padding:2px 8px;border-radius:6px">submission.zip</code></h1>
  <p style="font-size:16px;margin:10px 0 0 0;color:#fff;opacity:.95">One config cell · Run-All safe · every harness fact verified against the competition files at runtime</p>
</div>

<br>

**The task in one sentence:** build a software-engineering agent on **Gemma 4** that reads a real GitHub issue, edits a Python repository inside a sandbox, and produces a patch that makes hidden tests pass. Submissions are **declarative agent bundles** (YAML + prompts, optionally adapters) rather than arbitrary code.

### ✨ What makes this starter different

| | Principle | Why it matters |
|:-:|:--|:--|
| 🔎 | **Zero hard-coded harness facts** | Tool names, model alias, context limit and bundle schema are *detected* from `HARNESS_README.md` and `sample_submission`, with the evidence shown. If the organizers change something, the notebook adapts. |
| 🛡️ | **Run-All safe** | Every section degrades gracefully. Unknown data formats produce a warning, not a crash. |
| 📐 | **Correct EDA** | A real unified-diff parser (hunk-count aware, works with or without `diff --git` headers). All takeaways are *computed*, not guessed. |
| 🎯 | **Localization baseline** | A no-LLM TF-IDF retriever measures how hard it is to find the file to fix. That is the #1 failure mode of SWE agents. |
| 🧰 | **Reusable tooling** | `edit_file` simulator with syntax checks, patch-sanity checker, tag-tolerant YAML validator, deterministic zip packaging. |
| 🚫 | **No leakage** | Reference patches are only used for analysis and are never written to any output. |

---

### 🗺️ Contents
1. [⚙️ Config](#config) : the only cell you need to edit
2. [📦 Data discovery](#discovery) : locate the data, inventory it, read the harness README
3. [🧰 Tool verification](#tools) : which agent tools really exist
4. [📊 Task EDA](#eda) : repositories, patch anatomy, difficulty, timeline
5. [🧭 Localization signals](#signals) : what the issue text tells us about *where* to edit
6. [🕸️ Code intelligence](#graphs) : call graphs & embeddings explorer
7. [🎯 Localization baseline](#baseline) : lexical retrieval Hit@k
8. [✂️ Edit mechanics & patch safety](#edit) : avoid the classic `edit_file` pitfalls
9. [🧠 Prompts & context budget](#prompts)
10. [🏗️ Agent bundle builder](#bundle) : single agent or analyzer + coder
11. [🛡️ Validator & packaging](#validate) : `submission.zip`
12. [🚀 Playbook](#playbook) : what to try next, ranked

> **Quick start:** attach the competition data → (optionally) edit `CFG` → **Run All** → download `submission.zip` from the output panel and submit it following the competition's submission instructions.

---

<a id="config"></a>
# ⚙️ 1. Config
Everything tunable lives here. `None` means *auto-detect from the competition files*.

---

```python
CFG = {
    # ── agent ──────────────────────────────────────────────────────────────
    "architecture": "analyzer+coder",   # "single" | "analyzer+coder"
    "bundle_base": "starter",           # "starter" = build from this notebook's templates
                                        # "sample"  = copy sample_submission and only swap in our prompt
    "model_alias": None,                # None → detected from sample_submission
    "fallback_model_alias": "gemma-4-31b-it-qat-w4a16-ct",
    "temperature": 0.2,
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
    "thinking_budget": 4096,
    # ── environment ────────────────────────────────────────────────────────
    "context_limit": None,              # None → detected from HARNESS_README.md
    "fallback_context_limit": 32768,
    # ── analysis ───────────────────────────────────────────────────────────
    "localization_max_tasks": 200,
    "graph_scan_max_tasks": 60,
    "time_budget_s": 240,               # soft cap per heavy analysis loop
    "seed": 42,
    # ── output ─────────────────────────────────────────────────────────────
    "bundle_dir": "submission_bundle",
    "zip_name": "submission.zip",
}
```

<a id="discovery"></a>
# 📦 2. Setup & data discovery

---

```python
import os, re, sys, json, gzip, time, html, pickle, shutil, tarfile, zipfile, hashlib, textwrap, warnings
from pathlib import Path
from collections import Counter, defaultdict
from contextlib import contextmanager
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx
import yaml
from IPython.display import display, HTML, Markdown

from pandas.io.formats.style import Styler
if not hasattr(Styler, "map"):          # pandas < 2.1 compatibility
    Styler.map = Styler.applymap

warnings.filterwarnings("ignore")
np.random.seed(CFG["seed"])
pd.set_option("display.max_colwidth", 90)

# ── visual identity ─────────────────────────────────────────────────────────
PAL = ["#4285F4", "#EA4335", "#FBBC04", "#34A853", "#A142F4", "#24C1E0", "#F538A0", "#5F6368"]
sns.set_theme(style="whitegrid", palette=PAL)
plt.rcParams.update({
    "figure.dpi": 110, "axes.titleweight": "bold", "axes.titlesize": 12, "axes.labelsize": 10,
    "axes.spines.top": False, "axes.spines.right": False, "font.family": "DejaVu Sans",
    "figure.titleweight": "bold", "figure.titlesize": 15,
})

def esc(s):
    return html.escape(str(s))

def callout(msg, kind="info"):
    bg, bd, icon = {"info": ("#E8F0FE", "#4285F4", "💡"), "ok": ("#E6F4EA", "#34A853", "✅"),
                    "warn": ("#FEF7E0", "#F9AB00", "⚠️"), "err": ("#FCE8E6", "#EA4335", "⛔")}[kind]
    display(HTML(f'<div style="background:{bg};border-left:5px solid {bd};padding:10px 14px;'
                 f'border-radius:6px;margin:6px 0;color:#202124">{icon} {msg}</div>'))

def kpis(items):
    cards = "".join(
        f'<div style="flex:1;min-width:130px;background:#fff;border:1px solid #DADCE0;border-radius:12px;'
        f'padding:10px 14px;margin:4px;box-shadow:0 1px 2px rgba(60,64,67,.15)">'
        f'<div style="font-size:12px;color:#5F6368">{esc(label)}</div>'
        f'<div style="font-size:22px;font-weight:700;color:#1A73E8">{esc(value)}</div></div>'
        for label, value in items)
    display(HTML(f'<div style="display:flex;flex-wrap:wrap;margin:4px 0 10px 0">{cards}</div>'))

def details(summary, body_html):
    display(HTML(f'<details style="margin:4px 0"><summary style="cursor:pointer;font-weight:600">{esc(summary)}</summary>{body_html}</details>'))

def pre(text, max_lines=80):
    lines = str(text).splitlines()
    more = f"\n… ({len(lines) - max_lines} more lines)" if len(lines) > max_lines else ""
    return ('<pre
```

### 🔎 Locating the competition data
No hard-coded personal paths: we check the standard Kaggle mount points, then search `/kaggle/input` for `tasks.jsonl`. You can also set `GEMMA_AGENT_DATA=/path/to/data` to run this notebook locally.

---

```python
def limited_walk(root, max_depth):
    root = Path(root)
    if not root.exists():
        return
    stack = [(root, 0)]
    while stack:
        d, depth = stack.pop()
        try:
            entries = sorted(os.scandir(d), key=lambda e: e.name)
        except (PermissionError, FileNotFoundError, NotADirectoryError):
            continue
        for e in entries:
            yield Path(e.path)
            if e.is_dir(follow_symlinks=False) and depth < max_depth:
                stack.append((Path(e.path), depth + 1))

def find_data_dir():
    candidates = [Path(os.environ["GEMMA_AGENT_DATA"])] if os.environ.get("GEMMA_AGENT_DATA") else []
    candidates += [Path("/kaggle/input/competitions/gemma-4-developer-agent"),
                   Path("/kaggle/input/gemma-4-developer-agent"),
                   Path("competition_data"), Path("../competition_data")]
    for c in candidates:
        if (c / "tasks.jsonl").exists():
            return c
    for root in [Path("/kaggle/input"), Path(".")]:
        for p in limited_walk(root, 3):
            if p.name == "tasks.jsonl":
                return p.parent
    return None

DATA_DIR = find_data_dir()
DEMO_MODE = DATA_DIR is None
if DEMO_MODE:
    callout("Competition data not found → running in <b>demo mode</b> on a tiny synthetic sample. "
            "Attach the competition dataset (<i>Add Input → Competitions</i>) for real results.", "warn")
else:
    callout(f"Data directory: <code>{esc(DATA_DIR)}</code>", "ok")
```

```python
def dir_stats(path, max_files=200_000):
    n, size, exts, truncated = 0, 0, Counter(), False
    for dp, _, fns in os.walk(path):
        for f in fns:
            n += 1
            try:
                size += os.path.getsize(os.path.join(dp, f))
            except OSError:
                pass
            name = f.lower()
            ext = ".tar.gz" if name.endswith(".tar.gz") else (Path(f).suffix.lower() or "(none)")
            exts[ext] += 1
            if n >= max_files:
                truncated = True
                break
        if truncated:
            break
    return n, size, exts, truncated

INVENTORY = pd.DataFrame()
if not DEMO_MODE:
    rows = []
    for e in sorted(DATA_DIR.iterdir()):
        if e.is_dir():
            n, s, exts, tr = dir_stats(e)
            kind = "📁"
        else:
            n, s, exts, tr = 1, e.stat().st_size, Counter({e.suffix or "(none)": 1}), False
            kind = "📄"
        rows.append({"": kind, "entry": e.name, "files": f"{n:,}{'+' if tr else ''}", "size": human_bytes(s),
                     "top extensions": ", ".join(f"{k} ×{v}" for k, v in exts.most_common(4))})
    INVENTORY = pd.DataFrame(rows)
    display(INVENTORY.style.hide(axis="index").set_properties(**{"text-align": "left"}))
```

### 📜 The harness README is the source of truth
We extract key facts **with the line they came from**, so you can check every claim at a glance. The full README is rendered below (collapsed).

---

```python
README_PATH = None
if not DEMO_MODE:
    README_PATH = next((p for p in [DATA_DIR / "HARNESS_README.md", *sorted(DATA_DIR.glob("*README*"))] if p.exists()), None)
README = README_PATH.read_text(encoding="utf-8", errors="replace") if README_PATH else ""

def readme_lines(pattern, max_hits=3):
    hits = []
    for line in README.splitlines():
        if re.search(pattern, line, flags=re.I) and line.strip():
            hits.append(textwrap.shorten(line.strip(), 170))
            if len(hits) >= max_hits:
                break
    return hits

def detect_context_limit(text):
    """Look for max_model_len / context-window numbers; return (value, evidence line)."""
    pats = [r"max[_ -]?model[_ -]?len\D{0,20}?(\d{1,3}(?:[,_]\d{3})+|\d{4,7})",
            r"context(?:[ -]window|[ -]length|[ -]limit|[ -]ceiling)?\D{0,40}?(\d{1,3}(?:[,_]\d{3})+|\d{4,7})\s*(?:tokens)?"]
    for pat in pats:
        for line in text.splitlines():
            m = re.search(pat, line, flags=re.I)
            if m:
                v = int(re.sub(r"[,_]", "", m.group(1)))
                if 2048 <= v <= 2_000_000:
                    return v, line.strip()
    return None, None

ctx_value, ctx_evidence = detect_context_limit(README)
CONTEXT_LIMIT = CFG["context_limit"] or ctx_value or CFG["fallback_context_limit"]
ctx_source = "CFG override" if CFG["context_limit"] else ("HARNESS_README.md" if ctx_value else "fallback (not found in README)")

facts = []
for topic, pat in [("Context / tokens", r"max_model_len|context|token"), ("Turn / call budget", r"turn|budget|max[_ ]?calls?"),
                   ("Time limits", r"timeout|wall|second|minute"), ("Hardware", r"\bGPU|L4|A100|H100|TPU|vLLM"),
                   ("Submission rules", r"submission|archive|\.zip|extension|adapter|LoRA"),
                   ("Scoring", r"score|metric|pass|resolved|pytest")]:
    for line in readme_lines(pat):
        facts.append({"topic": topic, "evidence (README line)": line})

if README:
    callout(f"Context limit used by this notebook: <b>{CONTEXT_LIMIT:,} tokens</b> (source: {esc(ctx_source)})"
            + (f"<br><small>evidence: <code>{esc(ctx_evidence)}</code></small>" if ctx_evidence else ""), "info")
    if facts:
        display(pd.DataFrame(facts).style.hide(axis="index").set_properties(**{"text-align": "left"}))
    details(f"📖 Show full {README_PATH.name} ({len(README.splitlines())} lines)", pre(README, max_lines=400))
else:
    callout(f"No harness README found. Using fallback context limit 
```

<a id="tools"></a>
# 🧰 3. Tool verification
Community notebooks list up to nine sandbox tools. Rather than trusting any list (including this one), we **grep the harness files** for each tool name. The agent bundle built later only uses tools that were actually found, so a typo or a renamed tool cannot silently break your submission.

---

```python
EXPECTED_TOOLS = {
    "run_command": "execution", "submit_patch": "execution", "get_status": "execution",
    "read_file": "filesystem", "edit_file": "filesystem", "write_file": "filesystem",
    "search_similar_code": "code intelligence", "get_code_neighbors": "code intelligence",
    "get_code_subgraph": "code intelligence",
}
TEXT_EXTS = {".py", ".md", ".txt", ".yaml", ".yml", ".json", ".toml", ".cfg", ".sh", ".ini"}

def text_corpus(dirs, max_file_bytes=2_000_000, max_files=4000):
    chunks, n = [], 0
    for d in dirs:
        if not d or not Path(d).exists():
            continue
        for p in limited_walk(d, 6):
            if p.is_file() and p.suffix.lower() in TEXT_EXTS:
                try:
                    if p.stat().st_size <= max_file_bytes:
                        chunks.append(p.read_text(encoding="utf-8", errors="ignore"))
                        n += 1
                except OSError:
                    pass
            if n >= max_files:
                break
    return "\n".join(chunks)

HARNESS_DIRS = [] if DEMO_MODE else [DATA_DIR / d for d in ("sandbox", "docker")]
SAMPLE_DIRS = [] if DEMO_MODE else [p for p in DATA_DIR.iterdir() if "sample" in p.name.lower() and p.is_dir()]
corpus_harness = text_corpus(HARNESS_DIRS)
corpus_sample = text_corpus(SAMPLE_DIRS)

rows = []
for tool, cat in EXPECTED_TOOLS.items():
    pat = re.compile(r"\b" + re.escape(tool) + r"\b")
    r, h, s = bool(pat.search(README)), bool(pat.search(corpus_harness)), bool(pat.search(corpus_sample))
    rows.append({"tool": tool, "category": cat, "README": "✅" if r else "—", "harness sources": "✅" if h else "—",
                 "sample submission": "✅" if s else "—", "verified": r or h or s})
TOOLS_DF = pd.DataFrame(rows)

have_evidence = bool(README or corpus_harness or corpus_sample)
AVAILABLE_TOOLS = [t for t in EXPECTED_TOOLS if TOOLS_DF.set_index("tool").loc[t, "verified"]] if have_evidence else list(EXPECTED_TOOLS)

def _style_verified(v):
    return "background-color:#E6F4EA;color:#137333;font-weight:600" if v is True else (
           "background-color:#FCE8E6;color:#C5221F;font-weight:600" if v is False else "")
display(TOOLS_DF.style.hide(axis="index").map(_style_verified, subset=["verified"]))

other = sorted(set(re.findall(r"`([a-z_][a-z0-9_]{2,})\(", README)) - set(EXPECTED_TOOLS))
if other:
    callout("Other callables mentioned in the README (review, some may be tools): "
            + ", ".join(f"<code>{esc(o)}</code>" for o in other), "info")
```

<a id="eda"></a>
# 📊 4. Task EDA
### Loading `tasks.jsonl` and its schema

---

```python
DEMO_TASKS = [
    {"instance_id": "demo_1", "repo": "demo/pkg", "base_commit": "0" * 40,
     "problem_statement": "`parse_query` crashes on empty input.\n\nTraceback (most recent call last):\nValueError",
     "hints_text": "", "created_at": "2026-05-01T00:00:00Z",
     "patch": "--- a/pkg/query.py\n+++ b/pkg/query.py\n@@ -1,3 +1,5 @@ def parse_query(s):\n     x = 1\n+    if not s:\n+        return {}\n     y = 2\n     z = 3\n",
     "test_patch": "--- a/tests/test_query.py\n+++ b/tests/test_query.py\n@@ -1,1 +1,3 @@\n import pkg\n+def test_empty():\n+    assert pkg.parse_query('') == {}\n"},
    {"instance_id": "demo_2", "repo": "demo/pkg", "base_commit": "1" * 40,
     "problem_statement": "Headers with underscores are silently accepted.", "hints_text": "see headers.py",
     "created_at": "2026-06-01T00:00:00Z",
     "patch": "diff --git a/pkg/headers.py b/pkg/headers.py\n--- a/pkg/headers.py\n+++ b/pkg/headers.py\n@@ -10,2 +10,2 @@ class Headers:\n-    allow = True\n+    allow = False\n     pass\n",
     "test_patch": ""},
]

if not DEMO_MODE:
    df = pd.read_json(DATA_DIR / "tasks.jsonl", lines=True, dtype=False)
else:
    df = pd.DataFrame(DEMO_TASKS)

# normalise the columns this notebook relies on
if "instance_id" not in df.columns:
    df["instance_id"] = df["id"] if "id" in df.columns else [f"task_{i}" for i in range(len(df))]
for col in ["problem_statement", "hints_text", "patch", "test_patch", "base_commit"]:
    if col not in df.columns:
        df[col] = ""
    df[col] = df[col].fillna("").astype(str)
if "repo" not in df.columns:
    df["repo"] = df["instance_id"].str.rsplit("_", n=1).str[0]
df["created_at"] = pd.to_datetime(df.get("created_at"), errors="coerce", utc=True)

def schema_table(frame):
    rows = []
    for c in frame.columns:
        s = frame[c]
        filled = s.notna() & s.astype(str).str.strip().ne("") & s.astype(str).ne("NaT")
        example = next((v for v in s if isinstance(v, str) and v.strip()), s.iloc[0] if len(s) else "")
        rows.append({"column": c, "dtype": str(s.dtype), "filled %": round(100 * filled.mean(), 1),
                     "unique": s.astype(str).nunique(),
                     "example": textwrap.shorten(str(example).replace("\n", " ⏎ "), 80)})
    return pd.DataFrame(rows)

print(f"{len(df)} tasks · {df['repo'].nunique()} repositories · {len(df.columns)} columns")
display(schema_table(df).style.hide(axis="index")
        .bar(subset=["filled %"], color="#AECBFA", vmin=0, vmax=100).format({"fil
```

### 🔬 A real unified-diff parser
The reference patches use plain `--- a/` / `+++ b/` headers, **often without** a `diff --git` line. Counting `diff --git` lines therefore reports "1 file" for every task. The parser below tracks hunk line counts, so it handles both styles and also catches malformed patches. That last part is useful later for checking your agent's output.

---

```python
HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(.*)$")
SYMBOL_RE = re.compile(r"(?:async\s+)?(?:def|class)\s+([A-Za-z_]\w*)")

def _clean_path(p):
    p = p.split("\t")[0].strip()
    return p[2:] if p.startswith(("a/", "b/")) else p

def parse_patch(text):
    """Return {'files': [...], 'malformed': int, 'unterminated': bool}. Each file: path, added, deleted, hunks, symbols, status."""
    files, cur, old_path = [], None, None
    rem_old = rem_new = 0
    malformed = 0

    def new_file(path):
        f = {"path": path, "added": 0, "deleted": 0, "hunks": 0, "symbols": set(), "status": "modified", "_hdr": False}
        files.append(f)
        return f

    for line in (text or "").splitlines():
        if rem_old > 0 or rem_new > 0:                      # inside a hunk
            tag = line[:1]
            if tag == "+":
                cur["added"] += 1; rem_new -= 1
                m = SYMBOL_RE.match(line[1:].strip());  m and cur["symbols"].add(m.group(1))
                continue
            if tag == "-":
                cur["deleted"] += 1; rem_old -= 1
                m = SYMBOL_RE.match(line[1:].strip());  m and cur["symbols"].add(m.group(1))
                continue
            if tag == " " or line == "":
                rem_old -= 1; rem_new -= 1
                continue
            if tag == "\\":
                continue
            malformed += 1
            rem_old = rem_new = 0                            # fall through: treat as header
        if line.startswith("\\"):
            continue
        if line.startswith("diff --git "):
            m = re.match(r"diff --git a/(\S+) b/(\S+)", line)
            cur = new_file(m.group(2) if m else line[11:].strip())
            continue
        if line.startswith("--- "):
            old_path = _clean_path(line[4:])
            continue
        if line.startswith("+++ "):
            new_path = _clean_path(line[4:])
            if cur is None or cur["_hdr"]:
                cur = new_file(new_path)
            cur["_hdr"] = True
            if new_path == "/dev/null":
                cur["path"], cur["status"] = old_path, "deleted"
            else:
                cur["path"] = new_path
                if old_path == "/dev/null":
                    cur["status"] = "added"
            continue
        m = HUNK_RE.match(line)
        if m and cur is not None:
            rem_old = int(m.group(2)) if m.group(2) is not None else 1
            rem_new = int(m.group(4)) if m.group
```

```python
def task_features(row):
    p = parse_patch(row["patch"])
    src = [f for f in p["files"] if not is_test_path(f["path"])]
    tp = parse_patch(row["test_patch"])
    new_tests = re.findall(r"^\+\s*(?:async\s+)?def\s+(test_\w+)", row["test_patch"], flags=re.M)
    added = sum(f["added"] for f in p["files"]); deleted = sum(f["deleted"] for f in p["files"])
    return pd.Series({
        "gold_files": [f["path"] for f in src],
        "gold_symbols": sorted({s for f in src for s in f["symbols"]}),
        "n_files": len(p["files"]), "n_src_files": len(src),
        "n_hunks": sum(f["hunks"] for f in p["files"]),
        "added": added, "deleted": deleted, "churn": added + deleted,
        "adds_new_file": any(f["status"] == "added" for f in p["files"]),
        "n_test_files": len(tp["files"]), "n_new_tests": len(new_tests),
        "patch_ok": (not p["malformed"]) and (not p["unterminated"]) and bool(p["files"]),
    })

feat = df.apply(task_features, axis=1)
df = pd.concat([df.drop(columns=[c for c in feat.columns if c in df.columns]), feat], axis=1)

df["problem_words"] = df["problem_statement"].str.split().str.len().fillna(0).astype(int)
df["has_hints"] = df["hints_text"].str.strip().ne("")
BINS, LABELS = [-1, 5, 20, 80, 300, np.inf], ["XS (≤5)", "S (≤20)", "M (≤80)", "L (≤300)", "XL (>300)"]
df["size_bucket"] = pd.cut(df["churn"], bins=BINS, labels=LABELS)

for col in ["FAIL_TO_PASS", "PASS_TO_PASS"]:           # present in some SWE-bench style dumps
    if col in df.columns:
        df[f"n_{col.lower()}"] = df[col].apply(lambda v: len(json.loads(v)) if isinstance(v, str) and v.startswith("[") else (len(v) if isinstance(v, list) else np.nan))

span = (f"{df['created_at'].min():%Y-%m} → {df['created_at'].max():%Y-%m}" if df["created_at"].notna().any() else "n/a")
kpis([("Tasks", f"{len(df):,}"), ("Repositories", df["repo"].nunique()),
      ("Median churn (lines)", int(df["churn"].median())), ("Single-file fixes", f"{(df['n_src_files'] == 1).mean():.0%}"),
      ("With hints", f"{df['has_hints'].mean():.0%}"), ("Adds new tests", f"{(df['n_new_tests'] > 0).mean():.0%}"),
      ("Well-formed patches", f"{df['patch_ok'].mean():.0%}"), ("Created", span)])
```

### 🎨 The benchmark at a glance

---

```python
with safe("EDA dashboard"):
    repo_order = df["repo"].value_counts().index.tolist()
    rc = {r: PAL[i % len(PAL)] for i, r in enumerate(repo_order)}
    fig, ax = plt.subplots(2, 3, figsize=(18, 9.5))
    fig.suptitle("Gemma 4 Developer Agent: benchmark anatomy", y=1.0)

    # (a) tasks per repo
    vc = df["repo"].value_counts()
    a = ax[0, 0]; a.barh(vc.index[::-1], vc.values[::-1], color=[rc[r] for r in vc.index[::-1]])
    for i, v in enumerate(vc.values[::-1]):
        a.text(v, i, f" {v}", va="center", fontsize=9)
    a.set_title("Tasks per repository"); a.set_xlabel("tasks")

    # (b) difficulty buckets by repo
    a = ax[0, 1]
    ct = pd.crosstab(df["repo"], df["size_bucket"]).reindex(index=repo_order[::-1], columns=LABELS, fill_value=0)
    left = np.zeros(len(ct))
    for j, lab in enumerate(LABELS):
        a.barh(ct.index, ct[lab], left=left, color=sns.color_palette("viridis", len(LABELS))[j], label=lab)
        left += ct[lab].values
    a.set_title("Patch size buckets (churn = added + deleted)"); a.legend(fontsize=8, ncol=2, loc="lower right")

    # (c) churn distribution (log)
    a = ax[0, 2]
    bins = np.logspace(0, np.log10(max(2, df["churn"].max() + 1)), 30)
    a.hist(df["churn"].clip(lower=1), bins=bins, color=PAL[0], alpha=.85, edgecolor="white")
    a.set_xscale("log"); a.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:,.0f}"))
    a.axvline(df["churn"].median(), color=PAL[1], ls="--", lw=2, label=f"median = {int(df['churn'].median())}")
    a.set_title("Reference patch churn (log scale)"); a.set_xlabel("lines changed"); a.legend()

    # (d) files & hunks
    a = ax[1, 0]
    fcount = df["n_src_files"].clip(upper=5).value_counts().sort_index()
    hcount = df["n_hunks"].clip(upper=8).value_counts().sort_index()
    x = np.arange(1, 9)
    a.bar(x - .2, [fcount.get(i, 0) for i in x], width=.4, label="source files", color=PAL[3])
    a.bar(x + .2, [hcount.get(i, 0) for i in x], width=.4, label="hunks", color=PAL[4])
    a.set_xticks(x, [str(i) if i < 8 else "8+" for i in x]); a.set_title("How spread out is a fix?")
    a.set_xlabel("count per task (files capped at 5+, hunks at 8+)"); a.legend()

    # (e) problem statement length by repo
    a = ax[1, 1]
    sns.boxplot(data=df.assign(problem_words=df["problem_words"].clip(lower=1)), y="repo", x="problem_words",
                hue="repo", order=repo_order, hue_order=repo_order, palette=rc, legend=False, ax=a, fliersize=2)
    a.set_xscale("log
```


[CAP]