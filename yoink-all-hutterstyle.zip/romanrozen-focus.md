# romanrozen EDA starter v2 cells=48

## cell[0] markdown
<div style="background:linear-gradient(120deg,#1A73E8 0%,#6A3DE8 50%,#D93025 100%);padding:30px 32px;border-radius:16px;color:#fff">
  <div style="font-size:13px;letter-spacing:2px;opacity:.85;color:#fff">GOOGLE · THE GEMMA 4 DEVELOPER AGENT COMPETITION</div>
  <h1 style="color:#fff;margin:6px 0 4px 0;font-size:34px">🤖 Universal Starter: EDA → Localization → ADK Agent → <code style="background:rgba(255,255,255,.18);color:#fff;padding:2px 8px;border-radius:6px">submission.zip</code></h1>
  <p style="font-size:16px;margin:10px 0 0 0;color:#fff;opacity:.95">One config cell · Run-All safe · every harness fact verified against the competition files at runtime</p>
</div>

<br>

**The task in one sentence:** build a software-engineering agent on **Gemma 4** that reads a real GitHub issue, edits a Python repository inside a sandbox, and produces a patch that makes hidden tests pass. Submissions are **declarative agent bundles** (YAML + prompts, optionally adapters) rather than arbitrary code.

### ✨ What makes this starter different

| | Principle | Why it matters |
|:-:|:--|:--|
| 🔎 | **Zero hard-coded harness facts** | Tool names, model alias, context limit and bundle schema are *detected* from `HARNESS_README.md` and `sample_submission`, with the evidence shown. If the organizers change something, the notebook adapts. |
| 🛡️ | **Run-All safe** | Every section degrades gracefully. Unknown data formats produce a warning, not a crash. |
| 📐 | **Correct EDA** | A real unified-diff parser (hunk-count aware, works with or without `diff --git` headers). All takeaways are *computed*, not guessed. |
| 🎯 | **Localization baseline** | A no-LLM TF-IDF retriever measures how hard it is to find the file to fix. That is the #1 failure mode of SWE agents. |
| 🧰 | **Reusable tooling** | `edit_file` simulator with syntax checks, patch-sanity checker, tag-tolerant YAML validator, deterministic zip packaging. |
| 🚫 | **No leakage** | Reference patches are only used for analysis and are never written to any output. |

---

## cell[1] markdown
### 🗺️ Contents
1. [⚙️ Config](#config) : the only cell you need to edit
2. [📦 Data discovery](#discovery) : locate the data, inventory it, read the harness README
3. [🧰 Tool verification](#tools) : which agent tools really exist
4. [📊 Task EDA](#eda) : repositories, patch anatomy, difficulty, timeline
5. [🧭 Localization signals](#signals) : what the issue text tells us about *where* to edit
6. [🕸️ Code intelligence](#graphs) : call graphs & embeddings explorer
7. [🎯 Localization baseline](#baseline) : lexical retrieval Hit@k
8. [✂️ Edit mechanics & patch safety](#edit) : avoid the classic `edit_file` pitfalls
9. [🧠 Prompts & context budget](#prompts)
10. [🏗️ Agent bundle builder](#bundle) : single agent or analyzer + coder
11. [🛡️ Validator & packaging](#validate) : `submission.zip`
12. [🚀 Playbook](#playbook) : what to try next, ranked

> **Quick start:** attach the competition data → (optionally) edit `CFG` → **Run All** → download `submission.zip` from the output panel and submit it following the competition's submission instructions.

---

## cell[20] code
with safe("EDA takeaways"):
    single = (df["n_src_files"] == 1).mean(); small = (df["churn"] <= 20).mean()
    q90 = int(df["churn"].quantile(.9)); multi_hunk = (df["n_hunks"] > 1).mean()
    top_repo = df["repo"].value_counts()
    txt = f"""
#### 📌 Computed takeaways
- **{single:.0%}** of fixes touch exactly one source file, and **{multi_hunk:.0%}** need more than one hunk. So the agent must be able to make *several coordinated edits*, not just one.
- **{small:.0%}** of reference patches change ≤ 20 lines, while the 90th percentile is **{q90} lines**. There is a long tail of larger feature-style changes.
- **{(df['n_new_tests'] > 0).mean():.0%}** of tasks add new test functions. Those hidden tests check behaviour the issue describes, so reproduce it yourself before you fix it.
- The biggest repository (`{top_repo.index[0]}`) accounts for **{top_repo.iloc[0] / len(df):.0%}** of tasks. Repo-specific prompt hints (layout, test commands) can pay off.
- **{df['adds_new_file'].mean():.0%}** of fixes create a new file, so `write_file` matters, but rarely.
"""
    display(Markdown(txt))

---

## cell[21] markdown
<a id="signals"></a>
# 🧭 5. Localization signals
An agent that edits the wrong file cannot pass. How often does the issue text itself *point at* the fix? We check, per task, whether the problem statement mentions a gold file (path or module name), a gold symbol (function/class changed by the reference patch), contains a traceback, or includes a code block.

---

## cell[31] markdown
<a id="baseline"></a>
# 🎯 7. Localization baseline: can plain retrieval find the file?
Before spending GPU time on an agent, measure the difficulty of step 1. For each task we index every non-test `.py` file of the repository snapshot with **TF-IDF over code-aware tokens** (`get_request_handler` → `get request handler`, `CamelCase` → `camel case`) and rank files against the issue text.

- **TF-IDF**: pure lexical similarity.
- **TF-IDF + mention boost**: extra score when the issue explicitly names the file/module or a symbol *defined* in the file. This is what a disciplined `grep` step gives an agent.

**Hit@k** = share of tasks where a gold source file is in the top-k. A low Hit@5 means the agent needs real exploration (graph tools, sub-agent), not just reading the top result.

---

## cell[32] code
from sklearn.feature_extraction.text import TfidfVectorizer

_ID_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]+")
_PART_RE = re.compile(r"[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+")
def code_tokens(text):
    out = []
    for tok in _ID_RE.findall(text):
        out.append(tok.lower())
        parts = [p.lower() for p in _PART_RE.findall(tok) if len(p) > 1]
        if len(parts) > 1:
            out.extend(parts)
    return out

def strip_common_prefix(files):
    keys = list(files)
    if len(keys) > 1:
        first = {k.split("/", 1)[0] for k in keys}
        if len(first) == 1 and all("/" in k for k in keys):
            return strip_common_prefix({k.split("/", 1)[1]: v for k, v in files.items()})
    return files

def read_py_files(entry, max_files=8000, max_bytes=400_000):
    files = {}
    if entry.is_dir():
        for p in entry.rglob("*.py"):
            try:
                if p.stat().st_size <= max_bytes:
                    files[str(p.relative_to(entry))] = p.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                pass
            if len(files) >= max_files:
                break
    elif zipfile.is_zipfile(entry):
        with zipfile.ZipFile(entry) as z:
            for i in z.infolist():
                if i.filename.endswith(".py") and i.file_size <= max_bytes and len(files) < max_files:
                    files[i.filename] = z.read(i).decode("utf-8", "ignore")
    elif tarfile.is_tarfile(entry):
        with tarfile.open(entry) as t:
            for m in t:
                if m.isfile() and m.name.endswith(".py") and m.size <= max_bytes and len(files) < max_files:
                    files[m.name] = t.extractfile(m).read().decode("utf-8", "ignore")
    return strip_common_prefix(files)

def resolve_snapshot(row):
    base = DATA_DIR / "snapshots" if DATA_DIR else None
    if not base or not base.exists():
        return None
    entries = [p for p in limited_walk(base, 1)]
    repo = str(row["repo"])
    for key in [row["instance_id"], str(row["base_commit"])[:12], str(row["base_commit"])[:7], repo.replace("/", "__"), repo.split("/")[-1]]:
        if key and len(key) >= 4:
            hits = [p for p in entries if key in p.name]
            if hits:
                return sorted(hits, key=lambda p: (len(p.relative_to(base).parts), len(p.name)))[0]
    return None

_DEF_RE = re.compile(r"^\s*(?:async\s+)?(?:def|class)\s+([A-Za-z_]\w*)", re.M)
_INDEX_CACHE = {}
def build_index(entry):
    if entry not in _INDEX_CACHE:
        files = {k: v for k, v in read_py_files(entry).items() if not is_test_path(k)}
        paths = sorted(files)
        if not paths:
            _INDEX_CACHE[entry] = None
        else:
            docs = [(" ".join([p.replace("/", " ")] * 3)) + "\n" + files[p][:200_000] for p in paths]
            vec = TfidfVectorizer(tokenizer=code_tokens, lowercase=False, token_pattern=None, sublinear_tf=True, max_features=300_000)
            X = vec.fit_transform(docs)
            defs = [set(_DEF_RE.findall(files[p])) for p in paths]
            _INDEX_CACHE[entry] = (paths, vec, X, defs)
        if len(_INDEX_CACHE) > 6:
            _INDEX_CACHE.pop(next(iter(_INDEX_CACHE)))
    return _INDEX_CACHE[entry]

def rank_files(index, query, boost=False):
    paths, vec, X, defs = index
    scores = (X @ vec.transform([query]).T).toarray().ravel()
    if boost:
        q = query.lower()
        q_ids = {t for t in _ID_RE.findall(query) if len(t) >= 4 and ("_" in t or any(c.isupper() for c in t[1

---

## cell[33] markdown
<a id="edit"></a>
# ✂️ 8. Edit mechanics & patch safety
### A string-replacement `edit_file`, simulated
Agents lose a lot of turns to failed or *silently broken* edits. The simulator below re-implements the common three-tier strategy (**exact → whitespace-flexible → token regex**) and, crucially, **checks that the result still parses**. It is a local model for building intuition, and the real harness implementation is authoritative.

---

## cell[37] markdown
<a id="prompts"></a>
# 🧠 9. Prompts & context budget
The prompts are **generated from `AVAILABLE_TOOLS`**, so they never reference a tool that does not exist. They encode the lessons from the sections above: grep-first localization, reproduce before fixing, whitespace-exact edits, compile checks, budget discipline, and a clean diff.

---

## cell[39] code
est_tokens = lambda s: int(len(s) / 3.6)            # rough heuristic for English + code, not a real tokenizer

with safe("context budget"):
    tool_schema_tokens = 130 * (len(AVAILABLE_TOOLS) + (1 if ARCH == "analyzer+coder" else 0))
    issue_tok = df["problem_statement"].map(est_tokens)
    scen = {"median issue": int(issue_tok.median()), "p90 issue": int(issue_tok.quantile(.9)), "max issue": int(issue_tok.max())}
    comp_names = ["system prompt", "tool schemas", "issue text", "reserved for output"]
    colors = [PAL[0], PAL[4], PAL[2], PAL[1]]
    fig, ax = plt.subplots(figsize=(14, 3.6))
    for yi, (label, itok) in enumerate(scen.items()):
        parts = [est_tokens(SYSTEM_PROMPT), tool_schema_tokens, itok, CFG["max_output_tokens"]]
        left = 0
        for name, v, c in zip(comp_names, parts, colors):
            ax.barh(yi, v, left=left, color=c, label=name if yi == 0 else None, edgecolor="white")
            left += v
        free = CONTEXT_LIMIT - left
        ax.barh(yi, max(free, 0), left=left, color="#E8EAED", label="left for the trajectory" if yi == 0 else None, edgecolor="white")
        ax.text(min(left, CONTEXT_LIMIT) + 200, yi, f"{max(free, 0):,} tok free ({max(free, 0) / CONTEXT_LIMIT:.0%})", va="center", fontsize=9)
    ax.axvline(CONTEXT_LIMIT, color="#202124", ls="--"); ax.set_yticks(range(len(scen)), list(scen))
    ax.set_xlim(0, CONTEXT_LIMIT * 1.08); ax.set_xlabel("tokens (approx.)")
    ax.set_title(f"Where does a {CONTEXT_LIMIT:,}-token context go before the first tool call?")
    ax.legend(ncol=5, loc="upper center", bbox_to_anchor=(.5, -.28), frameon=False)
    plt.tight_layout(); plt.show()
    if CFG["max_output_tokens"] > 0.35 * CONTEXT_LIMIT:
        callout(f"<code>max_output_tokens={CFG['max_output_tokens']:,}</code> reserves more than 35% of the context. "
                "Every tool result competes for the remainder, so consider lowering it.", "warn")
    callout("Each <code>read_file</code> or command output lands in this grey area. That is why the analyzer sub-agent helps: "
            "its exploration happens in <i>its own</i> context and only a short report comes back to the coder.", "info")

---

## cell[40] markdown
<a id="bundle"></a>
# 🏗️ 10. Agent bundle builder
**Step 1: learn from the official sample.** We locate `sample_submission` (as a folder or a zip), show its files, and detect the model alias, root file name and whether it uses `!include`.

---

## cell[47] markdown
<a id="playbook"></a>
# 🚀 12. Playbook: what to try next, ranked by expected value

| # | Idea | Why (evidence from this notebook) | Effort |
|:-:|:--|:--|:-:|
| 1 | **Prompt iteration with an experiment log** | Every run writes `experiment_card.json`. Change one thing at a time and keep the table below up to date. | 🟢 |
| 2 | **Grep-first localization rule** | The mention boost in §7 shows how much exact identifier search adds over fuzzy retrieval. | 🟢 |
| 3 | **Mandatory reproduce → compile → test loop** | §8 shows how edits can apply cleanly yet break the file. Many tasks add new tests (§4) that check the *described* behaviour. | 🟢 |
| 4 | **Analyzer sub-agent tuning** | §9: the coder's context fills fast. Tighten the analyzer's answer format, or give it graph tools only for vague issues. | 🟡 |
| 5 | **Repository-specific hints** | Hot files (§5) and per-repo test commands can go in a short appendix of the system prompt. Keep it small, since it costs context on every turn. | 🟡 |
| 6 | **Reviewer sub-agent** | A read-only agent that inspects `git diff` against the issue before `submit_patch`. It catches scratch files, test edits and partial fixes (see `check_patch`). | 🟡 |
| 7 | **Sampling & thinking budget sweep** | Lower temperature for editing, and a thinking budget that does not starve tool calls. Track the effect in the log. | 🟢 |
| 8 | **LoRA adapter** (if the rules allow) | Train on *trajectories* (tool calls + edits) from repositories **other** than the benchmark ones. Tuning on the 129 public tasks risks overfitting and may conflict with the rules, so check them first. | 🔴 |

#### 🧾 Experiment log template
| run | architecture | prompt sha | temp | thinking | LB score | notes |
|:--|:--|:--|:-:|:-:|:-:|:--|
| baseline | analyzer+coder | *(from card)* | 0.2 | 4096 | | |

#### 🔧 How to adapt this starter
- **Everything** is controlled from `CFG` (§1). Prompts are plain functions (`build_system_prompt`, `build_analyzer_prompt`), so edit them directly.
- New data format? Extend `to_graph`, `unpack_embeddings` or `read_py_files`. The rest of the notebook picks it up.
- Validation fails on schema? Set `CFG["bundle_base"] = "sample"` to build on top of the official sample.

---
<div style="text-align:center;padding:12px;color:#5F6368">
Thanks to the community notebooks that explored this dataset first. This starter was rebuilt from scratch with corrected diff statistics and runtime-verified harness facts.<br>
<b>If this notebook saved you time, an upvote helps others find it. Good luck on the leaderboard! 🍀</b>
</div>

---

