#!/usr/bin/env python3
"""Static compliance checker for a swegemma submission bundle (HARNESS_README.md).

Usage:
  python3 -I 50_check_submission.py BUNDLE [--kit KIT_DIR] [--run-script FILE]
      [--checklist compliance/harness_checklist.json] [--zip-out FILE]
      [--report FILE] [--no-yaml-lib] [--strict] [--summary] [--allow-dotdot]

A '..' component in an !include, config_path or skills path fails S1-2-18 (README L102 blocks
'..' traversal) unless --allow-dotdot is given, which turns it into a warning for layouts like
the kit's sample_submission (resolution of '..' inside the root is unconfirmed, ambiguity 1).

Each check id matches an item of compliance/harness_checklist.json, whose static_check
column says what is verified. Extra checks are prefixed X-. Statuses: pass, fail, warn
(recommendations, or rules the README leaves ambiguous), skip (needs runtime evidence,
or an input such as --kit / --run-script that was not given).

Prints a JSON report to stdout. Exits 1 if any check fails (with --strict, also on a warn)
and 2 on a usage error. Standard library only, plus PyYAML when importable. Without PyYAML
(or with --no-yaml-lib) a small built-in parser handles the YAML subset that submissions
use, including !include. The bundle is only read: no bundle code is imported or executed,
and Python files are compiled in memory just to check their syntax.
"""
import argparse
import ast
import hashlib
import io
import json
import os
import re
import stat as statmod
import struct
import sys
import zipfile

try:
    import yaml  # type: ignore
    HAVE_YAML = True
except Exception:  # pragma: no cover
    yaml = None
    HAVE_YAML = False

# ---------------------------------------------------------------------------------------------
# Constants straight from HARNESS_README.md (line numbers in comments)
# ---------------------------------------------------------------------------------------------
TOOLS9 = {"run_command", "read_file", "edit_file", "write_file", "get_status", "submit_patch",
          "get_code_neighbors", "search_similar_code", "get_code_subgraph"}           # L30, L373
SKILL_TOOLS = {"load_skill", "load_skill_resource", "run_skill_script",             # L353
               "list_skills", "search_skills"}  # also exposed by ADK 1.36.1 SkillToolset (verified in its source)
WRITE_TOOLS = {"edit_file", "write_file", "submit_patch"}
GRAPH_TOOLS = {"get_code_neighbors", "search_similar_code", "get_code_subgraph"}
ALIASES = {"gemma-4-31b-it-qat-w4a16-ct", "gemma-4-12b-it-qat-w4a16-ct",
           "gemma-4-e4b-it-qat-w4a16-ct", "gemma-4-e2b-it-qat-w4a16-ct"}             # L109, L181
LOCAL_ONLY = {"gemma-4-31b-it", "gemma-4-31b", "gemma-4-27b-it", "gemma-4-27b", "gemma-4-26b-a4b-it",
              "gemma-4-26b-a4b", "diffusiongemma-26b-a4b-it", "gemma-4-12b-it", "gemma-4-12b",
              "gemma-4-9b-it", "gemma-4-9b", "gemma-4-e4b-it", "gemma-4-e4b", "gemma-4-e2b-it",
              "gemma-4-e2b"}                                                         # L178, L193-L200
PROVIDER = re.compile(r"^(openai|google|hosted_vllm|custom)/")                       # L188
MODEL_RE = re.compile(r"^((openai|google|hosted_vllm|custom)/)?gemma-4-(31b|12b|e4b|e2b)-it-qat-w4a16-ct$")
ROOT_CONFIGS = ["agent.yaml", "agent.yml", "root_agent.yaml", "root_agent.yml"]      # L97
ALLOWED_EXT = {".yaml", ".yml", ".md", ".txt", ".py", ".json", ".safetensors"}       # L144
INCLUDE_EXT = {".md", ".txt", ".yaml", ".yml"}                                       # L100-L101
AGENT_CLASSES = {"LlmAgent", "SequentialAgent", "ParallelAgent", "LoopAgent"}         # L105
GCC_KEYS = {"temperature", "top_p", "top_k", "max_output_tokens", "presence_penalty", "frequency_penalty",
            "stop_sequences", "response_mime_type", "seed", "thinking_config"}       # L146
TC_KEYS = {"thinking_budget", "thinking_level", "include_thoughts"}                  # L148-L150
FORBIDDEN_GCC = {"tools", "system_instruction", "http_options", "safety_settings", "response_schema"}  # L154
EVAL_KEYS = {"timeout_seconds", "max_tool_calls", "max_time_minutes", "max_turns"}   # L98, L542-L559
WORKFLOW_KEYS = {"agent_class", "name", "description", "sub_agents", "before_agent_callback",
                 "before_agent_callbacks", "after_agent_callback", "after_agent_callbacks"}  # L121, L123
ADAPTER_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")                          # L206
IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
GET_STATUS_FIELDS = {"status", "tool_calls_used", "patch_submitted", "patch_size", "tool_calls_remaining",
                     "max_tool_calls", "time_seconds_remaining", "max_time_minutes", "agent_elapsed_seconds",
                     "max_turns", "command_timeout_seconds"}                         # L418-L433
LORA_31B_KEY = re.compile(r"^base_model\.model\.model\.language_model\.layers\.\d+\."
                          r"(self_attn\.[qkvo]_proj|mlp\.(gate|up|down)_proj)\.lora_[AB]\.weight$")
SIZE_LIMIT = 3221225472                                                              # L128, L134
YAML_LIMIT = 50 * 1024 * 1024                                                        # L137
SKILL_LIMIT = 50 * 1024 * 1024                                                       # L138
NEG = re.compile(r"\b(never|not|don't|do not|no|must not|avoid|without|instead of|forbid\w*|only)\b", re.I)
# A command counts as prohibited only when a negation cue precedes it in the same clause (or it continues a
# list that starts with a prohibited item, as in "never run git commit, git stash or git reset").
NEG_GOV = re.compile(r"\b(never|not|no|don't|do not|must not|cannot|can't|avoid|without|instead of|forbid\w*|neither|nor)\b", re.I)
CLAUSE_BREAK = re.compile(r"[;!?,]|[.:](?=\s|$)")
LIST_GAP = re.compile(r"^[\s`'\"]*(,|\bor\b|\band\b|/)[\s,`'\"]*(\bor\b|\band\b)?[\s`'\"]*$", re.I)
# LlmAgent fields (L105, L107-L119). global_instruction is named only as an include target (L100, ambiguity 7).
LLM_KEYS = {"agent_class", "name", "model", "adapter", "description", "instruction", "tools", "skills", "sub_agents",
            "output_key", "include_contents", "disallow_transfer_to_parent", "disallow_transfer_to_peers",
            "generate_content_config"}
LLM_KEYS_AMBIGUOUS = {"global_instruction"}
LOOP_KEYS = {"agent_class", "name", "description", "sub_agents", "max_iterations"}                   # L124-L125
CALLBACK_KEY = re.compile(r"^(before|after)_(agent|model|tool)_callbacks?$")                        # L69, L121, L123
KNOWN_CALLBACKS = set()  # CallbackRegistry contents are not documented (L69, ambiguity 9): any callback fails
# Documented parameter and result field names (L386-L533, L353, L418-L433) and other non-tool identifiers that
# prompts may put in backticks, so they are never mistaken for tool names.
KNOWN_NAMES = {"command", "stdout", "stderr", "exit_code", "error_type", "error_message", "details", "patch_size",
               "files_changed", "filepath", "start_line", "end_line", "content", "total_lines", "is_truncated",
               "old_string", "new_string", "allow_multiple", "occurrences", "strategy", "diff", "size", "node",
               "edge_type", "max_neighbors", "neighbors", "count", "query", "results", "node_name", "code",
               "similarity", "nodes", "edges", "node_count", "edge_count", "status", "error", "budget_warning",
               "skill_name", "file_path", "args", "short_options", "positional_args", "problem_description",
               "hints", "config_path", "skip_summarization", "agent_tool", "output_key", "include_contents",
               "thinking_config", "thinking_budget", "include_thoughts", "max_output_tokens"}
TOOLISH = re.compile(r"^[a-z][a-z0-9]*(?:_[a-z0-9]+)+$")  # snake_case with at least one underscore
USE_BEFORE = re.compile(r"\b(call|calls|calling|use|uses|using|via|with|invoke|invokes|run|runs|try|prefer)\s+(?:the\s+|a\s+)?$", re.I)
USE_AFTER = re.compile(r"^(\s*\(|\s+(tool|tools|function)\b|\s+to\s+[a-z]+)", re.I)
SHELL_PHRASE = re.compile(r"\bfrom the shell\b|\bin the shell\b|\bshell command", re.I)
SCRATCHY = r"[\w./-]*(?:repro|reproduce|scratch|debug)[\w-]*\.py"
SEVERITY_ORDER = {"fail": 3, "warn": 2, "pass": 1, "skip": 0}

# The 180 checklist items with a static_check (generated from compliance/harness_checklist.json).
STATIC_IDS = [
    "S1-2-01", "S1-2-02", "S1-2-04", "S1-2-09", "S1-2-12", "S1-2-13", "S1-2-14", "S1-2-15", "S1-2-16",
    "S1-2-17", "S1-2-18", "S1-2-19", "S1-2-20", "S1-2-21", "S1-2-22", "S1-2-23", "S1-2-24", "S1-2-25",
    "S1-2-26", "S1-2-27", "S1-2-28", "S1-2-29", "S1-2-30", "S1-2-31", "S1-2-32", "S1-2-33", "S1-2-34",
    "S1-2-35", "S1-2-36", "S1-2-37", "S1-2-38", "S1-2-39", "S1-2-40", "S1-2-41", "S1-2-42", "S1-2-43",
    "S1-2-45", "S1-2-46", "S1-2-47", "S1-2-48", "S1-2-49", "S1-2-50", "S1-2-51", "S1-2-52", "S1-2-53",
    "S1-2-54", "S1-2-55", "S1-2-56", "S1-2-57", "S1-2-58", "S1-2-59", "S1-2-60", "S3-5-02", "S3-5-03",
    "S3-5-04", "S3-5-05", "S3-5-06", "S3-5-07", "S3-5-08", "S3-5-09", "S3-5-10", "S3-5-11", "S3-5-12",
    "S3-5-13", "S3-5-14", "S3-5-15", "S3-5-16", "S3-5-17", "S3-5-18", "S3-5-19", "S3-5-20", "S3-5-21",
    "S3-5-22", "S3-5-23", "S3-5-24", "S3-5-27", "S3-5-30", "S3-5-31", "S3-5-32", "S3-5-33", "S3-5-35",
    "S3-5-39", "S3-5-40", "S3-5-41", "S3-5-42", "S3-5-43", "S3-5-44", "S3-5-45", "S3-5-46", "S3-5-47",
    "S3-5-48", "S3-5-49", "S3-5-50", "S3-5-51", "S3-5-52", "S3-5-54", "S3-5-55", "S3-5-56", "S3-5-57",
    "S3-5-58", "S3-5-59", "S3-5-60", "S6-7-01", "S6-7-02", "S6-7-03", "S6-7-04", "S6-7-05", "S6-7-06",
    "S6-7-07", "S6-7-08", "S6-7-09", "S6-7-10", "S6-7-11", "S6-7-12", "S6-7-13", "S6-7-14", "S6-7-15",
    "S6-7-16", "S6-7-18", "S6-7-19", "S6-7-20", "S6-7-21", "S6-7-23", "S6-7-24", "S6-7-25", "S6-7-26",
    "S6-7-27", "S6-7-29", "S6-7-31", "S6-7-32", "S6-7-33", "S6-7-34", "S6-7-35", "S6-7-36", "S6-7-38",
    "S6-7-39", "S6-7-40", "S6-7-41", "S6-7-42", "S6-7-43", "S6-7-44", "S6-7-45", "S6-7-46", "S6-7-47",
    "S6-7-48", "S6-7-50", "S6-7-52", "S6-7-53", "S6-7-54", "S8-10-02", "S8-10-03", "S8-10-04", "S8-10-05",
    "S8-10-06", "S8-10-09", "S8-10-10", "S8-10-11", "S8-10-18", "S8-10-20", "S8-10-21", "S8-10-23", "S8-10-29",
    "S8-10-30", "S8-10-32", "S8-10-33", "S8-10-34", "S8-10-37", "S8-10-39", "S8-10-46", "S8-10-47", "S8-10-48",
    "S8-10-49", "S8-10-50", "S8-10-51", "S8-10-52", "S8-10-53", "S8-10-54", "S8-10-55", "S8-10-56", "S8-10-57",
]
EXTRA_IDS = ["X-SKILL-01", "X-SKILL-02", "X-SKILL-03", "X-SKILL-04", "X-SKILL-05", "X-COVERAGE"]
IMPLEMENTED = set()  # ids that produced a result in this run


# ---------------------------------------------------------------------------------------------
# Result bookkeeping
# ---------------------------------------------------------------------------------------------
class Report:
    def __init__(self):
        self.results = {}

    def add(self, cid, status, detail):
        IMPLEMENTED.add(cid)
        entry = self.results.setdefault(cid, {"status": "skip", "details": []})
        if SEVERITY_ORDER[status] > SEVERITY_ORDER[entry["status"]]:  # worst status wins
            if status in ("fail", "warn") and entry["status"] == "pass":
                entry["details"] = []  # pass notes would bury the failure detail
            entry["status"] = status
        if status == "pass" and entry["status"] != "pass":
            detail = ""  # keep the failure details readable
        if detail and detail not in entry["details"] and len(entry["details"]) < 25:
            entry["details"].append(detail)

    def ok(self, cid, cond, fail_detail, pass_detail="", warn=False):
        if cond:
            self.add(cid, "pass", pass_detail)
        else:
            self.add(cid, "warn" if warn else "fail", fail_detail)
        return cond

    def skip(self, cid, reason):
        IMPLEMENTED.add(cid)
        entry = self.results.setdefault(cid, {"status": "skip", "details": []})
        if reason not in entry["details"]:
            entry["details"].append(reason)


# ---------------------------------------------------------------------------------------------
# YAML loading: PyYAML with an !include tag, or a small built-in parser
# ---------------------------------------------------------------------------------------------
class Include:
    def __init__(self, path):
        self.path = path

    def __repr__(self):
        return "Include(%r)" % self.path


class YamlProblem(Exception):
    pass


if HAVE_YAML:
    class IncludeLoader(yaml.SafeLoader):  # only !include is known; any other tag raises
        pass

    def _include(loader, node):
        return Include(loader.construct_scalar(node))

    IncludeLoader.add_constructor("!include", _include)


class MiniYaml:
    """Block-style YAML subset: mappings, sequences, scalars, flow lists, block scalars, !include."""

    BOOL = {"true": True, "True": True, "TRUE": True, "false": False, "False": False, "FALSE": False,
            "yes": True, "Yes": True, "no": False, "No": False, "on": True, "On": True, "off": False, "Off": False}

    def __init__(self, text):
        if "\t" in "".join(ln[: len(ln) - len(ln.lstrip(" \t"))] for ln in text.splitlines()):
            raise YamlProblem("tab indentation")
        self.lines = text.replace("\r\n", "\n").split("\n")
        self.i = 0
        self.notes = []

    def _blank(self, idx):
        stripped = self.lines[idx].strip()
        return not stripped or stripped.startswith("#") or stripped in ("---", "...")

    def skip(self):
        while self.i < len(self.lines) and self._blank(self.i):
            self.i += 1

    def indent(self, idx):
        line = self.lines[idx]
        return len(line) - len(line.lstrip(" "))

    def content(self, idx):
        return self.lines[idx].strip()

    def parse(self):
        self.skip()
        if self.i >= len(self.lines):
            return None
        value = self.block(self.indent(self.i))
        self.skip()
        if self.i < len(self.lines):
            raise YamlProblem("unexpected content at line %d: %r" % (self.i + 1, self.lines[self.i][:60]))
        return value

    def block(self, ind):
        text = self.content(self.i)
        if text == "-" or text.startswith("- "):
            return self.seq(ind)
        if self.split_key(text) is None:
            self.i += 1
            return self.scalar(text)
        return self.mapping(ind)

    @staticmethod
    def strip_comment(text):
        quote = None
        for pos, ch in enumerate(text):
            if quote:
                if ch == quote:
                    quote = None
            elif ch in "'\"" and (pos == 0 or text[pos - 1] in " :[{,"):
                quote = ch
            elif ch == "#" and (pos == 0 or text[pos - 1] == " "):
                return text[:pos].rstrip()
        return text

    @staticmethod
    def split_key(text):
        if not text or text[0] in "\"'[{!&*|>":
            if text[:1] in "\"'":
                quote = text[0]
                end = text.find(quote, 1)
                if end > 0 and text[end + 1:end + 2] == ":" and (len(text) == end + 2 or text[end + 2] == " "):
                    return text[1:end], text[end + 2:]
            return None
        for pos in range(len(text)):
            if text[pos] == ":" and (pos + 1 == len(text) or text[pos + 1] == " "):
                return text[:pos].strip(), text[pos + 1:]
            if text[pos] == "#" and pos and text[pos - 1] == " ":
                return None
        return None

    def mapping(self, ind):
        result = {}
        while True:
            self.skip()
            if self.i >= len(self.lines):
                break
            cur = self.indent(self.i)
            if cur < ind:
                break
            if cur > ind:
                raise YamlProblem("bad indentation at line %d" % (self.i + 1))
            text = self.content(self.i)
            if text == "-" or text.startswith("- "):
                break
            pair = self.split_key(text)
            if pair is None:
                raise YamlProblem("expected 'key: value' at line %d: %r" % (self.i + 1, text[:60]))
            key, rest = pair
            if key in result:
                raise YamlProblem("duplicate key %r at line %d" % (key, self.i + 1))
            self.i += 1
            result[key] = self.value(rest, ind)
        return result

    def value(self, rest, ind):
        rest = self.strip_comment(rest).strip()
        if rest == "":
            self.skip()
            if self.i < len(self.lines):
                nxt, text = self.indent(self.i), self.content(self.i)
                if nxt > ind or (nxt == ind and (text == "-" or text.startswith("- "))):
                    return self.block(nxt)
            return None
        if re.fullmatch(r"[|>][+-]?", rest):
            return self.block_scalar(rest, ind)
        return self.scalar(rest)

    def seq(self, ind):
        items = []
        while True:
            self.skip()
            if self.i >= len(self.lines):
                break
            cur, text = self.indent(self.i), self.content(self.i)
            if cur != ind or not (text == "-" or text.startswith("- ")):
                break
            rest = text[1:].lstrip(" ")
            if rest == "":
                self.i += 1
                items.append(self.value("", ind))
            elif self.split_key(self.strip_comment(rest)) is not None:
                col = cur + (len(text) - len(rest))
                self.lines[self.i] = " " * col + rest
                items.append(self.mapping(col))
            else:
                self.i += 1
                items.append(self.scalar(self.strip_comment(rest).strip()))
        return items

    def block_scalar(self, style, ind):
        raw = []
        while self.i < len(self.lines):
            line = self.lines[self.i]
            if line.strip() and self.indent(self.i) <= ind:
                break
            raw.append(line)
            self.i += 1
        while raw and not raw[-1].strip():
            raw.pop()
        body_ind = min((len(l) - len(l.lstrip(" ")) for l in raw if l.strip()), default=0)
        body = [l[body_ind:] for l in raw]
        text = "\n".join(body) if style[0] == "|" else " ".join(l.strip() for l in body if l.strip())
        if style.endswith("-"):
            return text
        return text + "\n"

    def scalar(self, text):
        text = self.strip_comment(text).strip()
        if text.startswith("!include"):
            return Include(text[len("!include"):].strip())
        if text.startswith("!"):
            raise YamlProblem("unsupported tag %r" % text.split()[0])
        if text[:1] in "&*":
            self.notes.append("anchor/alias %s" % text.split()[0])
            raise YamlProblem("anchors and aliases are not supported by the mini parser: %r" % text[:30])
        if len(text) >= 2 and text[0] == text[-1] == "'":
            return text[1:-1].replace("''", "'")
        if len(text) >= 2 and text[0] == text[-1] == '"':
            try:
                return json.loads(text)
            except ValueError:
                return text[1:-1]
        if text.startswith("[") and text.endswith("]"):
            inner = text[1:-1].strip()
            return [self.scalar(part.strip()) for part in self.split_flow(inner)] if inner else []
        if text.startswith("{") and text.endswith("}"):
            inner = text[1:-1].strip()
            out = {}
            for part in self.split_flow(inner) if inner else []:
                pair = self.split_key(part.strip())
                if pair is None:
                    raise YamlProblem("bad flow mapping %r" % text[:40])
                out[pair[0]] = self.scalar(pair[1].strip()) if pair[1].strip() else None
            return out
        if text in ("null", "Null", "NULL", "~"):
            return None
        if text in self.BOOL:
            return self.BOOL[text]
        if re.fullmatch(r"[-+]?\d+", text):
            return int(text)
        if re.fullmatch(r"[-+]?(\d+\.\d*|\.\d+|\d+)([eE][-+]?\d+)?", text):
            return float(text)
        return text

    @staticmethod
    def split_flow(text):
        parts, depth, quote, cur = [], 0, None, []
        for ch in text:
            if quote:
                cur.append(ch)
                if ch == quote:
                    quote = None
                continue
            if ch in "'\"":
                quote = ch
            elif ch in "[{":
                depth += 1
            elif ch in "]}":
                depth -= 1
            elif ch == "," and depth == 0:
                parts.append("".join(cur))
                cur = []
                continue
            cur.append(ch)
        if "".join(cur).strip():
            parts.append("".join(cur))
        return parts


def parse_yaml(text, use_lib):
    if use_lib and HAVE_YAML:
        try:
            return yaml.load(text, Loader=IncludeLoader)  # noqa: S506 (SafeLoader subclass)
        except yaml.YAMLError as exc:
            raise YamlProblem(str(exc).splitlines()[0] if str(exc) else type(exc).__name__)
    return MiniYaml(text).parse()


# ---------------------------------------------------------------------------------------------
# Bundle model
# ---------------------------------------------------------------------------------------------
class Agent:
    def __init__(self, data, src, depth, via, parent):
        self.data = data if isinstance(data, dict) else {}
        self.src, self.depth, self.via, self.parent = src, depth, via, parent
        self.name = self.data.get("name")
        self.cls = self.data.get("agent_class", "LlmAgent") or "LlmAgent"
        instr = self.data.get("instruction")
        self.instruction = instr if isinstance(instr, str) else ""
        gi = self.data.get("global_instruction")
        self.global_instruction = gi if isinstance(gi, str) else ""
        desc = self.data.get("description")
        self.description = desc if isinstance(desc, str) else ""
        tools = self.data.get("tools") or []
        self.tools = tools if isinstance(tools, list) else []
        self.str_tools = {t for t in self.tools if isinstance(t, str)}
        skills = self.data.get("skills") or []
        self.skills = skills if isinstance(skills, list) else []
        gcc = self.data.get("generate_content_config")
        self.gcc = gcc if isinstance(gcc, dict) else ({} if gcc is None else {"__invalid__": gcc})
        self.children = []  # (via, Agent)

    @property
    def is_llm(self):
        return self.cls == "LlmAgent"

    def declared(self):
        names = set(self.str_tools)
        if self.skills:
            names |= SKILL_TOOLS
        for via, child in self.children:
            if via in ("agent_tool", "inline") and child.name:
                names.add(child.name)
        if any(via == "sub_agent" for via, _ in self.children):
            names.add("transfer_to_agent")
        return names


class Bundle:
    def __init__(self, root, use_lib, report, allow_dotdot=False):
        self.root = os.path.realpath(root)
        self.use_lib = use_lib
        self.r = report
        self.allow_dotdot = allow_dotdot
        self.expanded_by_file = {}  # agent YAML rel -> bytes of its include-expanded content (S1-2-52)
        self.files = []        # relative paths of regular files
        self.symlinks = []
        self.sizes = {}
        self.yaml_cache = {}   # rel -> parsed (unexpanded) or YamlProblem
        self.include_edges = []  # (from_rel, target, resolved_rel or None)
        self.expanded_sizes = {}
        self.agents = []
        self.root_config = None
        self.agent_files = set()
        self.raw_yaml = {}

    # -- filesystem --------------------------------------------------------------------------
    def scan(self):
        for dirpath, dirnames, filenames in os.walk(self.root, followlinks=False):
            for name in list(dirnames):
                full = os.path.join(dirpath, name)
                if os.path.islink(full):
                    self.symlinks.append(os.path.relpath(full, self.root))
                    dirnames.remove(name)
            for name in filenames:
                full = os.path.join(dirpath, name)
                rel = os.path.relpath(full, self.root).replace(os.sep, "/")
                st = os.lstat(full)
                if statmod.S_ISLNK(st.st_mode):
                    self.symlinks.append(rel)
                    continue
                self.files.append(rel)
                self.sizes[rel] = st.st_size
        self.files.sort()

    def read_bytes(self, rel):
        with open(os.path.join(self.root, rel), "rb") as handle:
            return handle.read()

    def read_text(self, rel):
        return self.read_bytes(rel).decode("utf-8", errors="replace")

    def inside(self, path):
        real = os.path.realpath(path)
        return real == self.root or real.startswith(self.root + os.sep)

    # -- yaml + includes --------------------------------------------------------------------
    def load_yaml_file(self, rel):
        if rel not in self.yaml_cache:
            try:
                text = self.read_bytes(rel).decode("utf-8")
                self.raw_yaml[rel] = text
                self.yaml_cache[rel] = parse_yaml(text, self.use_lib)
            except (UnicodeDecodeError, YamlProblem) as exc:
                self.yaml_cache[rel] = YamlProblem("%s: %s" % (rel, exc))
            except Exception as exc:  # constructor errors for unknown tags, etc.
                self.yaml_cache[rel] = YamlProblem("%s: %s: %s" % (rel, type(exc).__name__, str(exc)[:200]))
        return self.yaml_cache[rel]

    def resolve_ref(self, from_rel, target, cid):
        """Resolve a relative reference from a YAML file. Returns rel path or None."""
        r = self.r
        if not isinstance(target, str) or not target.strip():
            r.add(cid, "fail", "%s: empty or non-string reference %r" % (from_rel, target))
            return None
        target = target.strip()
        if "\x00" in target or target.startswith("/") or re.match(r"^[A-Za-z]:[\\/]", target):
            r.add("S1-2-18", "fail", "%s: absolute or NUL path %r" % (from_rel, target))
            return None
        if ".." in re.split(r"[\\/]", target):
            if self.allow_dotdot:
                r.add("S1-2-18", "warn", "%s: '..' component in %r (allowed by --allow-dotdot; L102 blocks '..')" % (from_rel, target))
            else:
                r.add("S1-2-18", "fail", "%s: '..' component in %r (README L102 blocks '..' traversal components; "
                      "--allow-dotdot downgrades this until a swegemma run accepts it)" % (from_rel, target))
        base_dir = os.path.dirname(os.path.join(self.root, from_rel))
        cand_file = os.path.normpath(os.path.join(base_dir, target))
        cand_root = os.path.normpath(os.path.join(self.root, target))
        if not self.inside(cand_file):
            r.add("S1-2-18", "fail", "%s: %r resolves outside the bundle" % (from_rel, target))
            return None
        r.add("S1-2-18", "pass", "")
        exists_file, exists_root = os.path.exists(cand_file), os.path.exists(cand_root)
        if exists_file and exists_root and os.path.realpath(cand_file) != os.path.realpath(cand_root):
            r.add(cid, "warn", "%s: %r means different files relative to the file and to the root" % (from_rel, target))
        elif exists_file != exists_root and cid != "S1-2-19":
            r.add(cid, "warn", "%s: %r exists only relative to the %s (resolution base is ambiguous)" % (
                from_rel, target, "including file" if exists_file else "bundle root"))
        chosen = cand_file if exists_file else (cand_root if exists_root and cid != "S1-2-19" else None)
        if chosen is None:
            return None
        return os.path.relpath(chosen, self.root).replace(os.sep, "/")

    def expand(self, obj, from_rel, depth, stack):
        if isinstance(obj, Include):
            target = obj.path
            ext = os.path.splitext(target)[1].lower()
            rel = self.resolve_ref(from_rel, target, "S1-2-19")
            self.include_edges.append((from_rel, target, rel))
            if ext not in INCLUDE_EXT:
                self.r.add("S1-2-19", "fail", "%s: !include %r has an undocumented type" % (from_rel, target))
            if rel is None or not os.path.isfile(os.path.join(self.root, rel)):
                self.r.add("S1-2-19", "fail", "%s: !include %r not found relative to the including file" % (from_rel, target))
                return None
            self.r.add("S1-2-19", "pass", "")
            if ext in (".md", ".txt"):
                data = self.read_bytes(rel)
                problems = []
                if data.startswith(b"\xef\xbb\xbf"):
                    problems.append("BOM")
                if b"\x00" in data:
                    problems.append("NUL byte")
                try:
                    text = data.decode("utf-8", errors="strict")
                except UnicodeDecodeError as exc:
                    problems.append("invalid UTF-8 (%s)" % exc)
                    text = data.decode("utf-8", errors="replace")
                self.r.ok("S1-2-16", not problems, "%s: %s" % (rel, ", ".join(problems)))
                return text
            if ext in (".yaml", ".yml"):
                if rel in stack:
                    self.r.add("S1-2-17", "fail", "include cycle: %s" % " -> ".join(stack + [rel]))
                    return None
                if depth + 1 > 10:
                    self.r.add("S1-2-17", "fail", "include depth > 10 at %s" % rel)
                    return None
                parsed = self.load_yaml_file(rel)
                if isinstance(parsed, YamlProblem):
                    self.r.add("S1-2-01", "fail", "YAML does not load with a safe loader: %s" % parsed)
                    return None
                return self.expand(parsed, rel, depth + 1, stack + [rel])
            return None
        if isinstance(obj, dict):
            return {k: self.expand(v, from_rel, depth, stack) for k, v in obj.items()}
        if isinstance(obj, list):
            return [self.expand(v, from_rel, depth, stack) for v in obj]
        return obj

    def load_agent_file(self, rel, stack):
        parsed = self.load_yaml_file(rel)
        if isinstance(parsed, YamlProblem):
            self.r.add("S1-2-01", "fail", "YAML does not load with a safe loader: %s" % parsed)
            return None
        expanded = self.expand(parsed, rel, 0, stack + [rel])
        self.expanded_by_file[rel] = len(json.dumps(expanded, default=str).encode("utf-8"))
        return expanded

    # -- agent tree ---------------------------------------------------------------------------
    def walk(self, data, src, depth, via, parent, file_stack):
        agent = Agent(data, src, depth, via, parent)
        self.agents.append(agent)
        if len(self.agents) > 600:
            return agent
        for entry in agent.tools:
            if isinstance(entry, dict) and "agent_tool" in entry:
                cfg = entry.get("agent_tool")
                if set(entry) != {"agent_tool"} or not isinstance(cfg, dict):
                    self.r.add("S1-2-30", "fail", "%s: malformed agent_tool entry %r" % (src, entry))
                    continue
                extra = set(cfg) - {"config_path", "skip_summarization"}
                if extra:
                    self.r.add("S1-2-30", "warn", "%s: agent_tool has undocumented keys %s" % (src, sorted(extra)))
                self.r.ok("S1-2-31", cfg.get("skip_summarization") is True,
                          "%s: agent_tool %s without skip_summarization: true" % (src, cfg.get("config_path")), warn=True)
                self.r.ok("S8-10-51", cfg.get("skip_summarization") is True,
                          "%s: agent_tool %s without skip_summarization: true" % (src, cfg.get("config_path")))
                rel = self.resolve_ref(src.split("#")[0], cfg.get("config_path"), "S1-2-30")
                if rel is None or not os.path.isfile(os.path.join(self.root, rel)):
                    self.r.add("S1-2-30", "fail", "%s: agent_tool config_path %r missing" % (src, cfg.get("config_path")))
                    self.r.add("S8-10-51", "fail", "%s: agent_tool config_path %r missing" % (src, cfg.get("config_path")))
                    continue
                self.r.add("S8-10-51", "pass", "")
                if rel in file_stack:
                    self.r.add("S1-2-54", "fail", "agent cycle through %s" % rel)
                    continue
                child_data = self.load_agent_file(rel, file_stack)
                if not isinstance(child_data, dict) or "name" not in child_data:
                    self.r.add("S1-2-30", "fail", "%s does not parse as an agent config" % rel)
                    continue
                self.agent_files.add(rel)
                child = self.walk(child_data, rel, depth + 1, "agent_tool", agent, file_stack + [rel])
                agent.children.append(("agent_tool", child))
            elif isinstance(entry, dict) and "name" in entry:
                child = self.walk(entry, src + "#inline:" + str(entry.get("name")), depth + 1, "inline", agent, file_stack)
                agent.children.append(("inline", child))
            elif isinstance(entry, str):
                continue
            else:
                self.r.add("S1-2-30", "fail", "%s: tools entry %r is not a name, agent_tool or inline agent" % (src, entry))
                self.r.add("S1-2-02", "fail", "%s: tools entry %r has an unsupported form" % (src, entry))
        subs = agent.data.get("sub_agents") or []
        if not isinstance(subs, list):
            self.r.add("S1-2-33", "fail", "%s: sub_agents is not a list" % src)
            subs = []
        for entry in subs:
            if not (isinstance(entry, dict) and set(entry) == {"config_path"}):
                self.r.add("S1-2-33", "fail", "%s: sub_agents item %r is not {config_path: ...}" % (src, entry))
                continue
            rel = self.resolve_ref(src.split("#")[0], entry["config_path"], "S1-2-33")
            if rel is None or not os.path.isfile(os.path.join(self.root, rel)):
                self.r.add("S1-2-33", "fail", "%s: sub_agents config_path %r missing" % (src, entry["config_path"]))
                continue
            if rel in file_stack:
                self.r.add("S1-2-54", "fail", "agent cycle through %s" % rel)
                continue
            child_data = self.load_agent_file(rel, file_stack)
            if not isinstance(child_data, dict) or "name" not in child_data:
                self.r.add("S1-2-33", "fail", "%s does not parse as an agent config" % rel)
                continue
            self.r.add("S1-2-33", "pass", "")
            self.agent_files.add(rel)
            child = self.walk(child_data, rel, depth + 1, "sub_agent", agent, file_stack + [rel])
            agent.children.append(("sub_agent", child))
        return agent


# ---------------------------------------------------------------------------------------------
# Helpers for prompt checks
# ---------------------------------------------------------------------------------------------
def lines_matching(pattern, text, flags=re.I):
    rx = re.compile(pattern, flags)
    return [ln for ln in text.splitlines() if rx.search(ln)]


def negated(line):
    return bool(NEG.search(line))


def governed(line, start):
    """True if a negation cue precedes position `start` within the same clause of `line`."""
    head, cut = line[:start], 0
    for m in CLAUSE_BREAK.finditer(head):
        cut = m.end()
    return bool(NEG_GOV.search(head[cut:]))


def match_governance(pattern, line):
    """[(match, governed)] for every match of `pattern` in `line`.

    A match also counts as governed when it continues a list whose previous item was governed:
    'Never run git commit, git stash or git reset' prohibits all three commands."""
    out, prev_end, prev_gov = [], None, False
    for m in re.finditer(pattern, line, re.I):
        gov = governed(line, m.start()) or bool(prev_gov and prev_end is not None and LIST_GAP.match(line[prev_end:m.start()]))
        out.append((m, gov))
        prev_end, prev_gov = m.end(), gov
    return out


def ungoverned(pattern, line):
    """The first match of `pattern` in `line` that no preceding negation governs, else None."""
    for m, gov in match_governance(pattern, line):
        if not gov:
            return m
    return None


def section(text, title):
    match = re.search(r"^##\s+%s.*$" % re.escape(title), text, re.M | re.I)
    if not match:
        return ""
    rest = text[match.end():]
    nxt = re.search(r"^##\s+", rest, re.M)
    return rest[: nxt.start()] if nxt else rest


def code_spans(text):
    spans = re.findall(r"`([^`\n]+)`", text)
    for block in re.findall(r"```.*?\n(.*?)```", text, re.S):
        spans.extend(block.splitlines())
    for line in text.splitlines():
        if line.startswith("    ") and line.strip():
            spans.append(line.strip())
    return spans


def placeholders(text):
    found = []
    for match in re.finditer(r"\{+([^{}]*)\}+", text):
        inner = match.group(1).strip()
        optional = inner.endswith("?")
        name = inner[:-1].strip() if optional else inner
        if re.fullmatch(r"(?:(?:app|user|temp):)?[A-Za-z_][A-Za-z0-9_]*", name) or name.startswith("artifact."):
            found.append((name, optional, match.group(0)))
    return found


def safetensors_header(path):
    with open(path, "rb") as handle:
        head = handle.read(8)
        if len(head) < 8:
            raise ValueError("file shorter than 8 bytes")
        length = struct.unpack("<Q", head)[0]
        size = os.path.getsize(path)
        if length <= 0 or length > min(size - 8, 100 * 1024 * 1024):
            raise ValueError("implausible header length %d" % length)
        header = json.loads(handle.read(length).decode("utf-8"))
    data_size = size - 8 - length
    for key, meta in header.items():
        if key == "__metadata__":
            continue
        start, end = meta["data_offsets"]
        if not (0 <= start <= end <= data_size):
            raise ValueError("tensor %s offsets out of range" % key)
    return header


def deterministic_zip(bundle):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel in bundle.files:
            info = zipfile.ZipInfo(rel, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (0o100644 << 16)
            zf.writestr(info, bundle.read_bytes(rel))
    return buf.getvalue()


# ---------------------------------------------------------------------------------------------
# The checks
# ---------------------------------------------------------------------------------------------
def run_checks(args):
    r = Report()
    b = Bundle(args.bundle, not args.no_yaml_lib, r, allow_dotdot=getattr(args, "allow_dotdot", False))
    if not os.path.isdir(b.root):
        raise SystemExit("not a directory: %s" % args.bundle)
    b.scan()

    # ---- bundle structure -------------------------------------------------------------------
    roots = [f for f in ROOT_CONFIGS if os.path.isfile(os.path.join(b.root, f))]
    r.ok("S1-2-13", len(roots) == 1, "root configs found: %s (exactly one required)" % roots, "root config: %s" % roots)
    r.ok("S1-2-01", not any(f in b.files for f in ("agent.py", "__init__.py")),
         "agent.py or __init__.py at the bundle root")
    yaml_files = [f for f in b.files if f.endswith((".yaml", ".yml"))]
    bad_pat = re.compile(r"agent_fn|!!python|importlib|code_executor|before_model_callback:\s*\S+\.\S+")
    for rel in yaml_files:
        text = b.read_text(rel)
        hits = [ln.strip() for ln in text.splitlines() if bad_pat.search(ln) and not ln.strip().startswith("#")]
        r.ok("S1-2-01", not hits, "%s: non-declarative construct %s" % (rel, hits[:2]))
        parsed = b.load_yaml_file(rel)
        r.ok("S1-2-01", not isinstance(parsed, YamlProblem), "YAML does not load with a safe loader: %s" % parsed)
        r.ok("S1-2-52", b.sizes[rel] <= YAML_LIMIT, "%s is larger than 50 MiB" % rel)
        if re.search(r"(^|[\s\[{,:-])[&*][A-Za-z0-9_-]+\b|<<\s*:", re.sub(r"#.*", "", text)):
            r.add("S1-2-52", "warn", "%s: YAML anchors/aliases present (expansion blow-up risk)" % rel)

    bad_ext = [f for f in b.files if os.path.splitext(f)[1].lower() not in ALLOWED_EXT]
    dot = [f for f in b.files if any(p.startswith(".") for p in f.split("/"))]
    py_outside = [f for f in b.files if f.endswith(".py") and not f.startswith("skills/")]
    r.ok("S1-2-57", not bad_ext, "disallowed extensions (L144): %s" % bad_ext[:10])
    r.ok("S1-2-57", not dot, "dotfiles or files in dot-directories: %s" % dot[:10])
    r.ok("S1-2-57", not py_outside, ".py outside skills/: %s" % py_outside[:10])
    r.ok("S1-2-20", not b.symlinks, "symlinks present: %s" % b.symlinks[:10], "no symlinks")
    total = sum(b.sizes.values())
    r.ok("S1-2-49", total < SIZE_LIMIT, "total unpacked size %d >= 3 GiB" % total, "total unpacked size %d bytes" % total)
    r.ok("S3-5-19", total < SIZE_LIMIT, "total unpacked size %d >= 3 GiB" % total, "total %d bytes" % total)
    r.ok("S1-2-50", len(b.files) <= 10000, "%d files > 10,000" % len(b.files), "%d files" % len(b.files))
    r.ok("S1-2-51", len(yaml_files) <= 1000, "%d YAML files > 1,000" % len(yaml_files), "%d YAML files" % len(yaml_files))

    # ---- zip-level checks on a deterministic archive of the tree ------------------------------
    blob = deterministic_zip(b)
    with zipfile.ZipFile(io.BytesIO(blob)) as zf:
        names = zf.namelist()
        roots_in_zip = [n for n in names if n in ROOT_CONFIGS]
        tops = {n.split("/")[0] for n in names}
        r.ok("S1-2-12", len(roots_in_zip) == 1 and not (len(tops) == 1 and "/" in names[0]),
             "zip root has %s; top-level entries %s" % (roots_in_zip, sorted(tops)[:5]), "agent config at zip root")
        modes = [i.filename for i in zf.infolist() if ((i.external_attr >> 16) & 0o170000) == 0o120000]
        r.ok("S1-2-20", not modes, "symlink entries in zip: %s" % modes)
        zsize = sum(i.file_size for i in zf.infolist())
        r.ok("S1-2-49", zsize < SIZE_LIMIT, "zip unpacked size %d >= 3 GiB" % zsize)
        mismatch = [n for n in names if hashlib.sha256(zf.read(n)).hexdigest() != hashlib.sha256(b.read_bytes(n)).hexdigest()]
        r.ok("S8-10-29", not mismatch and set(names) == set(b.files),
             "zip and tree differ: %s" % mismatch[:5],
             "zip entries match the tree (sha256 of %d files; archive sha256 %s)" % (len(names), hashlib.sha256(blob).hexdigest()[:16]))
    if args.zip_out:
        with open(args.zip_out, "wb") as handle:
            handle.write(blob)

    if len(roots) != 1:
        return r, b
    b.root_config = roots[0]

    # ---- agent tree -------------------------------------------------------------------------
    root_data = b.load_agent_file(b.root_config, [])
    if not isinstance(root_data, dict):
        r.add("S1-2-01", "fail", "root config does not parse to a mapping")
        return r, b
    b.agent_files.add(b.root_config)
    b.walk(root_data, b.root_config, 0, "root", None, [b.root_config])
    root = b.agents[0]
    agents = b.agents
    llm = [a for a in agents if a.is_llm]
    r.ok("S1-2-53", len(agents) <= 500, "%d agents > 500" % len(agents), "%d agent(s)" % len(agents))
    r.ok("S1-2-54", max(a.depth for a in agents) <= 50, "agent depth > 50", "max depth %d" % max(a.depth for a in agents))

    # include graph depth/cycles (also recorded during expansion)
    r.add("S1-2-17", "pass", "%d include edge(s), no cycle, depth <= 10" % len(b.include_edges))
    for frm, target, rel in b.include_edges:
        r.add("S1-2-18", "pass", "")
    # L137: 50 MiB per YAML file and for the cumulative !include expansion. Every loaded agent file is measured
    # after expansion, and so is their total (the stricter reading of ambiguity 12).
    for rel, size in sorted(b.expanded_by_file.items()):
        r.ok("S1-2-52", size <= YAML_LIMIT, "%s: include-expanded size %d bytes exceeds 50 MiB" % (rel, size))
    expanded_total = sum(b.expanded_by_file.values())
    r.ok("S1-2-52", expanded_total <= YAML_LIMIT, "cumulative include expansion of %d agent file(s) is %d bytes (> 50 MiB)" % (
        len(b.expanded_by_file), expanded_total), "expanded agent files %d bytes in total" % expanded_total)

    names = []
    for a in agents:
        r.ok("S1-2-21", a.cls in AGENT_CLASSES, "%s: agent_class %r" % (a.src, a.cls))
        # Schema: only the documented fields of each class (L105-L125). Sequential/ParallelAgent keys are S1-2-59.
        if a.cls in ("LlmAgent", "LoopAgent"):
            allowed = LLM_KEYS if a.cls == "LlmAgent" else LOOP_KEYS
            for key in sorted(map(str, a.data)):
                if CALLBACK_KEY.match(key):
                    continue
                if a.cls == "LlmAgent" and key in LLM_KEYS_AMBIGUOUS:
                    r.add("S1-2-21", "warn", "%s: %s is named only as an !include target (L100), not among the LlmAgent "
                          "fields (L107-L119)" % (a.src, key))
                elif key not in allowed:
                    r.add("S1-2-21", "fail", "%s: %s has no documented field %r (L107-L125: %s)" % (
                        a.src, a.cls, key, ", ".join(sorted(allowed))))
        # Callbacks resolve only against the closed CallbackRegistry (L69), whose names are not documented.
        for key in sorted(k for k in map(str, a.data) if CALLBACK_KEY.match(k)):
            for cb in _callback_names(a.data[key]):
                r.ok("S1-2-02", cb in KNOWN_CALLBACKS, "%s: %s %r is not a documented CallbackRegistry name "
                     "(L69; the registry contents are undocumented)" % (a.src, key, cb))
                if "." in cb:
                    r.add("S1-2-01", "fail", "%s: %s %r looks like a Python import path (non-declarative)" % (a.src, key, cb))
        for path in _find_key(a.data, ("thinking_level", "thinkingLevel")):
            if path != "generate_content_config.thinking_config.thinking_level":  # reported below with the sampling checks
                r.add("S1-2-43", "fail", "%s: thinking_level set at %s (omit it under vLLM, L149)" % (a.src, path))
        nm = a.name
        r.ok("S1-2-22", isinstance(nm, str) and IDENT.match(nm or "") and nm != "user",
             "%s: invalid agent name %r" % (a.src, nm))
        names.append(nm)
        str_tools = [t for t in a.tools if isinstance(t, str)]
        unknown = [t for t in str_tools if t not in TOOLS9]
        r.ok("S1-2-02", not unknown, "%s: unregistered tools %s" % (a.src, unknown), "%s tools ok" % a.name)
        r.ok("S6-7-01", not unknown, "%s: unregistered tools %s" % (a.src, unknown))
        for entry in a.tools:
            if isinstance(entry, dict) and not ("agent_tool" in entry and set(entry) == {"agent_tool"}) and "name" not in entry:
                r.add("S1-2-02", "fail", "%s: non-string tool entry %r" % (a.src, entry))
        r.add("S1-2-30", "pass", "")
        if a.via in ("agent_tool", "sub_agent", "inline"):
            desc = a.data.get("description")
            r.ok("S1-2-26", isinstance(desc, str) and desc.strip() and len(desc) <= 1_000_000,
                 "%s: description missing, empty or too long" % a.src)
        elif isinstance(a.data.get("description"), str):
            r.ok("S1-2-26", len(a.data["description"]) <= 1_000_000, "%s: description too long" % a.src)
        r.ok("S1-2-27", len(a.instruction) <= 1_000_000, "%s: instruction > 1,000,000 chars" % a.src)
        r.ok("S1-2-27", len(a.global_instruction) <= 1_000_000, "%s: global_instruction > 1,000,000 chars" % a.src)
        r.ok("S1-2-27", len(a.instruction) / 3.5 < 4000, "%s: instruction about %d tokens (> 4,000 recommended)" % (
            a.src, len(a.instruction) / 3.5), warn=True)
        ok_key = a.data.get("output_key")
        if ok_key is not None:
            r.ok("S1-2-34", isinstance(ok_key, str) and IDENT.match(ok_key) and ok_key not in ("problem_description", "hints"),
                 "%s: bad output_key %r" % (a.src, ok_key))
        ic = a.data.get("include_contents")
        r.ok("S1-2-35", ic in (None, "default", "none"), "%s: include_contents %r" % (a.src, ic))
        for key in ("disallow_transfer_to_parent", "disallow_transfer_to_peers"):
            v = a.data.get(key)
            r.ok("S1-2-36", v is None or isinstance(v, bool), "%s: %s must be a boolean, got %r" % (a.src, key, v))
        if a.cls == "LoopAgent":
            mi = a.data.get("max_iterations")
            r.ok("S1-2-55", mi is None or (isinstance(mi, int) and not isinstance(mi, bool) and 1 <= mi <= 500),
                 "%s: max_iterations %r" % (a.src, mi))
            reach = any("submit_patch" in x.str_tools for x in agents if x is a or _descends(x, a))
            r.ok("S1-2-56", (mi or 500) <= 5 and reach, "%s: LoopAgent max_iterations %r or no reachable submit_patch" % (a.src, mi), warn=True)
        if a.cls in ("SequentialAgent", "ParallelAgent"):
            extra = set(a.data) - WORKFLOW_KEYS
            r.ok("S1-2-59", not extra, "%s: %s accepts only %s; found %s" % (a.src, a.cls, sorted(WORKFLOW_KEYS), sorted(extra)))
        if a.cls == "ParallelAgent":
            for x in agents:
                if _descends(x, a) and (x.str_tools & (WRITE_TOOLS | {"run_command"})):
                    r.add("S1-2-60", "warn", "%s under ParallelAgent %s declares %s" % (x.name, a.name, sorted(x.str_tools & (WRITE_TOOLS | {"run_command"}))))
    r.ok("S1-2-22", len(names) == len(set(names)), "duplicate agent names: %s" % names)
    total_instr = sum(len(a.instruction) + len(a.global_instruction) for a in agents)
    r.ok("S1-2-27", total_instr <= 10_000_000, "instructions total %d chars across %d agent(s) (> 10,000,000, L139)" % (
        total_instr, len(agents)), "instructions total %d chars across %d agent(s)" % (total_instr, len(agents)))
    if not any(a.cls == "LoopAgent" for a in agents):
        r.add("S1-2-55", "pass", "no LoopAgent")
        r.add("S1-2-56", "pass", "no LoopAgent")
    if not any(a.cls in ("SequentialAgent", "ParallelAgent") for a in agents):
        r.add("S1-2-59", "pass", "no Sequential/ParallelAgent")
    if not any(a.cls == "ParallelAgent" for a in agents):
        r.add("S1-2-60", "pass", "no ParallelAgent")
    if not any(a.data.get("output_key") is not None for a in agents):
        r.add("S1-2-34", "pass", "no output_key declared")
    if not any(a.data.get("sub_agents") for a in agents):
        r.add("S1-2-33", "pass", "no sub_agents declared")

    # ---- models ------------------------------------------------------------------------------
    models = []
    for a in llm:
        m = a.data.get("model")
        r.ok("S3-5-13", isinstance(m, str) and m.strip(), "%s: LlmAgent without an explicit model" % a.src)
        r.ok("S1-2-23", m in ALIASES, "%s: model %r is not one of the four exact aliases" % (a.src, m))
        if isinstance(m, str):
            norm = PROVIDER.sub("", m)
            models.append(norm)
            r.ok("S3-5-08", norm in ALIASES, "%s: model %r not allowed on Kaggle" % (a.src, m))
            r.ok("S3-5-09", norm not in LOCAL_ONLY and norm.endswith("-qat-w4a16-ct"), "%s: local-only alias %r" % (a.src, m))
            r.ok("S3-5-12", bool(MODEL_RE.match(m)), "%s: model %r does not match the allowed pattern" % (a.src, m))
            r.ok("S8-10-37", norm in ALIASES, "%s: model %r" % (a.src, m))
    for a in agents:
        if not a.is_llm and a.data.get("model") is not None:
            r.add("S1-2-59", "fail", "%s: %s must not declare model" % (a.src, a.cls))
    # every YAML with a top-level model key, reachable or not (L187)
    stray, all_models = [], set(models)
    for rel in yaml_files:
        parsed = b.yaml_cache.get(rel)
        if isinstance(parsed, dict) and "model" in parsed:
            m = parsed.get("model")
            if isinstance(m, str):
                all_models.add(PROVIDER.sub("", m))
                norm = PROVIDER.sub("", m)
                r.ok("S3-5-08", norm in ALIASES, "%s: model %r not allowed" % (rel, m))
                r.ok("S3-5-09", norm not in LOCAL_ONLY and norm.endswith("-qat-w4a16-ct"), "%s: local-only alias %r" % (rel, m))
                r.ok("S3-5-12", bool(MODEL_RE.match(m)), "%s: model %r does not match the allowed pattern" % (rel, m))
            if rel not in b.agent_files:
                stray.append(rel)
    r.ok("S3-5-11", not stray, "agent YAML not reachable from %s: %s" % (b.root_config, stray),
         "all %d agent YAML file(s) reachable" % len(b.agent_files))
    r.ok("S1-2-24", len(set(models)) == 1, "base models in the agent tree: %s" % sorted(set(models)),
         "single base model %s" % sorted(set(models)))
    r.ok("S3-5-10", len(all_models) == 1, "base models across all YAML files: %s" % sorted(all_models),
         "single base model across all YAML files")
    key_hits = []
    for rel in yaml_files:
        for ln in b.read_text(rel).splitlines():
            if re.match(r"^\s*-?\s*(api_base|api_key|base_url|http_options|endpoint)\s*:", ln):
                key_hits.append("%s: %s" % (rel, ln.strip()))
    r.ok("S3-5-14", not key_hits, "endpoint keys present: %s" % key_hits[:3])

    # ---- generation config -------------------------------------------------------------------
    for a in llm:
        g = a.gcc
        tag = "%s (%s)" % (a.name, a.src)
        if "__invalid__" in g:
            r.add("S1-2-37", "fail", "%s: generate_content_config is not a mapping" % tag)
            continue
        r.ok("S1-2-37", set(g) <= GCC_KEYS, "%s: unknown generate_content_config keys %s" % (tag, sorted(set(g) - GCC_KEYS)))
        tc = g.get("thinking_config") or {}
        if not isinstance(tc, dict):
            r.add("S1-2-37", "fail", "%s: thinking_config is not a mapping" % tag)
            tc = {}
        r.ok("S1-2-37", set(tc) <= TC_KEYS, "%s: unknown thinking_config keys %s" % (tag, sorted(set(tc) - TC_KEYS)))
        forb = sorted((set(g) | set(tc)) & FORBIDDEN_GCC)
        r.ok("S1-2-38", not forb, "%s: forbidden keys %s" % (tag, forb))
        mot = g.get("max_output_tokens")
        tb = tc.get("thinking_budget")
        isint = lambda v: isinstance(v, int) and not isinstance(v, bool)
        r.ok("S1-2-39", mot is not None and isint(mot) and 1 <= mot <= 32768,
             "%s: max_output_tokens %r (set an int in 1..32768; the 16,384 default is implicit)" % (tag, mot))
        r.ok("S3-5-02", mot is None or (isint(mot) and mot <= 32768), "%s: max_output_tokens %r > 32768" % (tag, mot))
        r.ok("S3-5-02", tb is None or (isint(tb) and tb <= 32768), "%s: thinking_budget %r > 32768" % (tag, tb))
        eff_mot = mot if isint(mot) else 16384
        r.ok("S1-2-40", eff_mot <= 12288, "%s: max_output_tokens %d > 12288" % (tag, eff_mot), warn=True)
        r.ok("S3-5-03", eff_mot <= 16384, "%s: max_output_tokens %d > 16384" % (tag, eff_mot), warn=True)
        r.ok("S1-2-46", tb is not None, "%s: thinking_budget not set explicitly" % tag)
        r.ok("S1-2-41", tb is None or (isint(tb) and 0 <= tb <= 32768), "%s: thinking_budget %r" % (tag, tb))
        eff_tb = tb if isint(tb) else 4096
        r.ok("S1-2-42", eff_tb + 2048 <= eff_mot, "%s: thinking_budget %d + 2048 > max_output_tokens %d" % (tag, eff_tb, eff_mot), warn=True)
        r.ok("S3-5-59", eff_mot - eff_tb >= 2048, "%s: max_output_tokens - thinking_budget < 2048" % tag)
        r.ok("S3-5-60", eff_tb < eff_mot and "thinking_level" not in tc, "%s: thinking_budget >= max_output_tokens or thinking_level set" % tag)
        r.ok("S1-2-43", "thinking_level" not in tc, "%s: thinking_level is set (omit it under vLLM, L149)" % tag)
        r.ok("S6-7-53", eff_mot + 14336 <= 32768 and eff_tb < eff_mot,
             "%s: max_output_tokens %d + 14336 > 32768 or thinking_budget >= max_output_tokens" % (tag, eff_mot))
        if eff_tb > 0:
            r.ok("S8-10-46", eff_mot <= 32768, "%s: max_output_tokens > 32768" % tag)
            r.ok("S8-10-46", eff_tb + 4096 <= eff_mot, "%s: thinking_budget %d + 4096 > max_output_tokens %d" % (tag, eff_tb, eff_mot), warn=True)
        else:
            r.add("S8-10-46", "pass", "%s: thinking disabled (budget 0)" % tag)
        it = tc.get("include_thoughts")
        r.ok("S1-2-45", it is None or isinstance(it, bool), "%s: include_thoughts %r" % (tag, it))
        t, p, k, s = g.get("temperature"), g.get("top_p"), g.get("top_k"), g.get("seed")
        num = lambda v: isinstance(v, (int, float)) and not isinstance(v, bool)
        r.ok("S1-2-47", t is None or (num(t) and t >= 0), "%s: temperature %r" % (tag, t))
        r.ok("S1-2-47", p is None or (num(p) and 0 <= p <= 1), "%s: top_p %r" % (tag, p))
        r.ok("S1-2-47", k is None or (isint(k) and k >= 1), "%s: top_k %r" % (tag, k))
        r.ok("S1-2-47", s is None or isint(s), "%s: seed %r" % (tag, s))
        r.ok("S1-2-48", "stop_sequences" not in g and "response_mime_type" not in g,
             "%s: stop_sequences/response_mime_type set (untested with Gemma tool calls)" % tag, warn=True)

    # ---- eval_config ---------------------------------------------------------------------------
    ev = {}
    if "eval_config.yaml" in b.files:
        parsed = b.load_yaml_file("eval_config.yaml")
        ok = isinstance(parsed, dict) and isinstance(parsed.get("evaluation"), dict)
        r.ok("S1-2-14", ok, "eval_config.yaml has no 'evaluation' mapping")
        r.ok("S6-7-41", ok, "eval_config.yaml has no 'evaluation' mapping", "eval_config.yaml present")
        if ok:
            ev = parsed["evaluation"]
            extra = set(ev) - EVAL_KEYS
            r.ok("S1-2-14", not extra, "unknown evaluation keys %s" % sorted(extra))
            r.ok("S3-5-51", not extra, "undocumented evaluation keys %s" % sorted(extra))
            r.ok("S6-7-42", not extra, "unknown evaluation keys %s" % sorted(extra))
            r.ok("S6-7-46", not any(re.search("cost|token", k) for k in ev), "cost/token keys in eval_config")
            r.ok("S6-7-50", not (set(ev) & {"max_stdout_chars", "max_file_lines", "max_file_chars"}), "fixed harness caps set in eval_config")
            for key, val in ev.items():
                good = isinstance(val, (int, float)) and not isinstance(val, bool) and val > 0
                r.ok("S1-2-14", good, "evaluation.%s = %r is not a positive number" % (key, val))
                r.ok("S6-7-42", good and (key == "max_time_minutes" or isinstance(val, int)),
                     "evaluation.%s = %r (positive int required; max_time_minutes may be a float)" % (key, val))
    else:
        r.add("S6-7-41", "fail", "no eval_config.yaml: Stage 1 defaults apply (60 min, 100 calls, 500 turns, 300 s)")
        r.add("S1-2-14", "pass", "no eval_config.yaml")
    calls, minutes, turns, tmo = (ev.get("max_tool_calls"), ev.get("max_time_minutes"), ev.get("max_turns"), ev.get("timeout_seconds"))
    have4 = all(isinstance(x, (int, float)) for x in (calls, minutes, turns, tmo))
    r.ok("S1-2-15", have4 and calls > 10 and minutes > 1 and tmo > 60,
         "budgets %r not all set above the sample's tiny values" % ev, "budgets %r" % ev, warn=True)
    r.ok("S3-5-22", have4 and calls >= 25 and minutes >= 8, "max_tool_calls >= ~25 and max_time_minutes >= ~8 recommended", warn=True)
    r.ok("S3-5-47", isinstance(tmo, (int, float)) and 60 <= tmo <= 300, "timeout_seconds %r not in 60..300" % tmo)
    if have4:
        r.ok("S6-7-08", 0 < tmo <= minutes * 60, "timeout_seconds %r > session time" % tmo)
        r.ok("S6-7-08", tmo <= 0.5 * minutes * 60, "timeout_seconds %r > half the session time" % tmo, warn=True)
        r.ok("S6-7-43", minutes > 1, "max_time_minutes %r <= 1" % minutes)
        r.ok("S6-7-43", 5 <= minutes <= 60, "max_time_minutes %r outside 5..60" % minutes, warn=True)
        r.ok("S6-7-44", isinstance(calls, int), "max_tool_calls missing or not an int")
        r.ok("S6-7-44", calls >= 20, "max_tool_calls %r < 20 (no budget_warning, L379)" % calls, warn=True)
        r.ok("S6-7-45", turns >= calls + 10, "max_turns %r < max_tool_calls + 10" % turns, warn=True)
        r.ok("S6-7-47", isinstance(tmo, int) and 5 <= tmo <= minutes * 60, "timeout_seconds %r" % tmo)
        r.ok("S8-10-33", isinstance(tmo, int) and tmo > 0, "timeout_seconds %r" % tmo)
        r.ok("S8-10-33", tmo <= 300, "timeout_seconds %r > 300" % tmo, warn=True)
        r.ok("S8-10-10", calls > 10 and minutes > 1, "budgets no larger than the sample (10 calls, 1 min)")
        r.ok("S8-10-10", calls >= 20 and minutes >= 5, "budgets below 20 calls / 5 min", warn=True)
    else:
        for cid in ("S6-7-08", "S6-7-43", "S6-7-44", "S6-7-45", "S6-7-47", "S8-10-33", "S8-10-10"):
            r.add(cid, "fail", "evaluation budgets incomplete: %r" % ev)

    # ---- adapters ------------------------------------------------------------------------------
    adapter_values = {a.data.get("adapter") for a in llm if a.data.get("adapter") is not None}
    adapter_dirs = sorted({f.split("/")[1] for f in b.files if f.startswith("adapters/") and f.count("/") >= 2})
    adapter_files_top = [f for f in b.files if f.startswith("adapters/") and f.count("/") == 1]
    r.ok("S1-2-58", not adapter_files_top, "files directly under adapters/: %s" % adapter_files_top)
    for v in adapter_values:
        r.ok("S3-5-16", isinstance(v, str) and bool(ADAPTER_NAME.match(v)), "adapter value %r has an invalid name" % v)
        r.ok("S3-5-17", isinstance(v, str) and os.path.isdir(os.path.join(b.root, "adapters", str(v))), "adapter %r has no adapters/%s/" % (v, v))
    unref = [d for d in adapter_dirs if d not in adapter_values]
    r.ok("S3-5-05", not unref, "unreferenced adapter dirs %s still load and cost GPU memory" % unref, warn=True)
    r.ok("S3-5-05", adapter_values <= set(adapter_dirs), "adapter values without dirs: %s" % sorted(adapter_values - set(adapter_dirs)))
    declared_model = models[0] if models else ""
    for d in adapter_dirs:
        r.ok("S3-5-16", bool(ADAPTER_NAME.match(d)), "adapter dir %r has an invalid name" % d)
        members = [f for f in b.files if f.startswith("adapters/%s/" % d)]
        sub = [f for f in members if f.count("/") > 2]
        names_in = {f.split("/")[2] for f in members if f.count("/") == 2}
        r.ok("S1-2-58", names_in <= {"adapter_config.json", "adapter_model.safetensors", "README.md"} and not sub,
             "adapters/%s has extra files %s" % (d, sorted(names_in - {"adapter_config.json", "adapter_model.safetensors", "README.md"}) + sub))
        cfg_path = os.path.join(b.root, "adapters", d, "adapter_config.json")
        st_path = os.path.join(b.root, "adapters", d, "adapter_model.safetensors")
        both = os.path.isfile(cfg_path) and os.path.isfile(st_path)
        r.ok("S1-2-25", both, "adapters/%s lacks adapter_config.json or adapter_model.safetensors" % d)
        r.ok("S3-5-15", both and not any(f.endswith(".bin") for f in members), "adapters/%s incomplete or has .bin" % d)
        if not both:
            continue
        try:
            cfg = json.load(open(cfg_path))
        except ValueError as exc:
            r.add("S1-2-25", "fail", "adapters/%s/adapter_config.json: %s" % (d, exc))
            continue
        r.ok("S3-5-15", cfg.get("peft_type") == "LORA", "adapters/%s peft_type %r" % (d, cfg.get("peft_type")))
        rank = cfg.get("r")
        ranks = [rank] + list((cfg.get("rank_pattern") or {}).values())
        r.ok("S3-5-06", all(isinstance(x, int) and 0 < x <= 128 for x in ranks), "adapters/%s ranks %s exceed 128" % (d, ranks))
        r.ok("S3-5-06", rank in (8, 16, 32, 64, 128), "adapters/%s r=%r is not a standard vLLM rank" % (d, rank), warn=True)
        r.ok("S3-5-15", not cfg.get("use_dora") and not cfg.get("modules_to_save"), "adapters/%s uses DoRA or modules_to_save" % d)
        base = str(cfg.get("base_model_name_or_path", "")).lower()
        size_tok = re.search(r"gemma-4-(31b|12b|e4b|e2b)", declared_model)
        r.ok("S3-5-18", bool(size_tok) and size_tok.group(1) in base,
             "adapters/%s base_model_name_or_path %r does not name %s" % (d, base, declared_model), warn=True)
        r.ok("S3-5-18", cfg.get("r") == 16 and cfg.get("lora_alpha") == 32,
             "adapters/%s r/alpha = %r/%r (recipe: 16/32)" % (d, cfg.get("r"), cfg.get("lora_alpha")), warn=True)
        try:
            header = safetensors_header(st_path)
            r.add("S1-2-25", "pass", "adapters/%s safetensors header ok (%d tensors)" % (d, len(header) - ("__metadata__" in header)))
            r.add("S3-5-15", "pass", "")
        except Exception as exc:
            r.add("S1-2-25", "fail", "adapters/%s safetensors header: %s" % (d, exc))
            r.add("S3-5-15", "fail", "adapters/%s safetensors header: %s" % (d, exc))
            continue
        keys = [k for k in header if k != "__metadata__"]
        dtypes = {header[k]["dtype"] for k in keys}
        r.ok("S3-5-19", dtypes <= {"BF16"}, "adapters/%s dtypes %s (bf16 recommended)" % (d, sorted(dtypes)), warn=True)
        size = os.path.getsize(st_path)
        band = {16: 220e6, 32: 450e6, 64: 900e6, 128: 1.8e9}.get(rank)
        if band:
            r.ok("S3-5-19", size <= 2 * band, "adapters/%s %d bytes far above the r=%s band" % (d, size, rank), warn=True)
        if "31b" in declared_model:
            bad = [k for k in keys if not LORA_31B_KEY.match(k)]
            r.ok("S3-5-07", not bad, "adapters/%s keys not in the verified 31B PEFT layout, e.g. %s" % (d, bad[:2]),
                 "adapters/%s: %d keys match the 31B layout" % (d, len(keys)))
        elif "12b" in declared_model:
            r.ok("S3-5-07", not any("language_model." in k for k in keys),
                 "adapters/%s: keys contain 'language_model.' but 12B is served as Gemma4ForCausalLM" % d, warn=True)
        else:
            r.add("S3-5-07", "warn", "adapters/%s: no reference key layout for %s" % (d, declared_model))
    if not adapter_dirs and not adapter_values:
        for cid in ("S1-2-25", "S1-2-58", "S3-5-05", "S3-5-06", "S3-5-07", "S3-5-15", "S3-5-16", "S3-5-17", "S3-5-18"):
            r.add(cid, "pass", "no adapters declared (adapter slot documented separately)")

    # ---- skills --------------------------------------------------------------------------------
    declared_skills = {}
    for a in agents:
        for sk in a.skills:
            if not isinstance(sk, str):
                r.add("S1-2-32", "fail", "%s: skills entry %r is not a string" % (a.src, sk))
                continue
            rel = b.resolve_ref(a.src.split("#")[0], sk, "S1-2-32")
            if rel is None or not os.path.isdir(os.path.join(b.root, rel)):
                r.add("S1-2-32", "fail", "%s: skill dir %r missing" % (a.src, sk))
                continue
            declared_skills.setdefault(rel, []).append(a)
    r.ok("S1-2-32", len(declared_skills) <= 1000, "more than 1,000 skills")
    skill_dirs_on_disk = sorted({"/".join(f.split("/")[:2]) for f in b.files if f.startswith("skills/") and f.count("/") >= 2})
    for d in skill_dirs_on_disk:
        r.ok("X-SKILL-01", d in declared_skills, "%s is shipped but no agent declares it" % d, warn=True)
    own_skills = {id(a): set() for a in agents}  # skill directory names each agent declares
    for rel, owners in declared_skills.items():
        for owner in owners:
            own_skills[id(owner)].add(rel.split("/")[-1])
    bundle_skill_names = {d.split("/")[-1] for d in skill_dirs_on_disk} | {rel.split("/")[-1] for rel in declared_skills}
    agent_names = [x.name for x in agents if isinstance(x.name, str)]
    stdlib = getattr(sys, "stdlib_module_names", None)
    for d, owners in sorted(declared_skills.items()):
        members = [f for f in b.files if f.startswith(d + "/")]
        size = sum(b.sizes[f] for f in members)
        r.ok("S1-2-32", "%s/SKILL.md" % d in b.files, "%s has no SKILL.md" % d)
        r.ok("S1-2-32", size <= SKILL_LIMIT, "%s is %d bytes > 50 MiB" % (d, size))
        bad_types = [f for f in members if os.path.splitext(f)[1] not in (".md", ".txt", ".py")]
        r.ok("S1-2-32", not bad_types, "%s holds non .md/.txt/.py files %s" % (d, bad_types))
        if "%s/SKILL.md" % d not in b.files:
            continue
        text = b.read_text("%s/SKILL.md" % d)
        front = {}
        match = re.match(r"^---\n(.*?)\n---\n", text, re.S)
        if match:
            try:
                front = parse_yaml(match.group(1), not args.no_yaml_lib) or {}
            except YamlProblem as exc:
                r.add("X-SKILL-01", "fail", "%s: frontmatter: %s" % (d, exc))
        dirname = d.split("/")[-1]
        r.ok("X-SKILL-01", isinstance(front, dict) and front.get("name") == dirname,
             "%s: frontmatter name %r != directory %r" % (d, front.get("name") if isinstance(front, dict) else None, dirname))
        r.ok("X-SKILL-01", re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", dirname) is not None, "%s: name is not kebab-case" % d)
        desc = front.get("description") if isinstance(front, dict) else None
        r.ok("X-SKILL-01", isinstance(desc, str) and 0 < len(desc) <= 1024, "%s: description missing or > 1024 chars" % d)
        r.ok("X-SKILL-01", isinstance(desc, str) and len(desc) <= 200, "%s: description %d chars (> 200 adds listing tokens on every call)" % (d, len(desc or "")), warn=True)
        r.ok("X-SKILL-01", isinstance(desc, str) and not placeholders(desc), "%s: description has {placeholder} braces" % d)
        refs = set(re.findall(r"(?<![\w/])((?:scripts|references|assets)/[\w./-]+\.\w+)", text))
        missing = [p for p in refs if "%s/%s" % (d, p) not in b.files]
        r.ok("S3-5-56", not missing, "%s/SKILL.md references missing files %s" % (d, missing),
             "%s: %d referenced resource(s) exist" % (d, len(refs)))
        body_tools = {t for t in TOOLS9 | SKILL_TOOLS if re.search(r"\b%s\b" % t, text)}
        for owner in owners:  # a SKILL.md is read by its owner (load_skill), so it may only name what the owner has
            extra = body_tools - owner.declared()
            r.ok("X-SKILL-05", not extra, "%s/SKILL.md names %s, which %s does not declare" % (d, sorted(extra), owner.name))
            odd = tool_like_mentions(text, owner.declared(), agent_names)
            r.ok("X-SKILL-05", not odd, "%s/SKILL.md uses %s like tools, which %s does not declare" % (d, sorted(odd), owner.name))
            r.ok("X-SKILL-05", not (SHELL_PHRASE.search(text) and "run_command" not in owner.str_tools),
                 "%s/SKILL.md tells the reader to use the shell, but %s declares no run_command" % (d, owner.name))
            foreign = skill_mentions(text, bundle_skill_names) - own_skills[id(owner)]
            r.ok("X-SKILL-05", not foreign, "%s/SKILL.md refers to skill(s) %s, which %s does not declare" % (
                d, sorted(foreign), owner.name))
        for f in members:
            if f.endswith(".py"):
                try:
                    tree = ast.parse(b.read_bytes(f).decode("utf-8"), filename=f)
                    compile(tree, f, "exec", dont_inherit=True)
                    r.add("X-SKILL-02", "pass", "")
                except (SyntaxError, UnicodeDecodeError, ValueError) as exc:
                    r.add("X-SKILL-02", "fail", "%s: %s" % (f, exc))
                    continue
                if stdlib:
                    mods = set()
                    for node in ast.walk(tree):
                        if isinstance(node, ast.Import):
                            mods |= {n.name.split(".")[0] for n in node.names}
                        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
                            mods.add(node.module.split(".")[0])
                    nonstd = sorted(m for m in mods if m not in stdlib)
                    r.ok("X-SKILL-04", not nonstd, "%s imports non-stdlib modules %s" % (f, nonstd))
    if not declared_skills:
        r.add("S1-2-32", "pass", "no skills declared")
        r.add("S3-5-56", "pass", "no skills declared")
    installer = "skills/repro-verify/scripts/install.py"
    if installer in b.files:
        canon = {"pyloc.py": "skills/py-locate/scripts/pyloc.py", "tests.py": "skills/test-scout/scripts/tests.py",
                 "trace.py": "skills/repro-verify/scripts/trace.py", "check.py": "skills/repro-verify/scripts/check.py"}
        embedded, hashes = {}, {}
        try:
            for node in ast.parse(b.read_text(installer)).body:
                if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Subscript) \
                        and isinstance(node.targets[0].value, ast.Name):
                    key = ast.literal_eval(node.targets[0].slice)
                    target = {"SOURCES": embedded, "SHA256": hashes}.get(node.targets[0].value.id)
                    if target is not None:
                        target[key] = ast.literal_eval(node.value)
        except (SyntaxError, ValueError) as exc:
            r.add("X-SKILL-03", "fail", "installer unreadable: %s" % exc)
        for name, rel in canon.items():
            if rel not in b.files:
                r.add("X-SKILL-03", "fail", "canonical %s missing" % rel)
                continue
            data = b.read_bytes(rel)
            if name in embedded:  # cross-skill script carried as text
                ok = embedded[name] == data.decode("utf-8") and hashes.get(name) == hashlib.sha256(data).hexdigest()
            else:  # sibling copied from the materialized skill dir: must sit next to install.py with the recorded hash
                ok = os.path.dirname(rel) == os.path.dirname(installer) and hashes.get(name) == hashlib.sha256(data).hexdigest()
            r.ok("X-SKILL-03", ok, "install.py record for %s differs from %s (rerun 51_build_skill_installer.py)" % (name, rel),
                 "install.py: %d embedded + %d sibling script(s) match" % (len(embedded), len(canon) - len(embedded)))
    else:
        r.skip("X-SKILL-03", "no installer in this bundle")

    # ---- prompts -------------------------------------------------------------------------------
    ROOT = root.instruction
    all_instr = [(a, a.instruction) for a in agents]
    # ADK templates session state into instruction and global_instruction; description is what a parent reads.
    global_texts = [(a, a.global_instruction) for a in agents if a.global_instruction]
    desc_texts = [(a, a.description) for a in agents if a.description]
    skill_texts = [(d, b.read_text("%s/SKILL.md" % d)) for d in declared_skills if "%s/SKILL.md" % d in b.files]
    every_text = [("%s instruction" % a.name, t) for a, t in all_instr] + \
                 [("%s global_instruction" % a.name, t) for a, t in global_texts] + \
                 [("%s description" % a.name, t) for a, t in desc_texts] + \
                 [("%s/SKILL.md" % d, t) for d, t in skill_texts]
    joined_all = "\n".join(t for _, t in every_text)
    output_keys = {a.data.get("output_key") for a in agents if a.data.get("output_key")}
    allowed_ph = {"problem_description", "hints"} | output_keys

    def absent(cid, pattern, what, warn=False, texts=None, neg_ok=False):
        """Fail on lines matching `pattern`. With neg_ok, a match is excused only when a negation governs it
        in the same clause (governed/ungoverned), not merely when the line contains a negation word."""
        hits = []
        for label, text in texts or every_text:
            for ln in lines_matching(pattern, text):
                if neg_ok and ungoverned(pattern, ln) is None:
                    continue
                hits.append("%s: %s" % (label, ln.strip()[:120]))
        r.ok(cid, not hits, "%s: %s" % (what, hits[:3]), warn=warn)

    def toplevel_writes():
        """write_file/edit_file pointed at a new top-level file (outside any package): it enters the patch."""
        hits = []
        for label, text in every_text:
            for ln in text.splitlines():
                if not re.search(r"\b(write_file|edit_file)\b", ln):
                    continue
                for m in re.finditer(r"`(?:/workspace/)?([\w.-]+\.[A-Za-z0-9]+)`|/workspace/([\w.-]+\.[A-Za-z0-9]+)\b", ln):
                    if not governed(ln, m.start()):
                        hits.append("%s: %s" % (label, m.group(1) or m.group(2)))
        return hits

    def present(cid, pattern, what, text=None, warn=False, flags=re.I):
        r.ok(cid, re.search(pattern, ROOT if text is None else text, flags) is not None, "%s not found in the root instruction" % what, warn=warn)

    absent("S1-2-04", r"ask the user|wait for (the )?user|confirm with", "asks for user interaction")
    present("S1-2-09", r"/tmp", "'/tmp' scratch location")
    raw_root_yaml = b.raw_yaml.get(b.root_config, "")
    r.ok("S1-2-28", "{problem_description}" in ROOT or "harness task prompt" in raw_root_yaml,
         "root instruction neither templates the problem nor documents reliance on the harness task prompt",
         "relies on the harness task prompt (documented in %s)" % b.root_config if "{problem_description}" not in ROOT else "")
    for a, text, field in [(a, t, "instruction") for a, t in all_instr] + [(a, t, "global_instruction") for a, t in global_texts]:
        bad = [(n, o, raw) for n, o, raw in placeholders(text) if n not in allowed_ph]
        for cid in ("S1-2-29", "S3-5-40", "S3-5-43", "S6-7-54"):
            r.ok(cid, not bad, "%s %s: unknown state placeholders %s" % (a.name, field, [x[2] for x in bad]))
        bare_hints = [raw for n, o, raw in placeholders(text) if n == "hints" and not o]
        r.ok("S3-5-42", not bare_hints, "%s %s: bare {hints} (use {hints?}; the key is absent when hints are empty)" % (a.name, field))
        need_opt = [raw for n, o, raw in placeholders(text) if n in output_keys and not o]
        if need_opt:
            r.add("S1-2-29", "warn", "%s %s: output_key placeholders without '?': %s" % (a.name, field, need_opt))
        r.ok("S1-2-27", True, "")
    for a, text in desc_texts:  # descriptions are not templated [inferred], so braces would stay literal
        literal = [raw for _n, _o, raw in placeholders(text)]
        r.ok("S1-2-29", not literal, "%s description: %s is not templated (only instructions are)" % (a.name, literal), warn=True)
    # The task text reaches the root in the first user message (L306-L311), which ADK compaction can summarize
    # (L568-L574) [inferred]; one verbatim copy in the never-compacted system instruction keeps it available.
    n_pd = len(re.findall(r"\{problem_description\??\}", ROOT))
    r.ok("S3-5-41", n_pd <= 1, "root instruction templates {problem_description} %d times (duplication)" % n_pd, warn=True)
    r.ok("S3-5-41", n_pd >= 1, "root instruction has no {problem_description}: the task text then lives only in the first user "
         "message, which ADK compaction can summarize away [inferred]", "root keeps one verbatim copy of the task", warn=True)
    r.ok("S3-5-03", len(ROOT) / 4 <= 2000, "root instruction about %d tokens (> 2,000)" % (len(ROOT) / 4), warn=True)
    absent("S3-5-04", r"```json|\"tool\"\s*:|respond with json", "text tool-call format described")
    present("S3-5-20", r"pytest\s+\S*tests?/\S+|\s-k\s|::", "targeted pytest guidance")
    absent("S3-5-20", r"-n\s+auto|xdist", "parallel/full-suite pytest suggested", warn=True, neg_ok=True)
    absent("S3-5-21", r"previous task|earlier task|last task|across tasks|from (a|the) previous (run|session)|remember (from|between)",
           "relies on cross-task memory")
    present("S3-5-23", r"/tmp", "'/tmp'")
    absent("S3-5-23", r"/workspace/[\w/-]*(repro|reproduce|scratch|test_repro|debug)[\w-]*\.py", "repro scripts placed in /workspace")
    tl_writes = toplevel_writes()
    r.ok("S3-5-23", not tl_writes, "file tools pointed at new top-level files (they enter the patch): %s" % tl_writes[:3])

    def prohibits(word):
        return any(gov and m.group(1).lower() == word for l in ROOT.splitlines()
                   for m, gov in match_governance(r"git\s+(commit|stash|reset|checkout|restore|clean|rebase)", l))
    r.ok("S3-5-24", prohibits("commit") and prohibits("stash"), "no prohibition of git commit and git stash")
    present("S3-5-27", r"(library|source)[ -]code", "'fix library/source code'")
    r.ok("S3-5-27", any(negated(l) for l in lines_matching(r"test", ROOT)), "no prohibition on editing tests")
    absent("S3-5-30", r"pip install|curl |wget |git (clone|fetch|pull)|requests\.get\(.http", "network/install instruction", neg_ok=True)
    present("S3-5-31", r"/workspace", "'/workspace'")
    present("S3-5-31", r"/tmp", "'/tmp'")
    absent("S3-5-31", r"(?<![\w/.-])/(repo|app|testbed)\b", "other absolute repo roots")
    other_abs = []
    for label, text in every_text:
        for m in re.finditer(r"(?<![\w.~/:<\"'(-])(/[A-Za-z_][\w.-]*)(/[\w.*-]+)*", text):
            path = m.group(0).rstrip(".,;:")
            if not re.match(r"^/(workspace|tmp|wheels|usr/local/bin|dev/null)(/|$)", path):
                other_abs.append("%s: %s" % (label, path))
    r.ok("S3-5-32", not other_abs, "absolute paths outside /workspace,/tmp,/wheels,/usr/local/bin: %s" % other_abs[:5], warn=True)
    absent("S3-5-33", r"git (log|show|blame)", "recommends git history search", neg_ok=True)
    absent("S3-5-35", r"sed -i\.bak|sed -i\S|patch -p", "artifact-producing commands", warn=True)
    r.ok("S3-5-39", any(negated(l) and "pytest.ini" in l and "conftest.py" in l for l in ROOT.splitlines()),
         "no prohibition mentioning both pytest.ini and conftest.py")
    candidates = TOOLS9 | SKILL_TOOLS | set(agent_names) | {"transfer_to_agent"}

    def tool_findings(agent, text, declared):
        """(registered names mentioned, those not declared, other names used like tools, foreign skill names)."""
        mentioned = {t for t in candidates if t and t != agent.name and re.search(r"(?<![\w-])%s(?![\w-])" % re.escape(t), text)}
        odd = tool_like_mentions(text, declared | {agent.name}, agent_names)
        foreign = skill_mentions(text, bundle_skill_names) - own_skills.get(id(agent), set())
        return mentioned, sorted(mentioned - declared), sorted(odd), sorted(foreign)

    def report_tools(label, undeclared, odd, foreign):
        for cid in ("S3-5-44", "S6-7-01"):
            r.ok(cid, not undeclared, "%s mentions undeclared tools %s" % (label, undeclared))
            r.ok(cid, not odd, "%s uses %s like tools, but they are not declared (README L352: such a call returns a "
                 "ToolErrorPlugin error)" % (label, odd))
        r.ok("S3-5-44", not foreign, "%s refers to skill(s) %s that it does not declare" % (label, foreign))

    for a in agents:  # a description advertises the agent to its parent, so it may name only what the agent has
        if a.description:
            _m, und, odd, foreign = tool_findings(a, a.description, a.declared())
            report_tools("%s description" % a.name, und, odd, foreign)
        if a.global_instruction:  # ADK adds the root's global_instruction to every agent's request
            for x in [y for y in agents if y.is_llm]:
                _m, und, odd, foreign = tool_findings(x, a.global_instruction, x.declared())
                report_tools("%s global_instruction (seen by %s)" % (a.name, x.name), und, odd, foreign)
    for a, text in all_instr:
        declared = a.declared()
        mentioned, undeclared, odd, foreign = tool_findings(a, text, declared)
        report_tools(a.name, undeclared, odd, foreign)
        gs_decl, gs_ment = "get_status" in a.str_tools, "get_status" in mentioned
        r.ok("S6-7-18", gs_decl == gs_ment, "%s: get_status declared=%s mentioned=%s" % (a.name, gs_decl, gs_ment))
        r.ok("S8-10-54", (not gs_ment) or gs_decl, "%s mentions get_status without declaring it" % a.name)
        if "read_file" in a.str_tools:
            r.ok("S3-5-49", re.search(r"start_line|end_line|line range|window", text) is not None, "%s: no ranged-read guidance" % a.name)
        if a.str_tools & GRAPH_TOOLS and mentioned & GRAPH_TOOLS:
            r.ok("S6-7-35", re.search(r"`[a-z_][\w]*\.[\w]+\.[\w.]+`", text) is not None, "%s: no dotted-id examples for graph tools" % a.name)
        if "get_code_subgraph" in mentioned:
            r.ok("S6-7-40", any("list" in l for l in lines_matching(r"get_code_subgraph", text)), "%s: get_code_subgraph not described as taking a list of ids" % a.name)
    if not any("get_code_subgraph" in t for _, t in all_instr):
        r.add("S6-7-40", "pass", "get_code_subgraph not mentioned")
    if not any(a.str_tools & GRAPH_TOOLS for a in agents):
        r.add("S6-7-35", "pass", "no graph tools declared")
    # L338: section 6 of the root's first message lists the graph tools "declared across the agent hierarchy", so a
    # root without them is probably told to use tools it cannot call [inferred]. Its instruction must say who can.
    missing_graph = set().union(*[x.str_tools & GRAPH_TOOLS for x in agents]) - root.str_tools
    if missing_graph:
        owners = sorted({x.name for x in agents if x is not root and x.str_tools & missing_graph and x.name})
        told = any(re.search(r"graph", ln, re.I) and any(o in ln for o in owners) and
                   re.search(r"task message|first (user )?message|harness|\blist(s|ed)?\b", ln, re.I) for ln in ROOT.splitlines())
        r.ok("S3-5-52", told, "the harness task message probably lists %s to the root (L338 'across the agent hierarchy' "
             "[inferred]), which does not declare them; say in the root instruction that only %s can call them" % (
                 sorted(missing_graph), " / ".join(owners) or "a sub-agent"),
             "root instruction says graph tools %s belong to %s" % (sorted(missing_graph), ", ".join(owners)))
    mentions_fastapi = re.search(r"fastapi", ROOT, re.I)
    r.ok("S3-5-45", not mentions_fastapi or re.search(r"\b(rich|requests|httpx)\b", ROOT, re.I),
         "root instruction treats FastAPI as the only repository")
    unit_val = {"tool call": calls, "minute": minutes, "turn": turns}
    for label, text in every_text:
        for m in re.finditer(r"(\d+)\s*-?\s*(tool[- ]calls?|calls?|minutes?|turns?)\b", text, re.I):
            num, unit = int(m.group(1)), m.group(2).lower().replace("-", " ").rstrip("s")
            unit = "tool call" if unit in ("call", "tool call") else unit
            before = text[max(0, m.start() - 20):m.start()].lower()
            bound = unit_val.get(unit)
            self_cap = re.search(r"(at most|up to|no more than|maximum of)\s*$", before)
            after = text[m.end():m.end() + 16].lower()
            # "at least N tool calls remain" is a THRESHOLD on the remaining budget, not a claim about the budget:
            # it only has to be smaller than the budget (e.g. the A1 prompt's graph-decision rule).
            threshold = (re.search(r"(at least|fewer than|less than|more than|over|above)\s*$", before)
                         or after.lstrip().startswith("remain"))
            if threshold and not self_cap:
                for cid in ("S3-5-46",) + (("S6-7-03",) if unit == "tool call" else ()):
                    r.ok(cid, bound is None or num < bound,
                         "%s: threshold '%s' is not below the eval_config budget (%s=%r)" % (label, m.group(0), unit, bound))
                continue
            if unit == "tool call" and not re.match(r"\d+\s*-?\s*tool", m.group(0), re.I) and not self_cap:
                continue  # e.g. "3 graph calls" never matches; bare "N calls" only counts with a cap phrase
            good = (bound is not None and num == bound) or (self_cap and bound is not None and num <= bound)
            for cid in ("S3-5-46",) + (("S6-7-03",) if unit == "tool call" else ()):
                r.ok(cid, good, "%s: '%s' does not match eval_config (%s=%r)" % (label, m.group(0), unit, bound))
    r.add("S3-5-46", "pass", "")
    r.add("S6-7-03", "pass", "")
    present("S3-5-48", r"\bhead\b|\btail\b|grep -n|--tb=short", "output narrowing")
    absent("S3-5-50", r"never output text|do not run tests|don't run tests|never run tests|do not verify|skip verification|never test",
           "contradicts the harness's standard instructions")
    for label, text in every_text:
        for m in re.finditer(r"search_similar_code\(\s*(?:query\s*=\s*)?[\"']([^\"']*)[\"']", text):
            r.ok("S3-5-52", " " not in m.group(1), "%s: natural-language search_similar_code example %r" % (label, m.group(1)))
            r.ok("S6-7-38", re.fullmatch(r"[A-Za-z_][\w.]*", m.group(1)) is not None, "%s: non-identifier query %r" % (label, m.group(1)))
    r.add("S3-5-52", "pass", "")
    r.add("S6-7-38", "pass", "")
    r.ok("S3-5-54", "submit_patch" in root.str_tools, "root agent does not declare submit_patch")
    if re.search(r"error_message|[`\"']error[`\"']", joined_all):
        r.ok("S3-5-55", "error_message" in joined_all and re.search(r"[`\"']error[`\"']", joined_all),
             "error field named without accepting both 'error' and 'error_message'")
    else:
        r.add("S3-5-55", "pass", "no error field named")
    final_submit = re.search(r"submit_patch.{0,120}(final|last)|(final|last).{0,80}submit_patch", ROOT, re.I)
    r.ok("S3-5-57", final_submit and re.search(r"verif", ROOT, re.I), "no 'verify, then submit_patch as the final tool call' wording")
    present("S3-5-58", r"(end|finish) every turn with a tool call|always (act|respond|answer) with a tool call|every turn must end with a tool call|keep calling tools",
            "'always end the turn with a tool call'")
    present("S3-5-59", r"(never|don't|do not)[^\n]{0,40}(rewrite|replace)[^\n]{0,30}(whole|entire)", "'never rewrite a whole file'")
    for a in agents:
        if a.via in ("agent_tool", "sub_agent", "inline"):
            r.ok("S6-7-02", not (a.str_tools & WRITE_TOOLS), "%s (%s) declares %s" % (a.name, a.via, sorted(a.str_tools & WRITE_TOOLS)))
            r.ok("S6-7-02", "run_command" not in a.str_tools, "%s (%s) declares run_command (not strictly read-only)" % (a.name, a.via), warn=True)
            r.ok("S8-10-52", not (a.str_tools & WRITE_TOOLS), "%s declares %s" % (a.name, sorted(a.str_tools & WRITE_TOOLS)))
            r.ok("S8-10-52", "run_command" not in a.str_tools, "%s declares run_command" % a.name, warn=True)
            if a.via == "agent_tool":
                r.ok("S6-7-04", re.search(r"at most \d+ (tool )?calls|stop (as soon|when|after)|then answer", a.instruction, re.I) is not None,
                     "%s: no call limit or stop condition in its instruction" % a.name)
    r.ok("S6-7-02", "submit_patch" in root.str_tools, "root agent lacks submit_patch")
    if not any(a.via == "agent_tool" for a in agents):
        r.add("S1-2-31", "pass", "no agent_tool entries")
        r.add("S6-7-04", "pass", "no agent_tool sub-agents")
        r.add("S8-10-51", "pass", "no agent_tool entries")
        r.add("S8-10-52", "pass", "no agent_tool entries")
    absent("S6-7-05", r"\breturncode\b|\"output\"\s*:|success:\s*true|\"success\"", "invented tool-result field names")
    r.ok("S6-7-06", not (isinstance(calls, int) and calls < 20 and "budget_warning" in joined_all),
         "prompt relies on budget_warning but max_tool_calls < 20")
    cd_spans = [s for s in code_spans(joined_all) if re.search(r"\bcd\s+\S+", s) and "&&" not in s and ";" not in s]
    r.ok("S6-7-07", not cd_spans, "cd without chaining: %s" % cd_spans[:3], warn=True)
    present("S6-7-09", r"pytest\s+\S+::|\s-x\b|\s-q\b|--tb=short", "targeted-test flags")
    present("S6-7-10", r"\btail\b|\bhead\b|grep -n|\s-q\b|--tb=", "output-limiting idiom")
    present("S6-7-11", r"exit_code 1|exit code 1", "explanation that exit_code 1 is often normal", warn=True)
    present("S6-7-12", r"scratch[^\n]{0,80}/tmp|/tmp[^\n]{0,80}scratch|delet\w* scratch", "scratch files kept out of /workspace")
    absent("S6-7-13", r"git\s+(commit|stash|reset|checkout|rebase|tag|update-ref)", "git history/ref commands outside a prohibition", neg_ok=True)
    wf = section(ROOT, "Workflow") or ROOT
    pos, ok_order = 0, True
    for pat in (r"\bedit", r"\bverif", r"clean|git status|check\.py|\brm\b", r"submit_patch"):
        m = re.search(pat, wf[pos:], re.I)
        if not m:
            ok_order = False
            break
        pos += m.end()
    r.ok("S6-7-14", ok_order, "workflow does not order edit -> verify -> clean up -> submit_patch")
    if re.search(r"budget", ROOT, re.I):
        present("S6-7-15", r"submit_patch[^\n]{0,60}free|free[^\n]{0,60}submit_patch|submit_patch and get_status are free", "'submit_patch is free'")
    else:
        r.add("S6-7-15", "pass", "budgets not mentioned")
    r.ok("S6-7-16", final_submit is not None, "no 'submit_patch as the final action' wording")
    snake = set()
    for ln in lines_matching(r"get_status", joined_all):  # path pieces such as tests/test_x.py are not field names
        snake |= {t for t in re.findall(r"(?<![\w/.-])[a-z]+(?:_[a-z]+)+(?![\w/.-])", ln)
                  if t not in TOOLS9 | SKILL_TOOLS | {x.name for x in agents if x.name}}
    known = GET_STATUS_FIELDS | {"budget_warning"}  # budget_warning rides on every tool response (L379-L382)
    r.ok("S6-7-19", snake <= known, "unknown get_status field names %s" % sorted(snake - known))
    absent("S6-7-20", r"(write_file|read_file)[^\n]{0,40}(/tmp|/usr|site-packages)", "file tools pointed outside /workspace")
    absent("S6-7-21", r"(read_file|edit_file|write_file)\([^)]*\.\.", "'..' in file-tool examples")
    absent("S6-7-23", r"read_file\([^)]*\b(path|file_path|offset|limit|lines|start|end)\s*=", "wrong read_file keywords")
    claims = []
    for label, text in every_text:
        for ln in text.splitlines():
            if re.search(r"limit|cap\b|at most|maximum|\bmax\b|per (read|call)|truncat|\bcut\b", ln, re.I):
                for m in re.finditer(r"(\d[\d,]*)\s*-?\s*(lines|characters|chars)\b", ln):
                    n = int(m.group(1).replace(",", ""))
                    if n not in (150, 5000, 10000):
                        claims.append("%s: %s" % (label, m.group(0)))
    r.ok("S6-7-24", not claims, "limit numbers differ from 150 lines / 10,000 / 5,000 chars: %s" % claims[:3])
    r.ok("S6-7-50", not claims, "limit numbers differ from the fixed harness caps: %s" % claims[:3])
    present("S6-7-25", r"end_line\s*`?\s*\+\s*1|continue from", "continue from end_line + 1")
    absent("S6-7-26", r"edit_file\([^)]*\b(path|file_path|old|new|old_str|new_str|search|replace)\s*=", "wrong edit_file keywords")
    present("S6-7-27", r"verbatim", "'copy old_string verbatim'")
    present("S6-7-29", r"exactly once|unique|surrounding lines", "unique old_string advice")
    present("S6-7-31", r"edit_file for existing", "'use edit_file for existing files'")
    present("S6-7-31", r"write_file only", "'write_file only for new files'")
    bad_repro = []
    for label, text in every_text:
        for m in re.finditer(SCRATCHY, text):
            path = m.group(0)
            if not (path.startswith("/tmp/") or re.search(r"(^|/)tests?/", path) or re.search(r"(^|/)test_[^/]*\.py$", path)):
                bad_repro.append("%s: %s" % (label, path))
    r.ok("S6-7-32", not bad_repro, "repro paths outside /tmp or protected test paths: %s" % bad_repro[:3])
    absent("S6-7-34", r"get_code_neighbors\([^)]*\b(symbol|name|limit)\s*=", "wrong get_code_neighbors keywords")
    edge_vals = re.findall(r"edge_type\s*[=:]\s*[`\"']?(\w+)", joined_all)
    r.ok("S6-7-36", all(v.lower() == "calls" for v in edge_vals), "edge_type values %s (only 'calls' exists)" % edge_vals)
    ks = [int(x) for pair in re.findall(r"`k`\s*(?:=|of|:)?\s*(\d+)(?:\s*(?:to|-|–)\s*(\d+))?", joined_all) for x in pair if x]
    r.ok("S6-7-39", all(k <= 5 for k in ks), "k values %s (<= 5 recommended)" % ks, warn=True)
    est = len(ROOT) / 4 + 110 * len(root.str_tools) + (500 + 100 * len(root.skills) if root.skills else 0) + 100 * len(
        [c for v, c in root.children if v == "agent_tool"])
    r.ok("S6-7-52", est <= 4000, "root prompt + tool schemas about %d tokens (> 4,000)" % est, "about %d tokens" % est, warn=True)
    absent("S8-10-02", r"git\s+(commit|stash|reset|checkout|restore|clean|rebase)", "git state commands outside a prohibition", neg_ok=True)
    present("S8-10-03", r"/tmp", "'/tmp'")
    redirects = []
    for span in code_spans(joined_all):
        span = re.sub(r"<[^<>\s]+>", "X", span)  # <placeholder> is not a redirect
        if not re.match(r"\s*([A-Z_]+=\S+\s+)*(cat|echo|printf|python3?|git|grep|ls|sed|awk|find|head|tail|pytest|tee|cd|rm|cp|mv|sort|uniq|diff)\b", span):
            continue  # only shell command spans can redirect (not `files_changed > 0`)
        for m in re.finditer(r"(?<![<>&\d=-])>{1,2}\s*([^\s&|`)]+)", span):
            tgt = m.group(1)
            if not (tgt.startswith("/tmp") or tgt.startswith("/dev/null") or tgt.startswith("&")):
                redirects.append(span[:80])
    absent("S8-10-04", r"sed -i\.", "sed -i.bak backups")
    r.ok("S8-10-04", not redirects, "shell redirects into the working tree: %s" % redirects[:3])
    absent("S8-10-05", r"(edit|modify|update|fix) (the )?tests?\b", "tells the agent to edit tests", neg_ok=True)
    off = [w for w in ("pyproject", "conftest", "pytest.ini", "setup.cfg") if not any(negated(l) and w in l for l in ROOT.splitlines())]
    r.ok("S8-10-06", not off, "protected files not listed as off-limits: %s" % off)
    present("S8-10-09", r"debug print", "'remove debug prints'")
    present("S8-10-09", r"coherent|incremental", "'one coherent edit at a time'")
    absent("S8-10-11", r"pip install", "pip install suggested", neg_ok=True)
    present("S8-10-18", r"(do not|don't|never).{0,40}(test|conftest|pytest\.ini|pyproject)", "test/config prohibition")
    has_pytest_cmd = re.search(r"python3?\s+(-s\s+)?-m pytest|\bpytest\s+tests?/", ROOT)
    if has_pytest_cmd:
        present("S8-10-20", r"PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1 python3 -s -m pytest", "grading-equivalent pytest prefix", warn=True)
        present("S8-10-21", r"no:anyio", "-p no:anyio", warn=True)
        present("S8-10-23", r"python_classes", "-o python_classes", warn=True)
    else:
        for cid in ("S8-10-20", "S8-10-21", "S8-10-23"):
            r.add(cid, "pass", "no pytest command template in the prompt")
    edit_lines = [l for l in ROOT.splitlines() if re.search(r"edit_file|edit", l, re.I)]
    r.ok("S8-10-47", any(re.search(r"small|incremental|targeted|minimal", l, re.I) for l in edit_lines) or
         re.search(r"small|incremental", section(ROOT, "Editing rules"), re.I),
         "no 'small/incremental edits' guidance near edit_file")
    r.ok("S8-10-48", any(negated(l) and re.search(r"pytest\.ini|conftest\.py", l) for l in ROOT.splitlines()),
         "pytest.ini/conftest.py not in a do-not-modify instruction")
    present("S8-10-49", r"/tmp", "'/tmp'")
    absent("S8-10-49", r"/workspace/[\w/-]*(repro|reproduce|scratch|test_repro|debug)", "scratch paths in /workspace")
    r.ok("S8-10-49", not tl_writes, "file tools pointed at new top-level files (they enter the patch): %s" % tl_writes[:3])
    r.ok("S8-10-50", any("run_command" in l and "/tmp" in l for l in ROOT.splitlines()) or
         any("/tmp" in l and "run_command" in l for l in re.split(r"(?<=[.!?])\s+", ROOT)),
         "run_command not paired with /tmp scratch guidance")
    absent("S8-10-50", r"write_file.{0,40}/tmp", "write_file paired with /tmp")
    r.ok("S8-10-53", "submit_patch" in ROOT and "submit_patch" in root.str_tools, "submit_patch missing from root prompt or tools")
    r.ok("S8-10-57", "submit_patch" in ROOT and "submit_patch" in root.str_tools, "submit_patch missing from root prompt or tools")
    r.ok("S8-10-55", final_submit is not None, "submit_patch not described as the last/final step")
    last_submit = wf.lower().rfind("submit_patch")
    head = wf[:last_submit] if last_submit > 0 else ""
    r.ok("S8-10-56", re.search(r"pytest|python3? -c|check\.py", head) is not None and re.search(r"git status|clean ?up|\brm\b", head, re.I) is not None,
         "no verification and cleanup step before submit_patch")

    # ---- kit data (S6-7-33) ----------------------------------------------------------------------
    if args.kit:
        tasks_path = os.path.join(args.kit, "tasks.jsonl")
        missing, count = [], 0
        try:
            for line in open(tasks_path, encoding="utf-8"):
                t = json.loads(line)
                count += 1
                repo = t["repo"].split("/")[-1]
                for sub, ext in (("graphs", ".json"), ("embeddings", ".npz")):
                    p = os.path.join(args.kit, sub, "%s_%s%s" % (repo, t["base_commit"], ext))
                    if not (os.path.isfile(p) and os.path.getsize(p) > 100):
                        missing.append(os.path.relpath(p, args.kit))
            r.ok("S6-7-33", not missing, "missing graph/embedding files: %s" % missing[:5],
                 "%d tasks: graph and embedding files present (> 100 bytes)" % count)
        except OSError as exc:
            r.add("S6-7-33", "fail", "cannot read %s: %s" % (tasks_path, exc))
    else:
        r.skip("S6-7-33", "pass --kit KIT_DIR to verify graph/embedding coverage")

    # ---- local run script (S6-7-48, S8-10-30, S8-10-32, S8-10-34, S8-10-39) ---------------------
    if args.run_script:
        text = open(args.run_script, encoding="utf-8").read()
        flat = re.sub(r"\\\n", " ", text)
        cmds = [ln for ln in flat.splitlines() if re.search(r"\bswegemma\s+eval\b", ln) and not ln.strip().startswith("#")]
        if not cmds:
            for cid in ("S6-7-48", "S8-10-30", "S8-10-32", "S8-10-34", "S8-10-39"):
                r.add(cid, "fail", "no 'swegemma eval' command in %s" % args.run_script)
        else:
            cmd = cmds[0]
            flag = lambda name: (re.search(r"--%s(?:\s+|=)(\S+)" % re.escape(name), cmd) or [None, None])[1]
            exports = [ln.strip() for ln in flat.splitlines() if re.search(r"(^|\s)(export\s+)?SWE_[A-Z_]+=", ln) and not ln.strip().startswith(("#", "unset"))]
            pairs = [("max-tool-calls", calls), ("max-time-minutes", minutes), ("timeout-seconds", tmo)]
            diffs = []
            for name, want in pairs:
                got = flag(name)
                try:
                    same = got is not None and float(got.strip("\"'")) == float(want)
                except (TypeError, ValueError):
                    same = False
                if not same:
                    diffs.append("--%s %s != %s" % (name, got, want))
            r.ok("S6-7-48", not exports and not diffs, "SWE_* exports %s; flag mismatches %s" % (exports[:2], diffs),
                 "CLI budgets equal eval_config and no SWE_* overrides")
            r.ok("S8-10-30", not diffs, "CLI budgets differ from eval_config: %s" % diffs)
            sandbox = flag("sandbox")
            r.ok("S8-10-32", sandbox in (None, "docker"), "--sandbox %s (use docker for the final validation)" % sandbox)
            vt = flag("verification-timeout-seconds")
            r.ok("S8-10-34", vt is None or float(vt) <= 300, "--verification-timeout-seconds %s > 300" % vt)
            rd = flag("results-dir") or ""
            r.ok("S8-10-39", "$" in rd or re.search(r"[0-9a-f]{8,}|\d{8}", rd) is not None,
                 "--results-dir %r is not unique per bundle version" % rd)
    else:
        for cid in ("S6-7-48", "S8-10-30", "S8-10-32", "S8-10-34", "S8-10-39"):
            r.skip(cid, "pass --run-script FILE to verify the local eval command")

    return r, b


def _descends(agent, ancestor):
    node = agent.parent
    while node is not None:
        if node is ancestor:
            return True
        node = node.parent
    return False


def _callback_names(value):
    """Callback references as strings: a name, a list of names, or ADK-style {name: ...} entries."""
    items = value if isinstance(value, list) else [value]
    return [str(it.get("name", it)) if isinstance(it, dict) else str(it) for it in items]


def _find_key(data, keys, path="", skip=("tools", "sub_agents")):
    """Dotted paths of every occurrence of one of `keys` in an agent dict (child agents are checked separately)."""
    found = []
    if isinstance(data, dict):
        for k, v in data.items():
            here = "%s.%s" % (path, k) if path else str(k)
            if k in keys:
                found.append(here)
            if not path and k in skip:
                continue
            found += _find_key(v, keys, here, skip)
    elif isinstance(data, list):
        for i, v in enumerate(data):
            found += _find_key(v, keys, "%s[%d]" % (path, i), skip)
    return found


def tool_like_mentions(text, declared, agent_names):
    """Identifiers that a text uses like a tool although the agent does not declare them (README L352: such a
    call comes back as a ToolErrorPlugin error). Backticked snake_case names count when a usage verb precedes
    them, when 'tool', '(' or 'to <verb>' follows, or when they share a line with such a hit; backticked single
    words count only before 'tool'. Documented parameter/field names (KNOWN_NAMES) never count."""
    known = TOOLS9 | SKILL_TOOLS | KNOWN_NAMES | GET_STATUS_FIELDS | EVAL_KEYS | GCC_KEYS | TC_KEYS | LLM_KEYS | set(agent_names)
    found = set()
    for line in text.splitlines():
        spans = [(m.group(1), m.start(), m.end()) for m in re.finditer(r"`([^`\n]+)`", line)]
        line_hit = False
        for name, start, end in spans:
            if name in known or name in declared:
                continue
            before, after = line[:start], line[end:]
            snake = TOOLISH.match(name) is not None
            single = re.fullmatch(r"[a-z][a-z0-9]*", name) is not None
            if (snake and (USE_BEFORE.search(before) or USE_AFTER.match(after))) or \
                    (single and re.match(r"\s+tools?\b", after)):
                found.add(name)
                line_hit = True
        if line_hit:  # siblings in the same sentence, e.g. "use `x_tool` or `y_tool`"
            found |= {n for n, _s, _e in spans if TOOLISH.match(n) and n not in known and n not in declared}
        for m in re.finditer(r"\b(?:call|use|via|invoke)\s+(?:the\s+)?([a-z][a-z0-9]*(?:_[a-z0-9]+)+)\b", line, re.I):
            if m.group(1) not in known and m.group(1) not in declared:
                found.add(m.group(1))
    return found


def skill_mentions(text, bundle_skills):
    """Skill names a text tells the model to load or run: skill_name X, load_skill for X, or a backticked
    bundle skill name."""
    names = set(re.findall(r"skill_name[`'\"]?\s*(?:=|:|set to)?\s*[`'\"]([a-z0-9][a-z0-9-]*)[`'\"]", text))
    names |= set(re.findall(r"load_skill(?:_resource)?[`'\"]?\s*(?:\(|for|on|with)?\s*(?:skill_name\s*=\s*)?[`'\"]([a-z0-9][a-z0-9-]*)", text))
    names |= {m for m in re.findall(r"`([a-z0-9][a-z0-9-]*)`", text) if m in bundle_skills}
    return names


def main(argv):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("bundle")
    parser.add_argument("--kit", help="competition kit dir (tasks.jsonl, graphs/, embeddings/)")
    parser.add_argument("--run-script", help="local eval shell script to check against eval_config")
    parser.add_argument("--checklist", help="harness_checklist.json, to verify that every static check is implemented")
    parser.add_argument("--zip-out", help="also write the deterministic submission zip here")
    parser.add_argument("--report", help="also write the JSON report to this file")
    parser.add_argument("--no-yaml-lib", action="store_true", help="use the built-in YAML subset parser")
    parser.add_argument("--strict", action="store_true", help="exit non-zero on warnings too")
    parser.add_argument("--summary", action="store_true", help="print a human summary to stderr")
    parser.add_argument("--allow-dotdot", action="store_true",
                        help="warn instead of fail on '..' path components that stay inside the bundle (L102, ambiguity 1)")
    args = parser.parse_args(argv)
    report, bundle = run_checks(args)
    results = report.results
    checklist_items = []
    if args.checklist:
        data = json.load(open(args.checklist, encoding="utf-8"))
        checklist_items = data["checklist"] if isinstance(data, dict) else data
        none_like = {"", "n/a", "none", "none.", "n/a (pre-launch error).", "n/a."}
        for item in checklist_items:
            cid = item["id"]
            static = str(item.get("static_check", "")).strip().lower()
            has_static = static not in none_like and not static.startswith("none on the bundle")
            if has_static and cid not in STATIC_IDS:
                report.add("X-COVERAGE", "fail", "%s has a static_check but no implementation" % cid)
            elif not has_static and cid not in results:
                results[cid] = {"status": "skip", "details": ["no static check: runtime evidence or harness-only (see COMPLIANCE.md)"]}
        unknown = [cid for cid in STATIC_IDS if cid not in {i["id"] for i in checklist_items}]
        report.ok("X-COVERAGE", not unknown, "implemented ids missing from the checklist: %s" % unknown,
                  "all %d static checks of the %d checklist items are implemented" % (len(STATIC_IDS), len(checklist_items)))
    for cid in STATIC_IDS:
        if cid not in results:
            results[cid] = {"status": "pass", "details": ["not applicable: the construct this check guards is absent from the bundle"]}
    counts = {}
    for entry in results.values():
        counts[entry["status"]] = counts.get(entry["status"], 0) + 1
    out = {
        "bundle": os.path.realpath(args.bundle),
        "yaml_parser": "PyYAML %s" % yaml.__version__ if (HAVE_YAML and not args.no_yaml_lib) else "built-in subset parser",
        "agents": [{"name": a.name, "class": a.cls, "via": a.via, "src": a.src, "model": a.data.get("model"),
                    "adapter": a.data.get("adapter"), "tools": sorted(a.str_tools),
                    "agent_tools": [c.name for v, c in a.children if v == "agent_tool"], "skills": a.skills}
                   for a in bundle.agents],
        "files": len(bundle.files),
        "total_bytes": sum(bundle.sizes.values()),
        "counts": counts,
        "results": {k: results[k] for k in sorted(results, key=_sort_key)},
    }
    text = json.dumps(out, indent=1)
    print(text)
    if args.report:
        with open(args.report, "w", encoding="utf-8") as handle:
            handle.write(text + "\n")
    failed = [k for k, v in results.items() if v["status"] == "fail"]
    warned = [k for k, v in results.items() if v["status"] == "warn"]
    if args.summary:
        sys.stderr.write("%s: %s\n" % (args.bundle, counts))
        for k in sorted(failed + warned, key=_sort_key):
            sys.stderr.write("  %-5s %-10s %s\n" % (results[k]["status"].upper(), k, "; ".join(results[k]["details"])[:300]))
    return 1 if failed or (args.strict and warned) else 0


def _sort_key(cid):
    parts = re.findall(r"\d+|\D+", cid)
    return [int(p) if p.isdigit() else p for p in parts]


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
