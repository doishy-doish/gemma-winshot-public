from __future__ import annotations

from datetime import datetime, timezone

SLUG = "gemma-4-developer-agent"
TEAM = "Agent G"
KAGGLE_USER = "scottweeden"

DEADLINE = datetime(2026, 12, 2, 23, 59, tzinfo=timezone.utc)

SUBMISSION_KERNEL = "scottweeden/gemma4-agent-submission"
ADAPTER_MODEL_SOURCE = "scottweeden/gemma-4-31b-swe-tool-use-lora/Transformers/main-lora/1"
SUBMISSION_FILE_NAME = "submission.zip"

PUBLIC_MODEL = "scottweeden/gemma-4-31b-swe-tool-use-lora"
PUBLIC_DATASET = "scottweeden/gemma-4-developer-agent-tool-lora-kit"
PUBLIC_NOTEBOOK = "scottweeden/gemma-4-developer-agent-tool-lora-writeup"

MODEL = "gemma-4-31b-it-qat-w4a16-ct"
MODEL_ALIASES = {
    "gemma-4-31b-it-qat-w4a16-ct",
    "gemma-4-12b-it-qat-w4a16-ct",
    "gemma-4-e4b-it-qat-w4a16-ct",
    "gemma-4-e2b-it-qat-w4a16-ct",
}
LOCAL_ONLY_ALIASES = {
    "gemma-4-31b-it", "gemma-4-31b", "gemma-4-27b-it", "gemma-4-27b", "gemma-4-26b-a4b-it",
    "gemma-4-26b-a4b", "diffusiongemma-26b-a4b-it", "gemma-4-12b-it", "gemma-4-12b",
    "gemma-4-9b-it", "gemma-4-9b", "gemma-4-e4b-it", "gemma-4-e4b", "gemma-4-e2b-it", "gemma-4-e2b",
}

TOOLS = [
    "run_command", "read_file", "edit_file", "write_file", "get_status", "submit_patch",
    "get_code_neighbors", "search_similar_code", "get_code_subgraph",
]
TOOL_SET = set(TOOLS)
GRAPH_TOOLS = {"get_code_neighbors", "search_similar_code", "get_code_subgraph"}
WRITE_TOOLS = {"edit_file", "write_file", "submit_patch"}
SKILL_TOOLS = {"load_skill", "load_skill_resource", "run_skill_script", "list_skills", "search_skills"}

ALLOWED_BUNDLE_EXTENSIONS = {".yaml", ".yml", ".md", ".txt", ".py", ".json", ".safetensors"}
HASHED_EXTENSIONS = {".yaml", ".yml", ".md", ".txt", ".py", ".json"}
ROOT_CONFIG_NAMES = ["agent.yaml", "agent.yml", "root_agent.yaml", "root_agent.yml"]
EVAL_CONFIG_KEYS = {"timeout_seconds", "max_tool_calls", "max_time_minutes", "max_turns"}
ADAPTER_NAME = "main_lora"

SCORER_TASK_COUNT = 120
SCORER_HOURS = 12.0
PUBLIC_LEADERBOARD_TASKS = 58
OBSERVED_RUN_NOISE_TASKS = 6

WEEKLY_GPU_QUOTA_HOURS = 30.0
QUAD_L4_MULTIPLIER = 2.0
SUBMISSIONS_PER_UTC_DAY = 1


def score_quantum() -> float:
    return 1.0 / PUBLIC_LEADERBOARD_TASKS
