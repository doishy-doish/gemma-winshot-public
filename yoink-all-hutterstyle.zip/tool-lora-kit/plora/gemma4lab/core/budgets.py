from __future__ import annotations

import math
from dataclasses import dataclass

from gemma4lab.core import competition
from gemma4lab.yaml_mini import MiniYAML, YAMLProblem


@dataclass
class EvalBudget:
    """The `evaluation:` block of `eval_config.yaml`: the only four keys the harness accepts."""

    timeout_seconds: int
    max_tool_calls: int
    max_time_minutes: float
    max_turns: int

    @classmethod
    def parse(cls, text: str) -> "EvalBudget":
        doc = MiniYAML.parse(text)
        ev = doc.get("evaluation") if isinstance(doc, dict) else None
        if not isinstance(ev, dict):
            raise YAMLProblem("eval_config.yaml has no 'evaluation' mapping")
        extra = set(ev.keys()) - competition.EVAL_CONFIG_KEYS
        if extra:
            raise YAMLProblem(f"unknown evaluation keys {sorted(extra)}")
        try:
            t = int(ev["timeout_seconds"])
            c = int(ev["max_tool_calls"])
            m = float(ev["max_time_minutes"])
            n = int(ev["max_turns"])
        except (KeyError, TypeError, ValueError):
            raise YAMLProblem("evaluation budgets incomplete")
        return cls(timeout_seconds=t, max_tool_calls=c, max_time_minutes=m, max_turns=n)

    def to_yaml(self, comment: str | None = None) -> str:
        out = ""
        if comment:
            out += "\n".join(f"# {line}" for line in comment.split("\n")) + "\n"
        minutes = str(int(self.max_time_minutes)) if self.max_time_minutes == int(self.max_time_minutes) else str(self.max_time_minutes)
        out += (
            f"evaluation:\n"
            f"  timeout_seconds: {self.timeout_seconds}\n"
            f"  max_tool_calls: {self.max_tool_calls}\n"
            f"  max_time_minutes: {minutes}\n"
            f"  max_turns: {self.max_turns}\n"
        )
        return out

    def worst_case_scorer_hours(self, tasks: int = competition.SCORER_TASK_COUNT) -> float:
        return self.max_time_minutes * tasks / 60.0

    def fits_scorer(self, margin_hours: float = 0, tasks: int = competition.SCORER_TASK_COUNT) -> bool:
        return self.worst_case_scorer_hours(tasks) + margin_hours <= competition.SCORER_HOURS

    @staticmethod
    def projected_scorer_hours(mean_task_minutes: float, tasks: int = competition.SCORER_TASK_COUNT) -> float:
        return mean_task_minutes * tasks / 60.0

    @staticmethod
    def largest_safe_minutes(margin_hours: float = 0, tasks: int = competition.SCORER_TASK_COUNT) -> int:
        return math.floor((competition.SCORER_HOURS - margin_hours) * 60.0 / tasks)


EvalBudget.A1_SIX_MINUTE = EvalBudget(timeout_seconds=240, max_tool_calls=32, max_time_minutes=6, max_turns=80)
EvalBudget.A1_EIGHT_MINUTE = EvalBudget(timeout_seconds=240, max_tool_calls=32, max_time_minutes=8, max_turns=80)


@dataclass
class SamplingConfig:
    """`generate_content_config` as this project writes it in `configs/sampling.yaml`."""

    temperature: float
    top_p: float
    max_output_tokens: int
    thinking_budget: int
    include_thoughts: bool

    @classmethod
    def parse(cls, text: str) -> "SamplingConfig":
        doc = MiniYAML.parse(text)
        if not isinstance(doc, dict):
            raise YAMLProblem("sampling.yaml is not a mapping")
        tc = doc.get("thinking_config")
        tc = tc if isinstance(tc, dict) else {}
        try:
            t = float(doc["temperature"])
            p = float(doc["top_p"])
            mot = int(doc["max_output_tokens"])
        except (KeyError, TypeError, ValueError):
            raise YAMLProblem("sampling.yaml needs temperature, top_p and max_output_tokens")
        return cls(
            temperature=t, top_p=p, max_output_tokens=mot,
            thinking_budget=int(tc.get("thinking_budget", 4096)),
            include_thoughts=bool(tc.get("include_thoughts", False)),
        )

    @property
    def yaml(self) -> str:
        def num(d: float) -> str:
            return f"{d:.1f}" if d == int(d) else str(d)

        return (
            f"temperature: {num(self.temperature)}\n"
            f"top_p: {num(self.top_p)}\n"
            f"max_output_tokens: {self.max_output_tokens}\n"
            f"thinking_config:\n"
            f"  thinking_budget: {self.thinking_budget}\n"
            f"  include_thoughts: {str(self.include_thoughts).lower()}\n"
        )

    @property
    def answer_headroom(self) -> int:
        return self.max_output_tokens - self.thinking_budget


SamplingConfig.A1 = SamplingConfig(temperature=0.2, top_p=0.95, max_output_tokens=8192, thinking_budget=4096, include_thoughts=True)
SamplingConfig.REJECTION_SAMPLING = SamplingConfig(temperature=0.7, top_p=0.95, max_output_tokens=8192, thinking_budget=4096, include_thoughts=True)
