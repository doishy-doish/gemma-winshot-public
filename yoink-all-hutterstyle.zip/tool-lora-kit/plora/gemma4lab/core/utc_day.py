from __future__ import annotations

from datetime import datetime, timedelta, timezone

from gemma4lab.core import competition

_DATE_FMT = "%Y-%m-%d"
_STAMP_FMT = "%Y-%m-%dT%H:%M:%SZ"


def string(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime(_DATE_FMT)


def today(now: datetime | None = None) -> str:
    return string(now or datetime.now(timezone.utc))


def tomorrow(now: datetime | None = None) -> str:
    base = now or datetime.now(timezone.utc)
    return string(base + timedelta(days=1))


def timestamp(dt: datetime | None = None) -> str:
    base = dt or datetime.now(timezone.utc)
    return base.astimezone(timezone.utc).strftime(_STAMP_FMT)


def parse_date(text: str) -> datetime | None:
    try:
        return datetime.strptime(text, _DATE_FMT).replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def days_until_deadline(now: datetime | None = None) -> int:
    base = now or datetime.now(timezone.utc)
    delta = competition.DEADLINE - base
    return int(delta.total_seconds() // 86_400)


def next_quota_reset(now: datetime | None = None) -> datetime:
    """Next Saturday 00:00 UTC, when the weekly GPU quota resets."""
    base = now or datetime.now(timezone.utc)
    start = base.astimezone(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    ahead = (5 - start.weekday()) % 7
    if ahead == 0:
        ahead = 7
    return start + timedelta(days=ahead)
