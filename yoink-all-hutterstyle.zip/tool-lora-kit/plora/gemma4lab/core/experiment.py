from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum

_SCORE_RE = re.compile(r"\bLB\s*[=:]?\s*([0-9]*\.?[0-9]+)", re.IGNORECASE)

_STATUS_VALUES = {
    "idea", "drafted", "ready", "submitted", "scored", "failed_platform", "failed_bundle",
    "pending_gpu", "running_gpu", "done", "local_only", "superseded", "rejected", "current",
}


class ExperimentStatus(str):
    """Ledger statuses: idea -> drafted -> ready -> submitted -> scored | failed_*;
    GPU rows pending_gpu -> running_gpu -> done; plus local_only, superseded, rejected, and ARCH's `current`.
    Unknown values pass through unchanged (Swift's `.other(String)` case)."""

    def __new__(cls, value: str):
        return str.__new__(cls, value)


IDEA = ExperimentStatus("idea")
DRAFTED = ExperimentStatus("drafted")
READY = ExperimentStatus("ready")
SUBMITTED = ExperimentStatus("submitted")
SCORED = ExperimentStatus("scored")
FAILED_PLATFORM = ExperimentStatus("failed_platform")
FAILED_BUNDLE = ExperimentStatus("failed_bundle")
PENDING_GPU = ExperimentStatus("pending_gpu")
RUNNING_GPU = ExperimentStatus("running_gpu")
DONE = ExperimentStatus("done")
LOCAL_ONLY = ExperimentStatus("local_only")
SUPERSEDED = ExperimentStatus("superseded")
REJECTED_STATUS = ExperimentStatus("rejected")
CURRENT = ExperimentStatus("current")


class Decision(str, Enum):
    ADOPTED = "adopted"
    REJECTED = "rejected"
    PENDING = "pending"
    NONE = ""


ARCH_ID = "ARCH"
COLUMNS = ["exp_id", "status", "date", "priority", "kernel_version", "bundle_hash", "lb_ref",
           "parent", "decision", "prompt", "input", "output", "feedback"]


def parse_score(text: str) -> float | None:
    trimmed = text.strip()
    try:
        return float(trimmed)
    except ValueError:
        pass
    m = _SCORE_RE.search(text)
    if not m:
        return None
    try:
        return float(m.group(1))
    except ValueError:
        return None


@dataclass
class ExperimentRecord:
    """One row of the Evidently `experiments` ledger. Every value is a string in the ledger."""

    exp_id: str
    status: ExperimentStatus
    date: str = ""
    priority: str = ""
    kernel_version: str = ""
    bundle_hash: str = ""
    lb_ref: str = ""
    parent: str = ""
    decision: Decision = Decision.NONE
    prompt: str = ""
    input: str = ""
    output: str = ""
    feedback: str = ""

    @classmethod
    def from_row(cls, row: dict[str, str]) -> "ExperimentRecord":
        return cls(
            exp_id=row.get("exp_id", ""),
            status=ExperimentStatus(row.get("status", "")),
            date=row.get("date", ""),
            priority=row.get("priority", ""),
            kernel_version=row.get("kernel_version", ""),
            bundle_hash=row.get("bundle_hash", ""),
            lb_ref=row.get("lb_ref", ""),
            parent=row.get("parent", ""),
            decision=Decision(row.get("decision", "")) if row.get("decision", "") in [d.value for d in Decision] else Decision.NONE,
            prompt=row.get("prompt", ""),
            input=row.get("input", ""),
            output=row.get("output", ""),
            feedback=row.get("feedback", ""),
        )

    @property
    def row(self) -> dict[str, str]:
        return {
            "exp_id": self.exp_id, "status": str(self.status), "date": self.date, "priority": self.priority,
            "kernel_version": self.kernel_version, "bundle_hash": self.bundle_hash, "lb_ref": self.lb_ref,
            "parent": self.parent, "decision": self.decision.value, "prompt": self.prompt,
            "input": self.input, "output": self.output, "feedback": self.feedback,
        }

    @property
    def priority_value(self) -> int | None:
        try:
            return int(self.priority.strip())
        except ValueError:
            return None

    @property
    def kernel_version_value(self) -> int | None:
        try:
            return int(self.kernel_version.strip())
        except ValueError:
            return None

    @property
    def public_score(self) -> float | None:
        return parse_score(self.output)

    @property
    def is_arch(self) -> bool:
        return self.exp_id == ARCH_ID

    @property
    def is_control(self) -> bool:
        return self.public_score is None and self.status in (SUBMITTED, READY)


@dataclass
class Ledger:
    """The experiments ledger: the newest `experiments ...` dataset in Evidently, all rows."""

    rows: list[ExperimentRecord] = field(default_factory=list)

    @classmethod
    def from_string_rows(cls, string_rows: list[dict[str, str]]) -> "Ledger":
        return cls(rows=[ExperimentRecord.from_row(r) for r in string_rows])

    @property
    def arch(self) -> ExperimentRecord | None:
        return next((r for r in self.rows if r.is_arch), None)

    def row(self, exp_id: str) -> ExperimentRecord | None:
        return next((r for r in self.rows if r.exp_id == exp_id), None)

    def __getitem__(self, exp_id: str) -> ExperimentRecord | None:
        return self.row(exp_id)

    def score(self, exp_id: str) -> float | None:
        r = self.row(exp_id)
        if r is not None:
            return r.public_score
        arch = self.arch
        if arch is not None and arch.parent == exp_id:
            return arch.public_score
        return None

    def ready_candidate(self, today: str) -> ExperimentRecord | None:
        candidates = [r for r in self.rows if r.status == READY]
        if not candidates:
            return None

        def key(r: ExperimentRecord):
            date_rank = 0 if r.date == today else 1
            priority = r.priority_value if r.priority_value is not None else 2**31
            return (date_rank, priority)

        return min(candidates, key=key)

    def next_idea(self) -> ExperimentRecord | None:
        candidates = [r for r in self.rows if r.status == IDEA and not self.is_duplicate_change(r)]
        if not candidates:
            return None
        return min(candidates, key=lambda r: r.priority_value if r.priority_value is not None else 2**31)

    def is_duplicate(self, bundle_hash: str) -> bool:
        h = bundle_hash.strip()
        if not h:
            return False
        return any(r.bundle_hash.endswith(h) and r.status != FAILED_PLATFORM for r in self.rows)

    def is_duplicate_change(self, candidate: ExperimentRecord) -> bool:
        statuses = {SCORED, SUBMITTED, REJECTED_STATUS, FAILED_BUNDLE, READY}
        return any(
            other.exp_id != candidate.exp_id and other.input == candidate.input and other.status in statuses
            for other in self.rows
        )

    @property
    def pending_decisions(self) -> list[ExperimentRecord]:
        return [r for r in self.rows if r.decision == Decision.PENDING]

    @property
    def pending_gpu(self) -> list[ExperimentRecord]:
        rows = [r for r in self.rows if r.status == PENDING_GPU]
        return sorted(rows, key=lambda r: r.priority_value if r.priority_value is not None else 2**31)

    @property
    def submitted_without_ref(self) -> list[ExperimentRecord]:
        return [r for r in self.rows if r.status == SUBMITTED and not r.lb_ref]

    def upsert(self, record: ExperimentRecord) -> None:
        for i, r in enumerate(self.rows):
            if r.exp_id == record.exp_id:
                self.rows[i] = record
                return
        self.rows.append(record)

    @property
    def string_rows(self) -> list[dict[str, str]]:
        return [r.row for r in self.rows]
