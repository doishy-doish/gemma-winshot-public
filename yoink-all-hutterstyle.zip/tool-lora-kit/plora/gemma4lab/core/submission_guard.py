from __future__ import annotations

import json
import re
from dataclasses import dataclass

from gemma4lab.core import competition, utc_day

TOKEN_LEAK_PATTERNS = [
    r"\bcat\b[^|;&]*(access_token|kaggle\.json)",
    r"\b(echo|printf)\b[^|;&]*\$\{?KAGGLE_API_TOKEN",
    r"\bprintenv\b[^|;&]*KAGGLE",
    r"\benv\b\s*\|\s*grep[^|;&]*-?i?[^|;&]*kaggle",
    r"\bset\b\s*\|\s*grep[^|;&]*kaggle",
]
KAGGLE_DELETE = r"\b(kg|kaggle)\b[^|;&]*\b(kernels|datasets|models)\b[^|;&]*\bdelete\b"
MESSAGE_PATTERN = r"^[A-Z]+[0-9]+[A-Za-z0-9]*:\s*\S"


@dataclass
class SubmissionLogEntry:
    utc_date: str
    timestamp: str
    exp_id: str
    kernel_version: str | None
    message: str

    @classmethod
    def parse_jsonl(cls, jsonl: str) -> list["SubmissionLogEntry"]:
        out = []
        for line in jsonl.split("\n"):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            out.append(cls(
                utc_date=row.get("utc_date", ""), timestamp=row.get("ts", ""),
                exp_id=row.get("exp_id", ""), kernel_version=row.get("kernel_version"),
                message=row.get("message", ""),
            ))
        return out


class Verdict:
    pass


@dataclass(frozen=True)
class Allowed(Verdict):
    def __bool__(self) -> bool:
        return True


@dataclass(frozen=True)
class Blocked(Verdict):
    reason: str

    def __bool__(self) -> bool:
        return False


ALLOWED = Allowed()


def is_blocked(verdict: Verdict) -> bool:
    return isinstance(verdict, Blocked)


def _matches(pattern: str, text: str, case_insensitive: bool = False) -> bool:
    flags = re.IGNORECASE if case_insensitive else 0
    return re.search(pattern, text, flags) is not None


def is_submit(command: str) -> bool:
    return _matches(r"\bcompetitions\s+submit\b", command) or "competition_submit_code" in command


def argument(cmd: str, *flags: str) -> str | None:
    for fl in flags:
        pattern = rf"(?:^|\s){re.escape(fl)}(?:\s+|=)(\"[^\"]*\"|'[^']*'|\S+)"
        m = re.search(pattern, cmd)
        if m:
            return m.group(1).strip("\"'")
    return None


def _daily_slot(log: list[SubmissionLogEntry], today: str) -> Verdict:
    done = [r for r in log if r.utc_date == today]
    if done:
        last = done[-1]
        return Blocked(
            f"a submission is already logged for UTC {today} ({last.exp_id} at {last.timestamp}). "
            "One per UTC day; a failed one still uses the slot."
        )
    return ALLOWED


def _check_submit(cmd: str, log: list[SubmissionLogEntry], today: str) -> Verdict:
    if "competition_submit_code" in cmd and not _matches(r"\bcompetitions\s+submit\b", cmd):
        if competition.SUBMISSION_FILE_NAME not in cmd or competition.SUBMISSION_KERNEL not in cmd:
            return Blocked(f"competition_submit_code must name `{competition.SUBMISSION_KERNEL}` and `submission.zip`.")
        return _daily_slot(log, today)
    fname = argument(cmd, "-f", "--file-name", "--file")
    if fname != competition.SUBMISSION_FILE_NAME:
        return Blocked("the competition output file must be exactly `submission.zip` (pass `-f submission.zip`).")
    kernel = argument(cmd, "-k", "--kernel")
    if kernel != competition.SUBMISSION_KERNEL:
        return Blocked(f"experiments are submitted only from the private kernel `{competition.SUBMISSION_KERNEL}` (got {kernel!r}).")
    if argument(cmd, "-v", "--version") is None:
        return Blocked("pin the kernel version with `-v <kernel_version>` from the ledger row.")
    msg = argument(cmd, "-m", "--message") or ""
    if not re.match(MESSAGE_PATTERN, msg):
        return Blocked('the message must be "<exp_id>: <short change>" so the LB entry maps back to a ledger row.')
    if competition.SLUG not in cmd:
        return Blocked(f"submit to `{competition.SLUG}` explicitly.")
    return _daily_slot(log, today)


def check(command: str, log: list[SubmissionLogEntry] | None = None, today: str | None = None) -> Verdict:
    """Port of `.claude/scripts/hooks/guard_kaggle.py` (pre mode): the hard rules applied to a shell
    command before it runs."""
    log = log or []
    today = today if today is not None else utc_day.today()
    for pat in TOKEN_LEAK_PATTERNS:
        if _matches(pat, command, case_insensitive=True):
            return Blocked("this would print the Kaggle token. Use `source ops/kenv.sh` and `kg`; never print credentials.")
    if _matches(KAGGLE_DELETE, command):
        return Blocked("deleting Kaggle items is not allowed from this project.")
    if is_submit(command):
        return _check_submit(command, log, today)
    return ALLOWED


def submit_command(exp_id: str, kernel_version: int, change: str) -> str:
    """The canonical, guard-compliant submit command for a ready ledger row."""
    message = f"{exp_id}: {change}".replace('"', "'")
    return (
        f"kg competitions submit {competition.SLUG} -k {competition.SUBMISSION_KERNEL} "
        f"-v {kernel_version} -f {competition.SUBMISSION_FILE_NAME} -m \"{message}\""
    )
