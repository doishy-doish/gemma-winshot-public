from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path

from gemma4lab.core import competition

_ADAPTER_LINE_RE = re.compile(r"^adapter:\s*main_lora\s*$", re.MULTILINE)
_MODEL_LINE_RE = re.compile(r"^(model:.*)$", re.MULTILINE)


class BundleError(Exception):
    pass


def _sorted_paths(keys) -> list[str]:
    return sorted(keys)


@dataclass
class AgentBundle:
    """The text files of a submission bundle, keyed by POSIX-relative path, plus whether the adapter ships with it.

    This is the unit ``ops/build_sub.py`` hashes, embeds in the submission notebook and verifies after the
    kernel runs. ``hash`` reproduces ``bundle_hash()`` byte for byte.
    """

    files: dict[str, str] = field(default_factory=dict)
    adapter: bool = False

    @classmethod
    def from_directory(cls, directory: str | Path, adapter: bool = False) -> "AgentBundle":
        root = Path(directory)
        if not root.is_dir():
            raise BundleError(f"not a directory: {root}")
        files: dict[str, str] = {}
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(root)
            if "__pycache__" in rel.parts:
                continue
            ext = path.suffix.lower()
            if ext not in competition.HASHED_EXTENSIONS:
                continue
            data = path.read_bytes()
            try:
                text = data.decode("utf-8")
            except UnicodeDecodeError:
                raise BundleError(f"{rel.as_posix()} is not UTF-8 text")
            files[rel.as_posix()] = text.replace("\r\n", "\n")
        if "agent.yaml" not in files:
            raise BundleError("bundle needs agent.yaml at its root")
        bundle = cls(files=files, adapter=adapter)
        if adapter:
            bundle.files["agent.yaml"] = with_adapter_line(bundle.files["agent.yaml"])
        return bundle

    @property
    def root_config(self) -> str | None:
        return self.files.get("agent.yaml")

    @property
    def sorted_paths(self) -> list[str]:
        return _sorted_paths(self.files.keys())

    @property
    def hash(self) -> str:
        return bundle_hash(self.files, self.adapter)

    @property
    def is_consistent(self) -> bool:
        y = self.root_config
        if y is None:
            return False
        has_line = "adapter: main_lora" in y
        return competition.MODEL in y and has_line == self.adapter

    def replacing(self, path: str, text: str) -> "AgentBundle":
        copy = AgentBundle(files=dict(self.files), adapter=self.adapter)
        copy.files[path] = text
        return copy

    def write(self, directory: str | Path) -> None:
        root = Path(directory)
        for rel, text in self.files.items():
            dest = root / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(text, encoding="utf-8")


def bundle_hash(files: dict[str, str], adapter: bool) -> str:
    h = hashlib.sha256()
    for key in _sorted_paths(files.keys()):
        h.update(key.encode("utf-8"))
        h.update(b"\0")
        h.update(files[key].encode("utf-8"))
        h.update(b"\0")
    h.update(b"adapter" if adapter else b"no-adapter")
    return h.hexdigest()[:16]


def with_adapter_line(yaml_text: str) -> str:
    """Insert `adapter: main_lora` after the first `model:` line unless already present."""
    if _ADAPTER_LINE_RE.search(yaml_text):
        return yaml_text
    m = _MODEL_LINE_RE.search(yaml_text)
    if not m:
        return yaml_text
    start, end = m.span(1)
    return yaml_text[:start] + m.group(1) + "\nadapter: main_lora" + yaml_text[end:]
