from __future__ import annotations

import json

JSONValue = None | bool | float | str | list["JSONValue"] | dict[str, "JSONValue"]


def parse(text: str | bytes) -> JSONValue:
    return json.loads(text)


def serialize(value: JSONValue, pretty: bool = False) -> str:
    """Compact JSON with keys sorted, the equivalent of Python's own
    `json.dumps(x, sort_keys=True, separators=(",", ":"))`."""
    if pretty:
        return json.dumps(value, sort_keys=True, indent=2)
    return json.dumps(value, sort_keys=True, separators=(",", ":"))
