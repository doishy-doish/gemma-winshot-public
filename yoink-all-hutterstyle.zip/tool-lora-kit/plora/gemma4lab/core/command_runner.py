from __future__ import annotations

import os
import subprocess
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Protocol


@dataclass
class CommandResult:
    exit_code: int
    stdout: str
    stderr: str

    @property
    def combined(self) -> str:
        return self.stdout + self.stderr

    @property
    def succeeded(self) -> bool:
        return self.exit_code == 0


class CommandRunning(Protocol):
    def run(self, executable: str, arguments: list[str],
            environment: dict[str, str] | None = None,
            current_directory: Path | None = None) -> CommandResult: ...


class CommandError(Exception):
    pass


class LaunchFailed(CommandError):
    def __init__(self, executable: str, why: str):
        super().__init__(f"could not launch {executable}: {why}")


class CommandFailed(CommandError):
    def __init__(self, result: CommandResult):
        super().__init__(f"command failed ({result.exit_code}): {result.combined[-500:]}")
        self.result = result


class ProcessRunner:
    """Runs a process through /usr/bin/env so PATH lookup matches the user's shell (uv, python3, curl)."""

    def run(self, executable: str, arguments: list[str],
            environment: dict[str, str] | None = None,
            current_directory: Path | None = None) -> CommandResult:
        env = dict(os.environ)
        if environment:
            env.update(environment)
        try:
            proc = subprocess.run(
                ["/usr/bin/env", executable, *arguments],
                env=env,
                cwd=str(current_directory) if current_directory else None,
                capture_output=True,
                text=True,
            )
        except OSError as e:
            raise LaunchFailed(executable, str(e))
        return CommandResult(exit_code=proc.returncode, stdout=proc.stdout, stderr=proc.stderr)


@dataclass
class _Call:
    executable: str
    arguments: list[str]

    @property
    def command_line(self) -> str:
        return " ".join([self.executable, *self.arguments])


class RecordingRunner:
    """A fake runner for tests and notebook dry runs: records every call and replays scripted results."""

    def __init__(self):
        self._lock = threading.Lock()
        self._calls: list[_Call] = []
        self._responses: list[tuple[Callable[[_Call], bool], CommandResult]] = []
        self.default_result = CommandResult(exit_code=0, stdout="", stderr="")

    @property
    def calls(self) -> list[_Call]:
        with self._lock:
            return list(self._calls)

    def respond_when(self, predicate: Callable[[_Call], bool], result: CommandResult) -> None:
        with self._lock:
            self._responses.append((predicate, result))

    def respond(self, containing: str, stdout: str, exit_code: int = 0) -> None:
        self.respond_when(lambda c: containing in c.command_line, CommandResult(exit_code=exit_code, stdout=stdout, stderr=""))

    def run(self, executable: str, arguments: list[str],
            environment: dict[str, str] | None = None,
            current_directory: Path | None = None) -> CommandResult:
        call = _Call(executable=executable, arguments=list(arguments))
        with self._lock:
            self._calls.append(call)
            for predicate, result in reversed(self._responses):
                if predicate(call):
                    return result
            return self.default_result
