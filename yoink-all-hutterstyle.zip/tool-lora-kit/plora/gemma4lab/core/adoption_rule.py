from __future__ import annotations

from dataclasses import dataclass

from gemma4lab.core import competition
from gemma4lab.core.experiment import (
    Decision, ExperimentRecord, Ledger, FAILED_BUNDLE, FAILED_PLATFORM,
    IDEA, DRAFTED, READY, ExperimentStatus,
)


@dataclass(frozen=True)
class Verdict:
    decision: Decision
    reason: str

    def __str__(self) -> str:
        return f"{self.decision.value}: {self.reason}"


def judge_scores(child_score: float | None, parent_score: float | None, arch_score: float | None = None) -> Verdict:
    """The strict adoption test: adopt only when the child's public LB score is strictly higher than its
    parent's (and not below the architecture). Ties are rejected. No noise margin, no re-runs."""
    if child_score is None:
        return Verdict(Decision.PENDING, "child has no public LB score yet")
    if parent_score is None:
        return Verdict(Decision.PENDING, "parent is an unscored control; submit it first")
    if child_score > parent_score:
        if arch_score is not None and child_score < arch_score:
            return Verdict(Decision.REJECTED, f"beats parent {parent_score:.3f} but is below ARCH {arch_score:.3f}")
        return Verdict(Decision.ADOPTED, f"{child_score:.3f} > {parent_score:.3f} (strictly higher)")
    if child_score == parent_score:
        return Verdict(Decision.REJECTED, f"tie at {child_score:.3f}; ties are rejected")
    return Verdict(Decision.REJECTED, f"{child_score:.3f} <= parent {parent_score:.3f}")


def judge(child: ExperimentRecord, ledger: Ledger) -> Verdict:
    """Judge a ledger row against its parent. `failed_bundle` is a rejection, `failed_platform` is not a result."""
    if child.status == FAILED_BUNDLE:
        return Verdict(Decision.REJECTED, "bundle error (for example over the 12 h limit)")
    if child.status == FAILED_PLATFORM:
        return Verdict(Decision.PENDING, "platform failure is not a result; resubmit the same build")
    parent_score = ledger.score(child.parent) if child.parent else None
    arch = ledger.arch
    return judge_scores(child.public_score, parent_score, arch.public_score if arch else None)


def tasks_between(a: float, b: float) -> int:
    return round(abs(a - b) / competition.score_quantum())


def is_within_observed_noise(a: float, b: float) -> bool:
    return tasks_between(a, b) <= competition.OBSERVED_RUN_NOISE_TASKS


@dataclass(frozen=True)
class UpdateArch:
    input: str
    score: float
    parent: str

    def __str__(self) -> str:
        return f"ARCH <- {self.parent} ({self.score:.2f}): {self.input}"


@dataclass(frozen=True)
class SetDecision:
    exp_id: str
    decision: Decision

    def __str__(self) -> str:
        return f"{self.exp_id}.decision = {self.decision.value}"


@dataclass(frozen=True)
class RewriteInput:
    exp_id: str

    def __str__(self) -> str:
        return f"rewrite input of {self.exp_id} on the new ARCH"


@dataclass(frozen=True)
class Rebuild:
    exp_id: str

    def __str__(self) -> str:
        return f"rebuild ready candidate {self.exp_id} on the new ARCH"


@dataclass(frozen=True)
class Supersede:
    exp_id: str

    def __str__(self) -> str:
        return f"{self.exp_id} -> superseded"


@dataclass(frozen=True)
class SuggestShorterBudget:
    current_minutes: float

    def __str__(self) -> str:
        return f"next idea: shorter budget than {self.current_minutes} min"


LedgerEdit = UpdateArch | SetDecision | RewriteInput | Rebuild | Supersede | SuggestShorterBudget


def edits(child: ExperimentRecord, verdict: Verdict, ledger: Ledger,
          redundant_ideas: list[str] | None = None, over_time: bool = False,
          current_minutes: float | None = None) -> list[LedgerEdit]:
    """Turns a verdict into the concrete ledger edits the daily loop performs (DAILY.md step 4)."""
    redundant_ideas = redundant_ideas or []
    out: list[LedgerEdit] = [SetDecision(child.exp_id, verdict.decision)]
    if verdict.decision == Decision.ADOPTED:
        if child.public_score is not None:
            out.append(UpdateArch(child.input, child.public_score, child.exp_id))
        for row in ledger.rows:
            if row.exp_id == child.exp_id:
                continue
            if row.status in (IDEA, DRAFTED):
                out.append(Supersede(row.exp_id) if row.exp_id in redundant_ideas else RewriteInput(row.exp_id))
            elif row.status == READY:
                if not row.is_control or row.parent != child.parent:
                    out.append(RewriteInput(row.exp_id))
                    out.append(Rebuild(row.exp_id))
    elif verdict.decision == Decision.REJECTED:
        if over_time and current_minutes is not None:
            out.append(SuggestShorterBudget(current_minutes))
    return out


def apply_edits(edit_list: list[LedgerEdit], ledger: Ledger, today: str) -> tuple[Ledger, list[LedgerEdit]]:
    """Apply the mechanical edits (decision, ARCH row) to a ledger copy. Rewrites, rebuilds and supersessions
    need human/agent judgement about the new wording, so they are returned as work items instead."""
    l = Ledger(rows=list(ledger.rows))
    work: list[LedgerEdit] = []
    for e in edit_list:
        if isinstance(e, SetDecision):
            r = l.row(e.exp_id)
            if r is not None:
                r.decision = e.decision
                l.upsert(r)
        elif isinstance(e, UpdateArch):
            arch = l.arch or ExperimentRecord(
                exp_id="ARCH", status=ExperimentStatus("current"),
                prompt="Current architecture (champion). Every experiment = this + exactly one change.",
            )
            arch.input = e.input
            arch.output = f"LB {e.score:.2f}"
            arch.parent = e.parent
            arch.date = today
            arch.status = ExperimentStatus("current")
            l.upsert(arch)
        elif isinstance(e, Supersede):
            r = l.row(e.exp_id)
            if r is not None:
                r.status = ExperimentStatus("superseded")
                l.upsert(r)
        else:
            work.append(e)
    return l, work
