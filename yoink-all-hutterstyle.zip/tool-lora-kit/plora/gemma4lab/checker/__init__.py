from __future__ import annotations

"""Wraps the real static bundle checker, ``dataset/tools/check_submission.py``.

The Swift ``Gemma4Checker`` module (``BundleChecker``) was only a *partial* port of this script: it
deliberately skips the lexical prompt-hygiene scans (~70 check ids) that the Python checker still runs.
Re-deriving a second, weaker copy in this package would be a regression, so ``gemma4lab.checker`` calls
straight into the real script and exposes a small, stable Python API (``check_bundle``, ``CheckReport``)
in front of it, matching the names the Swift ``Gemma4Checker`` types used so other modules in this package
have one import path regardless of what is behind it.
"""

from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace

from gemma4lab._external import check_submission as _check_submission


@dataclass
class CheckReport:
    """A thin view over ``check_submission.Report.results``: ``{check_id: {"status", "details"}}``."""

    results: dict[str, dict]

    @property
    def failures(self) -> list[str]:
        return [k for k, v in self.results.items() if v["status"] == "fail"]

    @property
    def warnings(self) -> list[str]:
        return [k for k, v in self.results.items() if v["status"] == "warn"]

    @property
    def passed(self) -> list[str]:
        return [k for k, v in self.results.items() if v["status"] == "pass"]

    @property
    def summary(self) -> str:
        counts: dict[str, int] = {}
        for entry in self.results.values():
            counts[entry["status"]] = counts.get(entry["status"], 0) + 1
        return ", ".join(f"{status}={n}" for status, n in sorted(counts.items()))


def check_bundle(directory: str | Path, use_yaml_lib: bool = True, allow_dotdot: bool = False) -> CheckReport:
    """Run every static check against a bundle directory, the equivalent of
    ``python3 -I dataset/tools/check_submission.py BUNDLE``."""
    args = SimpleNamespace(
        bundle=str(directory), no_yaml_lib=not use_yaml_lib, allow_dotdot=allow_dotdot,
        zip_out=None, kit=None, run_script=None, checklist=None, report=None, strict=False, summary=False,
    )
    report, _bundle = _check_submission.run_checks(args)
    return CheckReport(results=report.results)


def deterministic_zip(directory: str | Path, use_yaml_lib: bool = True) -> bytes:
    """What the kernel's submission.zip step produces: a deterministic zip of the bundle's files."""
    args = SimpleNamespace(
        bundle=str(directory), no_yaml_lib=not use_yaml_lib, allow_dotdot=False,
        zip_out=None, kit=None, run_script=None, checklist=None, report=None, strict=False, summary=False,
    )
    _report, bundle = _check_submission.run_checks(args)
    return _check_submission.deterministic_zip(bundle)


__all__ = ["CheckReport", "check_bundle", "deterministic_zip"]
