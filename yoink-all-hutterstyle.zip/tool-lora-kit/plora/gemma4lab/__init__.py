"""gemma4lab: the Python port of Gemma4LabKit for the gemma4-tool-lora-rebuild project.

Submodules: core (competition rules, bundle hashing, ledger, submission guard), checker (wraps
dataset/tools/check_submission.py), training (recipe, schedule, tool-call format, gates), ledger
(Evidently client/bridge/snapshot), kaggle (kg CLI wrapper, submission notebook, build state),
plora (the PLoRA paper reproduction: memory/cost models, planner, benchmarks), viz (palette + plot
helpers), yaml_mini (the bundle's restrictive YAML subset), workspace (repo-relative paths)."""

from gemma4lab import workspace
from gemma4lab.workspace import Workspace
from gemma4lab.yaml_mini import MiniYAML, YAMLProblem

__all__ = ["workspace", "Workspace", "MiniYAML", "YAMLProblem"]
