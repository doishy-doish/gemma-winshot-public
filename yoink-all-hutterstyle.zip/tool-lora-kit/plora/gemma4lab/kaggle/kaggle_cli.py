from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

from gemma4lab.core import competition, utc_day
from gemma4lab.core.command_runner import CommandResult, CommandRunning, ProcessRunner
from gemma4lab.core.submission_guard import SubmissionLogEntry, is_blocked, check as guard_check

TOOL_ARGUMENTS = ["tool", "run", "--python", "3.12", "--from", "kaggle>=1.8", "kaggle"]


class KaggleError(Exception):
    pass


class CredentialsNotFound(KaggleError):
    def __init__(self, path: str):
        super().__init__(f"Kaggle credentials not found at {path} (run `source ops/kenv.sh` first)")


class BlockedByGuard(KaggleError):
    def __init__(self, why: str):
        super().__init__(f"blocked by the submission guard: {why}")


class PushFailed(KaggleError):
    def __init__(self, output: str):
        super().__init__(f"kernel push failed: {output[-400:]}")


class KaggleCommandFailed(KaggleError):
    def __init__(self, result: CommandResult):
        super().__init__(f"kaggle command failed ({result.exit_code}): {result.combined[-400:]}")
        self.result = result


class KernelStatus(str, Enum):
    COMPLETE = "complete"
    RUNNING = "running"
    QUEUED = "queued"
    ERROR = "error"
    CANCELLED = "cancelled"

    @classmethod
    def parse(cls, output: str) -> "KernelStatus | str":
        up = output.upper()
        if "COMPLETE" in up:
            return cls.COMPLETE
        if "RUNNING" in up:
            return cls.RUNNING
        if "QUEUED" in up:
            return cls.QUEUED
        if "ERROR" in up:
            return cls.ERROR
        if "CANCEL" in up:
            return cls.CANCELLED
        return output.strip()

    @staticmethod
    def is_finished(status) -> bool:
        return status in (KernelStatus.COMPLETE, KernelStatus.ERROR, KernelStatus.CANCELLED)


_PUSH_RE = re.compile(r"Kernel version (\d+) successfully pushed")


@dataclass(frozen=True)
class KernelPushResult:
    version: int
    output: str

    @classmethod
    def parse(cls, output: str) -> "KernelPushResult":
        m = _PUSH_RE.search(output)
        if not m:
            raise PushFailed(output)
        return cls(version=int(m.group(1)), output=output)


_EXP_ID_RE = re.compile(r"^[A-Z]+[0-9]+[A-Za-z0-9]*$")


def _split_csv_line(line: str) -> list[str]:
    out: list[str] = []
    cur = ""
    quoted = False
    for ch in line:
        if ch == '"':
            quoted = not quoted
        elif ch == "," and not quoted:
            out.append(cur)
            cur = ""
        else:
            cur += ch
    out.append(cur)
    return out


@dataclass(frozen=True)
class LeaderboardSubmission:
    """A row of `kaggle competitions submissions <slug>` output."""

    ref: str
    file_name: str
    date: str
    description: str
    status: str
    public_score: float | None

    @property
    def exp_id(self) -> str | None:
        """Experiment id from a "<exp_id>: <change>" description."""
        if ":" not in self.description:
            return None
        candidate = self.description.split(":", 1)[0].strip()
        return candidate if _EXP_ID_RE.match(candidate) else None

    @property
    def is_scored(self) -> bool:
        return self.public_score is not None

    @property
    def threw_exception(self) -> bool:
        status = self.status.lower()
        return "exception" in status or "error" in status

    @classmethod
    def parse_csv(cls, text: str) -> list["LeaderboardSubmission"]:
        """Parse the CSV form (`--csv`) with a header row; `ref` is taken from a `ref` column when
        present."""
        lines = [ln for ln in text.split("\n") if ln]
        if not lines:
            return []
        cols = [c.lower() for c in _split_csv_line(lines[0])]

        def idx(name: str) -> int | None:
            name = name.lower()
            return cols.index(name) if name in cols else None

        out = []
        for line in lines[1:]:
            f = _split_csv_line(line)

            def at(name: str) -> str:
                i = idx(name)
                return f[i] if i is not None and i < len(f) else ""

            score_text = at("publicScore") or at("publicscore")
            try:
                score = float(score_text) if score_text else None
            except ValueError:
                score = None
            out.append(cls(
                ref=at("ref"), file_name=at("fileName") or at("filename"), date=at("date"),
                description=at("description"), status=at("status"), public_score=score,
            ))
        return out


@dataclass
class KaggleCLI:
    """`kg`: the Kaggle CLI through `uv tool run --python 3.12 --from 'kaggle>=1.8' kaggle ...`,
    configured like `ops/kenv.sh` (session-local config dir, token read from `access_token` into the
    environment, never printed)."""

    runner: CommandRunning = field(default_factory=ProcessRunner)
    config_directory: Path = field(default_factory=lambda: Path.home() / "kcfg")
    guard_log: list[SubmissionLogEntry] = field(default_factory=list)

    def _environment(self) -> dict[str, str]:
        token_file = self.config_directory / "access_token"
        if not token_file.is_file():
            raise CredentialsNotFound(str(token_file))
        token = token_file.read_text().strip()
        return {"KAGGLE_CONFIG_DIR": str(self.config_directory), "KAGGLE_API_TOKEN": token}

    def kg(self, arguments: list[str], today: str | None = None) -> CommandResult:
        """Run any `kaggle` subcommand. The guard runs first on the equivalent shell line so the hard
        rules hold here too."""
        today = today or utc_day.today()
        shell_line = "kg " + " ".join(f'"{a}"' if " " in a else a for a in arguments)
        verdict = guard_check(shell_line, log=self.guard_log, today=today)
        if is_blocked(verdict):
            raise BlockedByGuard(verdict.reason)
        return self.runner.run("uv", TOOL_ARGUMENTS + arguments, environment=self._environment())

    def kernels_push(self, directory: str | Path, accelerator: str | None = None) -> KernelPushResult:
        args = ["kernels", "push", "-p", str(directory)]
        if accelerator:
            args += ["--accelerator", accelerator]
        return KernelPushResult.parse(self.kg(args).combined)

    def kernels_status(self, kernel: str = competition.SUBMISSION_KERNEL):
        return KernelStatus.parse(self.kg(["kernels", "status", kernel]).combined)

    def kernels_output(self, kernel: str = competition.SUBMISSION_KERNEL, to: str | Path = ".") -> CommandResult:
        Path(to).mkdir(parents=True, exist_ok=True)
        return self.kg(["kernels", "output", kernel, "-p", str(to)])

    def competitions_submissions(self) -> list[LeaderboardSubmission]:
        return LeaderboardSubmission.parse_csv(self.kg(["competitions", "submissions", competition.SLUG, "--csv"]).stdout)

    def competition_submit(self, exp_id: str, kernel_version: int, change: str, today: str | None = None) -> CommandResult:
        """The one guarded submission of the day. Builds the canonical command so the guard's checks
        all apply."""
        message = f"{exp_id}: {change}"
        return self.kg([
            "competitions", "submit", competition.SLUG, "-k", competition.SUBMISSION_KERNEL,
            "-v", str(kernel_version), "-f", competition.SUBMISSION_FILE_NAME, "-m", message,
        ], today=today)

    def datasets_version(self, directory: str | Path, message: str) -> CommandResult:
        return self.kg(["datasets", "version", "-p", str(directory), "-m", message, "--dir-mode", "zip"])
