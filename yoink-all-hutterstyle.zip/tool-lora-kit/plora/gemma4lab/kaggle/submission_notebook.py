from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from gemma4lab.core import competition
from gemma4lab.core.agent_bundle import AgentBundle

QUAD_L4_ACCELERATOR = "NvidiaL4"


@dataclass
class KernelMetadata:
    """`kernel-metadata.json` for a kernel push."""

    id: str
    title: str
    code_file: str
    language: str = "python"
    kernel_type: str = "notebook"
    is_private: bool = True
    enable_gpu: bool = False
    enable_tpu: bool = False
    enable_internet: bool = False
    dataset_sources: list[str] = field(default_factory=list)
    competition_sources: list[str] = field(default_factory=lambda: [competition.SLUG])
    kernel_sources: list[str] = field(default_factory=list)
    model_sources: list[str] = field(default_factory=list)
    docker_image: str | None = None

    @classmethod
    def submission(cls, adapter: bool) -> "KernelMetadata":
        """The private submission kernel: CPU, no internet, competition attached, adapter model
        attached when needed."""
        return cls(
            id=competition.SUBMISSION_KERNEL, title="gemma4-agent-submission",
            code_file="gemma4-agent-submission.ipynb",
            model_sources=[competition.ADAPTER_MODEL_SOURCE] if adapter else [],
        )

    @classmethod
    def gpu_kernel(cls, id: str, title: str, code_file: str, model_sources: list[str], docker_image: str,
                   wheelhouse: bool = True, kernel_sources: list[str] | None = None) -> "KernelMetadata":
        """The GPU kernels of this project (`kernels/{train,sample,evalbase,evaladapter}`): 4x L4
        needs the competition attached, internet off and the pinned docker image already in the
        metadata."""
        return cls(
            id=id, title=title, code_file=code_file, enable_gpu=True,
            dataset_sources=["metric/gemma-4-developer-agent-wheelhouse"] if wheelhouse else [],
            kernel_sources=kernel_sources or [], model_sources=model_sources, docker_image=docker_image,
        )

    def to_json(self) -> str:
        d = {
            "id": self.id, "title": self.title, "code_file": self.code_file, "language": self.language,
            "kernel_type": self.kernel_type, "is_private": self.is_private, "enable_gpu": self.enable_gpu,
            "enable_tpu": self.enable_tpu, "enable_internet": self.enable_internet,
            "dataset_sources": self.dataset_sources, "competition_sources": self.competition_sources,
            "kernel_sources": self.kernel_sources, "model_sources": self.model_sources,
            "docker_image": self.docker_image,
        }
        return json.dumps(d, indent=2, sort_keys=True)


_CODE_TEMPLATE = '''import glob, hashlib, json, shutil, zipfile
from pathlib import Path
EXP, ADAPTER = {exp!r}, {adapter!r}
FILES = json.loads({files_literal!r})
stage = Path("/kaggle/working/bundle")
for rel, text in FILES.items():
    p = stage / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text)
if ADAPTER:
    cfg = sorted(glob.glob("/kaggle/input/**/adapter_config.json", recursive=True))
    assert cfg, "attach the adapter model"
    d = stage / "adapters/main_lora"; d.mkdir(parents=True, exist_ok=True)
    for n in ("adapter_config.json", "adapter_model.safetensors"): shutil.copyfile(Path(cfg[0]).parent / n, d / n)
files = sorted(p for p in stage.rglob("*") if p.is_file())
y = (stage / "agent.yaml").read_text()
assert {model!r} in y and (("adapter: main_lora" in y) == ADAPTER)
zp = Path("/kaggle/working/submission.zip")
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for p in files:
        zi = zipfile.ZipInfo(p.relative_to(stage).as_posix(), date_time=(2026, 1, 1, 0, 0, 0))
        zi.compress_type, zi.external_attr = zipfile.ZIP_DEFLATED, 0o644 << 16
        z.writestr(zi, p.read_bytes())
shutil.rmtree(stage)
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None and "agent.yaml" in z.namelist()
    for i in z.infolist(): print(f"{{i.file_size:>12}}  {{i.filename}}")
print(EXP, "submission.zip sha256", hashlib.sha256(zp.read_bytes()).hexdigest()[:16])
print(y)
'''


@dataclass
class SubmissionNotebook:
    """Builds the notebook `ops/build_sub.py push` uploads: one markdown cell and one code cell that
    re-creates the bundle's text files on the kernel, optionally copies the adapter from the attached
    model, zips deterministically to `/kaggle/working/submission.zip`, then verifies and prints the
    listing and the zip's sha256 prefix."""

    exp_id: str
    bundle: AgentBundle

    @property
    def code(self) -> str:
        files_json = json.dumps(self.bundle.files, sort_keys=True, separators=(",", ":"))
        return _CODE_TEMPLATE.format(
            exp=self.exp_id, adapter=self.bundle.adapter, files_literal=files_json, model=competition.MODEL,
        )

    def notebook_json(self) -> bytes:
        """nbformat 4 notebook JSON."""
        nb = {
            "cells": [
                {
                    "cell_type": "markdown", "id": "m0", "metadata": {},
                    "source": f"# Gemma 4 Developer Agent: submission `{self.exp_id}`\nWrites `/kaggle/working/submission.zip`.",
                },
                {"cell_type": "code", "id": "c0", "metadata": {}, "execution_count": None, "outputs": [], "source": self.code},
            ],
            "metadata": {"kernelspec": {"name": "python3", "display_name": "Python 3", "language": "python"}, "language_info": {"name": "python"}},
            "nbformat": 4, "nbformat_minor": 5,
        }
        return json.dumps(nb, sort_keys=True).encode("utf-8")

    @property
    def metadata(self) -> KernelMetadata:
        return KernelMetadata.submission(adapter=self.bundle.adapter)

    def write(self, push_directory: str | Path) -> None:
        """Write `gemma4-agent-submission.ipynb` + `kernel-metadata.json` into an empty push
        directory."""
        d = Path(push_directory)
        d.mkdir(parents=True, exist_ok=True)
        for f in d.glob("*"):
            if f.is_file():
                f.unlink()
        (d / self.metadata.code_file).write_bytes(self.notebook_json())
        (d / "kernel-metadata.json").write_text(self.metadata.to_json())
