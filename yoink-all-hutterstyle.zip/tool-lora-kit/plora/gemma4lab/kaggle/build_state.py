from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from dataclasses import dataclass, field
from io import BytesIO
from pathlib import Path

from gemma4lab.core import competition
from gemma4lab.core.agent_bundle import AgentBundle, bundle_hash
from gemma4lab.kaggle.kaggle_cli import KaggleCLI, KaggleError
from gemma4lab.kaggle.submission_notebook import SubmissionNotebook


@dataclass
class BuildState:
    """`ops/experiments/<exp_id>/build.json`: what was pushed and, after verification, what came
    back."""

    exp_id: str
    bundle_dir: str
    adapter: bool
    bundle_hash: str
    version: int
    files: list[str]
    kernel: str = competition.SUBMISSION_KERNEL
    zip_sha256: str | None = None
    zip_files: list[str] | None = None
    verified: bool | None = None

    @classmethod
    def from_file(cls, path: str | Path) -> "BuildState":
        data = json.loads(Path(path).read_text())
        return cls(
            exp_id=data["exp_id"], bundle_dir=data["bundle_dir"], adapter=data["adapter"],
            bundle_hash=data["bundle_hash"], kernel=data.get("kernel", competition.SUBMISSION_KERNEL),
            version=data["version"], files=data["files"], zip_sha256=data.get("zip_sha256"),
            zip_files=data.get("zip_files"), verified=data.get("verified"),
        )

    def write(self, path: str | Path) -> None:
        dest = Path(path)
        dest.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "exp_id": self.exp_id, "bundle_dir": self.bundle_dir, "adapter": self.adapter,
            "bundle_hash": self.bundle_hash, "kernel": self.kernel, "version": self.version,
            "files": self.files, "zip_sha256": self.zip_sha256, "zip_files": self.zip_files,
            "verified": self.verified,
        }
        dest.write_text(json.dumps(payload, indent=1, sort_keys=True))

    @property
    def is_ready(self) -> bool:
        """The ledger fields a `ready` row records from a verified build."""
        return self.verified is True


@dataclass(frozen=True)
class VerifyOutcome:
    bundle_hash: str
    has_adapter: bool
    zip_sha256: str
    names: list[str]
    matches: bool


def verify_zip(zip_data: bytes, against: BuildState) -> VerifyOutcome:
    """Checks a downloaded `submission.zip` against the pushed state (`build_sub.py verify`)."""
    with zipfile.ZipFile(BytesIO(zip_data)) as z:
        names = z.namelist()
        files: dict[str, str] = {}
        for name in names:
            ext = "." + Path(name).suffix.lower().lstrip(".")
            if ext not in competition.HASHED_EXTENSIONS or name.startswith("adapters/"):
                continue
            files[name] = z.read(name).decode("utf-8")
        has_adapter = "adapters/main_lora/adapter_model.safetensors" in names
    got = bundle_hash(files, has_adapter)
    zip_sha256 = hashlib.sha256(zip_data).hexdigest()[:16]
    matches = got == against.bundle_hash and has_adapter == against.adapter
    return VerifyOutcome(bundle_hash=got, has_adapter=has_adapter, zip_sha256=zip_sha256, names=names, matches=matches)


def expected_archive(bundle: AgentBundle) -> bytes:
    """Build the zip the kernel would produce for a bundle (kernel style: 2026-01-01 timestamps,
    mode 0644). Adapter weights are not available locally, so an adapter bundle's zip here lacks
    `adapters/`."""
    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in bundle.sorted_paths:
            zi = zipfile.ZipInfo(rel, date_time=(2026, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, bundle.files[rel].encode("utf-8"))
    return buf.getvalue()


@dataclass
class ExperimentBuilder:
    """Orchestrates push -> wait -> verify for one experiment, writing `build.json` like the Python
    script."""

    kaggle: KaggleCLI
    experiments_directory: Path
    push_directory: Path = field(default_factory=lambda: Path.home() / "push_exp")
    output_directory: Path = field(default_factory=lambda: Path.home() / "tmp")

    def state_path(self, exp_id: str) -> Path:
        return self.experiments_directory / exp_id / "build.json"

    def push(self, exp_id: str, bundle_directory: str | Path, adapter: bool) -> BuildState:
        """`build_sub.py push <exp_id> <bundle_dir> [--adapter]`: write the notebook, push a new
        kernel version, record state."""
        bundle = AgentBundle.from_directory(bundle_directory, adapter=adapter)
        notebook = SubmissionNotebook(exp_id=exp_id, bundle=bundle)
        notebook.write(self.push_directory)
        result = self.kaggle.kernels_push(self.push_directory)
        state = BuildState(
            exp_id=exp_id, bundle_dir=str(Path(bundle_directory).resolve()), adapter=adapter,
            bundle_hash=bundle.hash, version=result.version, files=bundle.sorted_paths,
        )
        state.write(self.state_path(exp_id))
        return state

    def verify(self, exp_id: str) -> tuple[BuildState, VerifyOutcome]:
        """`build_sub.py verify <exp_id>`: download the kernel output and compare the zip with the
        pushed bundle."""
        state = BuildState.from_file(self.state_path(exp_id))
        out = self.output_directory / f"out_{exp_id}"
        shutil.rmtree(out, ignore_errors=True)
        self.kaggle.kernels_output(state.kernel, to=out)
        zip_path = out / competition.SUBMISSION_FILE_NAME
        if not zip_path.is_file():
            raise KaggleError("no submission.zip in the kernel output (still running, or it failed: read the log)")
        outcome = verify_zip(zip_path.read_bytes(), against=state)
        state.zip_sha256 = outcome.zip_sha256
        state.zip_files = outcome.names
        state.verified = outcome.matches
        state.write(self.state_path(exp_id))
        return state, outcome
