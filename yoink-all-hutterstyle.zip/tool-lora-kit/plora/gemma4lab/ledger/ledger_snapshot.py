from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from gemma4lab.core.experiment import ExperimentRecord, Ledger
from gemma4lab.ledger.payloads import PayloadKind


def _loose_string(value) -> str:
    """Values are strings in practice, but be lenient with numbers/nulls from older uploads."""
    if isinstance(value, str):
        return value
    if isinstance(value, bool):
        return "True" if value else "False"
    if isinstance(value, (int, float)):
        return str(int(value)) if float(value) == int(value) else str(value)
    return ""


@dataclass
class EvidentlyDataset:
    """One Evidently dataset as `ops/ev_read.py` dumps it: `experiments ...`, `prompts ...`,
    `trace ...` or `datasets ...`."""

    id: str
    name: str
    created_at: str
    columns: list[str]
    rows: list[dict[str, str]]

    @classmethod
    def from_json(cls, data: dict) -> "EvidentlyDataset":
        loose_rows = data.get("rows", [])
        rows = [{k: _loose_string(v) for k, v in row.items()} for row in loose_rows]
        return cls(
            id=data["id"], name=data["name"], created_at=data.get("created_at", ""),
            columns=data.get("columns", []), rows=rows,
        )

    @property
    def kind(self) -> PayloadKind | None:
        for k in PayloadKind:
            if self.name.startswith(k.value):
                return k
        return None


@dataclass
class LedgerSnapshot:
    """The whole project history (`ops/ledger_cache/evh_<date>.json`, `ev_history.json`)."""

    project: str
    url: str
    datasets: list[EvidentlyDataset] = field(default_factory=list)

    @classmethod
    def from_json(cls, data: dict) -> "LedgerSnapshot":
        return cls(
            project=data.get("project", ""), url=data.get("url", ""),
            datasets=[EvidentlyDataset.from_json(d) for d in data.get("datasets", [])],
        )

    @classmethod
    def from_file(cls, path: str | Path) -> "LedgerSnapshot":
        return cls.from_json(json.loads(Path(path).read_text()))

    @property
    def ordered(self) -> list[EvidentlyDataset]:
        """Datasets in creation order (the server list is sorted by `created_at` in ev_read.py)."""
        return sorted(self.datasets, key=lambda d: d.created_at)

    def datasets_of(self, kind: PayloadKind) -> list[EvidentlyDataset]:
        return [d for d in self.ordered if d.kind == kind]

    @property
    def latest_ledger_dataset(self) -> EvidentlyDataset | None:
        """The newest `experiments` dataset is authoritative; older ones are history."""
        exps = self.datasets_of(PayloadKind.EXPERIMENTS)
        return exps[-1] if exps else None

    @property
    def latest_ledger(self) -> Ledger | None:
        d = self.latest_ledger_dataset
        return Ledger.from_string_rows(d.rows) if d else None

    @property
    def insight_rows(self) -> list[dict[str, str]]:
        """Every prompt/feedback row across all `prompts` and `trace` datasets, oldest first."""
        out = []
        for d in self.ordered:
            if d.kind in (PayloadKind.PROMPTS, PayloadKind.TRACE):
                out.extend(d.rows)
        return out

    def digest(self, max_rows: int | None = None) -> str:
        """The digest `ev_read.py` prints: ledger rows, then prompt/trace rows, then other dataset
        summaries."""
        limit = max_rows if max_rows is not None else len(self.ordered) * 10**9
        out = [f"{len(self.datasets)} datasets  ({self.url})"]
        exps = self.datasets_of(PayloadKind.EXPERIMENTS)
        if exps:
            d = exps[-1]
            older = [e.name for e in exps[:-1]]
            out.append("")
            out.append(f"== LATEST LEDGER {d.name} ({len(d.rows)} rows); older ledgers: {older}")
            for r in d.rows[:limit]:
                rec = ExperimentRecord.from_row(r)
                out.append(
                    f"{rec.exp_id:<6} {str(rec.status):<15} {rec.date:<10} p{rec.priority} v{rec.kernel_version} "
                    f"{rec.bundle_hash} lb={rec.lb_ref} parent={rec.parent} {rec.decision.value} | "
                    f"{rec.input[:90]} | {rec.output[:60]}"
                )
        for d in self.ordered:
            if d.kind in (PayloadKind.PROMPTS, PayloadKind.TRACE):
                out.append("")
                out.append(f"== {d.name}")
                for r in d.rows[:limit]:
                    out.append(f"- {r.get('input', '')[:90]} | {r.get('output', '')[:160]} | {r.get('feedback', '')[:200]}")
            elif d.kind != PayloadKind.EXPERIMENTS:
                out.append("")
                out.append(f"== {d.name}: {len(d.rows)} rows, columns {d.columns}")
        return "\n".join(out)
