from __future__ import annotations

import json
import urllib.request
from pathlib import Path
from dataclasses import dataclass, field

from gemma4lab.core import utc_day
from gemma4lab.ledger.ledger_snapshot import EvidentlyDataset, LedgerSnapshot

DEFAULT_BASE_URLS = ["http://cloudfronts.group:8000", "http://192.168.0.15:8000"]
PROJECT_NAME = "gemma-4-developer-agent"


class EvidentlyError(Exception):
    pass


def _get(base: str, path: str, timeout: float = 60):
    with urllib.request.urlopen(base + path, timeout=timeout) as r:
        return json.loads(r.read())


def _cell(v) -> str:
    if isinstance(v, str):
        return v
    if isinstance(v, bool):
        return "True" if v else "False"
    if isinstance(v, (int, float)):
        return str(int(v)) if float(v) == int(v) else str(v)
    if v is None:
        return ""
    return json.dumps(v, sort_keys=True, separators=(",", ":"))


@dataclass
class EvidentlyClient:
    """Read-only client for the Evidently server (the write path goes through the Python pack/send
    scripts because it needs parquet). Reachable from the user's machine only; the first URL that
    answers wins, like `ev_read.py`."""

    base_urls: list[str] = field(default_factory=lambda: list(DEFAULT_BASE_URLS))
    project_name: str = PROJECT_NAME
    page_size: int = 500

    def connect(self) -> tuple[str, list[dict]]:
        """First reachable base URL and its project list."""
        for base in self.base_urls:
            try:
                projects = _get(base, "/api/v2/projects")
                return base, projects
            except Exception:
                continue
        raise EvidentlyError(f"no Evidently server reachable: {self.base_urls}")

    def fetch_snapshot(self) -> LedgerSnapshot:
        """Download every dataset of the project with all rows, the equivalent of
        `python3 ops/ev_read.py`."""
        base, projects = self.connect()
        pid = next((p["id"] for p in projects if p.get("name") == self.project_name), None)
        if pid is None:
            raise EvidentlyError(f"Evidently project '{self.project_name}' not found")
        listing = _get(base, f"/api/datasets?project_id={pid}")["datasets"]
        out: list[EvidentlyDataset] = []
        for d in sorted(listing, key=lambda d: d.get("created_at", "")):
            rows: list[dict[str, str]] = []
            cols: list[str] = []
            page = 1
            while True:
                b = _get(base, f"/api/datasets/{d['id']}?page_size={self.page_size}&current_page={page}")
                cols = [c["name"] for c in b["metadata"]["columns"]]
                rows += [dict(zip(cols, [_cell(v) for v in item])) for item in b["items"]]
                if page >= b["total_pages"]:
                    break
                page += 1
            out.append(EvidentlyDataset(id=d["id"], name=d.get("name", ""), created_at=d.get("created_at", ""), columns=cols, rows=rows))
        return LedgerSnapshot(project=pid, url=f"{base}/projects/{pid}/datasets", datasets=out)

    def fetch_and_cache(self, cache_directory, today: str | None = None) -> LedgerSnapshot:
        """Fetch and cache under `ops/ledger_cache/evh_<today>.json`, returning the snapshot."""
        today = today or utc_day.today()
        snap = self.fetch_snapshot()
        cache_dir = Path(cache_directory)
        cache_dir.mkdir(parents=True, exist_ok=True)
        data = {
            "project": snap.project, "url": snap.url,
            "datasets": [
                {"id": d.id, "name": d.name, "created_at": d.created_at, "columns": d.columns, "rows": d.rows}
                for d in snap.datasets
            ],
        }
        (cache_dir / f"evh_{today}.json").write_text(json.dumps(data, indent=1, sort_keys=True))
        return snap
