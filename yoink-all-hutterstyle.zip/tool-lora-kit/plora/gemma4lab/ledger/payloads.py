from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path

from gemma4lab.core import utc_day
from gemma4lab.core.experiment import COLUMNS as EXPERIMENT_COLUMNS, Ledger


class PayloadKind(str, Enum):
    EXPERIMENTS = "experiments"
    PROMPTS = "prompts"
    TRACE = "trace"
    DATASETS = "datasets"

    @property
    def required_columns(self) -> list[str]:
        """Columns every row of this kind must carry (skills/evidently-ledger)."""
        return {
            PayloadKind.EXPERIMENTS: EXPERIMENT_COLUMNS,
            PayloadKind.PROMPTS: ["prompt", "feedback", "input", "output"],
            PayloadKind.TRACE: ["prompt", "input", "output", "feedback"],
            PayloadKind.DATASETS: ["filename", "timestamp", "input", "output"],
        }[self]


class PayloadError(Exception):
    pass


@dataclass
class PayloadRows:
    """Rows for one Evidently upload. Every value is a string; every row carries `input` and `output`;
    prompt rows carry `prompt` and `feedback`. Method: axiomatic questions (prompts) -> facts (trace) ->
    insights as feedback."""

    kind: PayloadKind
    rows: list[dict[str, str]] = field(default_factory=list)

    @classmethod
    def from_experiments(cls, ledger: Ledger) -> "PayloadRows":
        """The FULL ledger (every row, all columns): the only valid `experiments` payload."""
        return cls(kind=PayloadKind.EXPERIMENTS, rows=ledger.string_rows)

    def append(self, row: dict[str, str]) -> None:
        self.rows.append(row)

    def add_prompt(self, question: str, input: str, output: str, feedback: str) -> None:
        """A hypothesis question with what was done and what was learned."""
        self.rows.append({"prompt": question, "input": input, "output": output, "feedback": feedback})

    def add_fact(self, input: str, output: str, feedback: str = "") -> None:
        """An atomic fact (`prompt = "fact"`)."""
        self.rows.append({"prompt": "fact", "input": input, "output": output, "feedback": feedback})

    def add_file_fact(self, path: str | Path, label: str | None = None) -> None:
        """File metadata fact: path, size, mtime and short sha256, as the runbook's trace rows record."""
        p = Path(path)
        stat = p.stat()
        mtime = utc_day.timestamp(datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc))
        sha = hashlib.sha256(p.read_bytes()).hexdigest()[:16]
        self.add_fact(
            input=label or p.name,
            output=f"path={p} size={stat.st_size} mtime={mtime} sha256={sha}",
            feedback="file metadata",
        )

    def validate(self) -> None:
        if not self.rows:
            raise PayloadError(f"{self.kind.value} payload has no rows")
        required = self.kind.required_columns
        for i, row in enumerate(self.rows):
            missing = [c for c in required if c not in row]
            if missing:
                raise PayloadError(f"{self.kind.value} row {i} lacks {missing}")

    def to_json_bytes(self) -> bytes:
        """JSON list of dicts, all values strings, as `ev_pack.py` reads."""
        self.validate()
        return json.dumps(self.rows, indent=2, sort_keys=True).encode("utf-8")

    def write(self, payload_directory: str | Path) -> Path:
        """Write `rows/<kind>.json` under the payload directory and return its path."""
        rows_dir = Path(payload_directory) / "rows"
        rows_dir.mkdir(parents=True, exist_ok=True)
        path = rows_dir / f"{self.kind.value}.json"
        path.write_bytes(self.to_json_bytes())
        return path


def payload_stamp_directory(ops: str | Path, now: datetime | None = None) -> Path:
    """Names a payload directory the way the runbook does: `ops/payload_<yyyyMMdd-HHmm>/`."""
    base = now or datetime.now(timezone.utc)
    return Path(ops) / f"payload_{base.astimezone(timezone.utc):%Y%m%d-%H%M}"
