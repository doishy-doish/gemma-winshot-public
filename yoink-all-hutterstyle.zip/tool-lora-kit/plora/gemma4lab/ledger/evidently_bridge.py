from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from gemma4lab.core.command_runner import CommandFailed, CommandRunning, ProcessRunner
from gemma4lab.ledger.ledger_snapshot import LedgerSnapshot
from gemma4lab.ledger.payloads import PayloadKind

PACK_ARGUMENTS = ["run", "--python", "3.12", "--with", "evidently==0.7.23", "--with", "pandas", "--with", "pyarrow", "python"]


@dataclass
class EvidentlyBridge:
    """Drives the Python ops scripts that need `evidently`, `pandas` and `pyarrow` (packing parquet)
    or the server (sending). Commands match `skills/evidently-ledger` exactly; the runner can be a
    fake for dry runs."""

    ops_directory: Path
    runner: CommandRunning = field(default_factory=ProcessRunner)

    def pack(self, kind: PayloadKind, rows_json: Path, output_directory: Path):
        """`uv run --python 3.12 --with evidently==0.7.23 --with pandas --with pyarrow python
        ops/ev_pack.py <kind> <rows.json> <outdir>`"""
        script = str(self.ops_directory / "ev_pack.py")
        result = self.runner.run(
            "uv", PACK_ARGUMENTS + [script, kind.value, str(rows_json), str(output_directory)],
            current_directory=self.ops_directory.parent,
        )
        if not result.succeeded:
            raise CommandFailed(result)
        return result

    def pack_all(self, payload_directory: Path) -> list[PayloadKind]:
        """Pack every kind present under `payload_directory/rows/` into `payload_directory/<kind>/`."""
        packed = []
        for kind in PayloadKind:
            rows = payload_directory / "rows" / f"{kind.value}.json"
            if not rows.is_file():
                continue
            self.pack(kind, rows, payload_directory / kind.value)
            packed.append(kind)
        return packed

    def send(self, payload_directories: list[Path]):
        """`cd ops && python3 ev_send.py <payload_dir>...` (run from the ops directory, as the skill
        shows)."""
        args = ["ev_send.py"] + [self._relative_to_ops(p) for p in payload_directories]
        result = self.runner.run("python3", args, current_directory=self.ops_directory)
        if not result.succeeded:
            raise CommandFailed(result)
        return result

    def read_back(self, cache_file: Path) -> LedgerSnapshot:
        """`python3 ops/ev_read.py <cache.json>`: refresh the cache with the stdlib script and parse
        it."""
        script = str(self.ops_directory / "ev_read.py")
        result = self.runner.run("python3", [script, str(cache_file)], current_directory=self.ops_directory.parent)
        if not result.succeeded:
            raise CommandFailed(result)
        return LedgerSnapshot.from_file(cache_file)

    def _relative_to_ops(self, path: Path) -> str:
        resolved = path.resolve()
        base = self.ops_directory.resolve()
        try:
            return str(resolved.relative_to(base))
        except ValueError:
            return str(resolved)

    @staticmethod
    def uploaded_dataset_ids(output: str) -> list[str]:
        """Dataset ids printed by `ev_send.py` (`{"url":..., "dataset": "<id>", ...}` lines)."""
        out = []
        for line in output.split("\n"):
            if not line.strip():
                continue
            try:
                v = json.loads(line)
            except json.JSONDecodeError:
                continue
            dataset_id = v.get("dataset")
            if isinstance(dataset_id, str) and not dataset_id.startswith("upload failed"):
                out.append(dataset_id)
        return out
