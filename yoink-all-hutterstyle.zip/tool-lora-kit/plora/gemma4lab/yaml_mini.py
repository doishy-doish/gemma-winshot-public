"""The submission bundle's YAML subset (mappings, sequences, scalars, flow lists/maps, block
scalars, ``!include``; no anchors or aliases).

``check_submission.py``'s ``MiniYaml`` class is the one implementation of this grammar; the Swift
``Gemma4YAML`` module was a port of it. This module re-exports it rather than re-deriving it.
"""

from gemma4lab._external import check_submission as _check_submission

Include = _check_submission.Include


class YAMLProblem(Exception):
    pass


class MiniYAML:
    @staticmethod
    def parse(text: str):
        try:
            return _check_submission.MiniYaml(text).parse()
        except _check_submission.YamlProblem as e:
            raise YAMLProblem(str(e)) from e
