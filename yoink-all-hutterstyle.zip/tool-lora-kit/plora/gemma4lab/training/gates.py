from __future__ import annotations

import math
from dataclasses import dataclass

from gemma4lab.core.json_value import JSONValue


@dataclass
class TrainingStep:
    """One optimizer step of the training history (`train_history` in metrics.json)."""

    step: int
    epoch: int
    loss: float
    grad_norm: float
    lr: float
    minutes: float


@dataclass
class LossSentinel:
    """Recipe §5.2: losses finite, no skipped steps, decreasing (mean of the last 3 below the mean
    of the first 3)."""

    finite: bool
    first3: list[float]
    last3: list[float]
    decreased: bool

    @property
    def passed(self) -> bool:
        return self.finite and self.decreased

    @classmethod
    def from_history(cls, history: list[TrainingStep]) -> "LossSentinel":
        losses = [s.loss for s in history]
        finite = all(math.isfinite(x) for x in losses)
        first3 = losses[:3]
        last3 = losses[-3:] if losses else []
        decreased = bool(first3) and bool(last3) and (sum(last3) / len(last3)) < (sum(first3) / len(first3))
        return cls(finite=finite, first3=first3, last3=last3, decreased=decreased)


@dataclass
class EffectGate:
    """Recipe §5.3: the adapter changes logits (catches a silent no-op LoRA load in vLLM)."""

    max_abs_logit_delta: float
    threshold: float = 1e-3

    @property
    def passed(self) -> bool:
        return self.max_abs_logit_delta > self.threshold

    @classmethod
    def from_logits(cls, adapter_logits: list[float], base_logits: list[float]) -> "EffectGate":
        deltas = [abs(a - b) for a, b in zip(adapter_logits, base_logits)]
        return cls(max_abs_logit_delta=max(deltas) if deltas else 0)


@dataclass
class ToolAccuracy:
    """Teacher-forced next-tool accuracy on held-out decision points, with the confusion pairs
    (`tool_acc`)."""

    hits: int
    total: int
    confusions: dict[str, int]

    @property
    def accuracy(self) -> float:
        return self.hits / max(self.total, 1)

    @classmethod
    def from_predictions(cls, expected: list[str], predicted: list[str]) -> "ToolAccuracy":
        pairs = list(zip(expected, predicted))
        hits = sum(1 for e, p in pairs if e == p)
        total = min(len(expected), len(predicted))
        confusions: dict[str, int] = {}
        for e, p in pairs:
            key = f"{e}->{p}"
            confusions[key] = confusions.get(key, 0) + 1
        return cls(hits=hits, total=total, confusions=confusions)

    @property
    def top_confusions(self) -> list[tuple[str, int]]:
        """The 12 most common (expected -> predicted) pairs, as the kernel logs them."""
        items = sorted(self.confusions.items(), key=lambda kv: (-kv[1], kv[0]))
        return items[:12]


@dataclass
class PairedOutcome:
    """Paired base-vs-adapter outcome on the held-out fold (`val_adapter` in metrics.json)."""

    tasks: int
    resolved: int
    base_resolved: int
    paired_tasks: int
    gained: int
    lost: int

    @classmethod
    def from_results(cls, base: dict[str, bool], adapter: dict[str, bool]) -> "PairedOutcome":
        both = set(base.keys()) & set(adapter.keys())
        gained = sum(1 for k in both if not base[k] and adapter[k])
        lost = sum(1 for k in both if base[k] and not adapter[k])
        return cls(
            tasks=len(adapter), resolved=sum(1 for v in adapter.values() if v),
            base_resolved=sum(1 for v in base.values() if v), paired_tasks=len(both),
            gained=gained, lost=lost,
        )

    @property
    def mcnemar_statistic(self) -> float:
        """McNemar's statistic on discordant pairs (no continuity correction); >= 3.84 is p < 0.05."""
        d = self.gained + self.lost
        return 0.0 if d == 0 else (self.gained - self.lost) ** 2 / d

    @property
    def net_gain(self) -> int:
        return self.gained - self.lost


@dataclass
class GoCriteria:
    """Recipe §5.5 go criteria. Offline only: never evidence for leaderboard adoption (see
    adoption_rule)."""

    minimum_net_gain: int = 3
    malformed_call_rate_not_up: bool = True
    graph_error_rate_down: bool = True

    @dataclass(frozen=True)
    class Evaluation:
        net_gain_ok: bool
        malformed_ok: bool
        graph_error_ok: bool

        @property
        def go(self) -> bool:
            return self.net_gain_ok and self.malformed_ok and self.graph_error_ok

    def evaluate(self, outcome: PairedOutcome, malformed_rate_base: float, malformed_rate_adapter: float,
                 graph_error_rate_base: float, graph_error_rate_adapter: float) -> "GoCriteria.Evaluation":
        return GoCriteria.Evaluation(
            net_gain_ok=outcome.net_gain >= self.minimum_net_gain,
            malformed_ok=not self.malformed_call_rate_not_up or malformed_rate_adapter <= malformed_rate_base,
            graph_error_ok=not self.graph_error_rate_down or graph_error_rate_adapter < graph_error_rate_base,
        )


def _get_path(raw: JSONValue, *keys: str) -> JSONValue | None:
    cur = raw
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return None
        cur = cur[k]
    return cur


@dataclass
class TrainingMetrics:
    """Loose reader for `metrics.json` written by the training kernel (fields appear as the run
    progresses)."""

    raw: JSONValue

    @property
    def history(self) -> list[TrainingStep]:
        arr = self.raw.get("train_history") if isinstance(self.raw, dict) else None
        if not isinstance(arr, list):
            return []
        out = []
        for s in arr:
            if not isinstance(s, dict) or "step" not in s or "epoch" not in s or "loss" not in s:
                continue
            out.append(TrainingStep(
                step=int(s["step"]), epoch=int(s["epoch"]), loss=float(s["loss"]),
                grad_norm=float(s.get("grad_norm", 0)), lr=float(s.get("lr", 0)), minutes=float(s.get("min", 0)),
            ))
        return out

    @property
    def loss_sentinel(self) -> LossSentinel:
        return LossSentinel.from_history(self.history)

    @property
    def effect_gate(self) -> EffectGate | None:
        delta = _get_path(self.raw, "effect_gate", "max_abs_logit_delta")
        return EffectGate(max_abs_logit_delta=float(delta)) if isinstance(delta, (int, float)) else None

    @property
    def held_out_base_accuracy(self) -> float | None:
        v = _get_path(self.raw, "heldout_tool_acc", "base")
        return float(v) if isinstance(v, (int, float)) else None

    @property
    def held_out_adapter_accuracy(self) -> float | None:
        v = _get_path(self.raw, "heldout_tool_acc", "adapter")
        return float(v) if isinstance(v, (int, float)) else None

    @property
    def max_length(self) -> int | None:
        v = _get_path(self.raw, "max_len", "max_len")
        return int(v) if isinstance(v, (int, float)) else None

    @property
    def ms_per_token(self) -> float | None:
        v = _get_path(self.raw, "fit_probe", "ms_per_token")
        return float(v) if isinstance(v, (int, float)) else None

    @property
    def wrapped_projections(self) -> int | None:
        v = _get_path(self.raw, "lora", "wrapped_projections")
        return int(v) if isinstance(v, (int, float)) else None

    @property
    def exported_tensors(self) -> int | None:
        v = _get_path(self.raw, "export", "tensors")
        return int(v) if isinstance(v, (int, float)) else None

    @property
    def exported_mib(self) -> float | None:
        v = _get_path(self.raw, "export", "mib")
        return float(v) if isinstance(v, (int, float)) else None
