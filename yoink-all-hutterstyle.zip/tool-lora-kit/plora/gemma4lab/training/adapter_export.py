from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

from gemma4lab.training.training_recipe import TrainingRecipe

_PEFT_KEY_RE = re.compile(r"layers\.(\d+)\.(self_attn|mlp)\.(\w+_proj)\.lora_(A|B)(?:\.default)?\.weight$")
_PROJ_SUFFIX_RE = re.compile(r"\.(\w+_proj)\.")


@dataclass
class AdapterConfig:
    """`adapter_config.json` as `export_adapter` writes it: HF PEFT LoRA, inference mode, no
    DoRA/rsLoRA/modules_to_save."""

    r: int
    lora_alpha: int
    lora_dropout: float
    target_modules: list[str]
    peft_type: str = "LORA"
    task_type: str = "CAUSAL_LM"
    base_model_name_or_path: str = "google/gemma-4-31b-it-qat-w4a16-ct"
    bias: str = "none"
    fan_in_fan_out: bool = False
    inference_mode: bool = True
    init_lora_weights: bool = True
    use_dora: bool = False
    use_rslora: bool = False
    modules_to_save: list[str] | None = None
    layers_to_transform: list[int] | None = None
    layers_pattern: str | None = None
    rank_pattern: dict[str, int] = field(default_factory=dict)
    alpha_pattern: dict[str, int] = field(default_factory=dict)
    revision: str | None = None

    @classmethod
    def from_recipe(cls, recipe: TrainingRecipe = TrainingRecipe.shipped, target_modules: list[str] | None = None) -> "AdapterConfig":
        return cls(
            r=recipe.lora_rank, lora_alpha=recipe.lora_alpha, lora_dropout=recipe.lora_dropout,
            target_modules=sorted(target_modules or recipe.target_modules),
        )

    def to_json(self) -> str:
        """Encode with explicit nulls, matching Python's own `json.dumps` of the dict."""
        d = {
            "peft_type": self.peft_type, "task_type": self.task_type,
            "base_model_name_or_path": self.base_model_name_or_path,
            "r": self.r, "lora_alpha": self.lora_alpha, "lora_dropout": self.lora_dropout,
            "bias": self.bias, "fan_in_fan_out": self.fan_in_fan_out,
            "inference_mode": self.inference_mode, "init_lora_weights": self.init_lora_weights,
            "use_dora": self.use_dora, "use_rslora": self.use_rslora,
            "target_modules": self.target_modules, "rank_pattern": self.rank_pattern, "alpha_pattern": self.alpha_pattern,
            "modules_to_save": self.modules_to_save, "layers_to_transform": self.layers_to_transform,
            "layers_pattern": self.layers_pattern, "revision": self.revision,
        }
        return json.dumps(d, indent=2, sort_keys=True)

    @property
    def is_servable(self) -> bool:
        """vLLM constraints the checker also enforces."""
        return self.peft_type == "LORA" and not self.use_dora and not (self.modules_to_save or []) and 0 < self.r <= 128


def competition_key(peft_key: str) -> str | None:
    """Maps PEFT state-dict keys to the layout the competition's vLLM loader expects on the 31B."""
    m = _PEFT_KEY_RE.search(peft_key)
    if not m:
        return None
    layer, block, proj, matrix = m.group(1), m.group(2), m.group(3), m.group(4)
    return f"base_model.model.model.language_model.layers.{layer}.{block}.{proj}.lora_{matrix}.weight"


def projections(keys: list[str]) -> set[str]:
    """Distinct projections named by a set of exported keys (each projection has a lora_A and a lora_B)."""
    out = set()
    for k in keys:
        idx = k.rfind(".lora_")
        if idx > 0:
            out.add(k[:idx])
    return out


def target_modules(keys: list[str]) -> list[str]:
    """Module names (q_proj, gate_proj, ...) present in the exported keys, sorted like the exporter
    writes them."""
    out = set()
    for k in keys:
        m = _PROJ_SUFFIX_RE.search(k)
        if m:
            out.add(m.group(1))
    return sorted(out)


EXPECTED_31B_KEY_COUNT = 820
