from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

from gemma4lab.core.json_value import JSONValue

_GRAPH_FAIL_RE = re.compile(r"error|not found|no node|unknown node|does not exist|0 neighbors|no results", re.IGNORECASE)


@dataclass
class ToolCall:
    """A tool call as vLLM returns it in `response.choices[0].message.tool_calls`."""

    name: str
    arguments: JSONValue
    id: str | None = None

    @staticmethod
    def parse_arguments(raw: JSONValue | None) -> JSONValue:
        """Arguments as the Python code receives them: a JSON string is parsed, anything unparsable
        becomes `{"_raw": ...}`."""
        if raw is None:
            return {}
        if isinstance(raw, dict):
            return raw
        if isinstance(raw, str):
            if raw == "":
                return {}
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                return {"_raw": raw}
        return raw

    @property
    def arguments_key(self) -> str:
        return json.dumps(self.arguments, sort_keys=True, separators=(",", ":"))


@dataclass
class AssistantMessage:
    """An assistant turn: thought channel, visible text and tool calls."""

    reasoning: str = ""
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)


def format_argument(v: JSONValue) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, str):
        return f'<|"|>{v}<|"|>'
    if isinstance(v, dict):
        return "{" + ",".join(f"{k}:{format_argument(v[k])}" for k in sorted(v.keys())) + "}"
    if isinstance(v, list):
        return "[" + ",".join(format_argument(x) for x in v) + "]"
    if isinstance(v, (int, float)):
        return str(int(v)) if float(v) == int(v) and abs(v) < 1e15 else str(v)
    return "None"


def format_call(call: ToolCall) -> str:
    args = ToolCall.parse_arguments(call.arguments)
    if isinstance(args, dict):
        body = ",".join(f"{k}:{format_argument(args[k])}" for k in sorted(args.keys()))
    else:
        body = format_argument(args)
    return f"<|tool_call>call:{call.name}{{{body}}}<tool_call|>"


def thought(reasoning: str) -> str:
    return f"<|channel>thought\n{reasoning.strip()}\n<channel|>"


def target_text(msg: AssistantMessage) -> str:
    """The assistant turn exactly as the model emits it, including the stop token."""
    content = msg.content.strip()
    if not msg.tool_calls:
        return content + "<turn|>"
    s = ""
    if msg.reasoning:
        s += thought(msg.reasoning)
    s += content
    for call in msg.tool_calls:
        s += format_call(call)
    return s + "<|tool_response>"


def decision_prefix(msg: AssistantMessage) -> str:
    """The prefix up to the tool name at a decision point (what `val_decisions` appends to the prompt
    before asking which tool greedy decoding would pick)."""
    prefix = thought(msg.reasoning) if msg.reasoning else ""
    return prefix + msg.content.strip() + "<|tool_call>call:"


def graph_call_failed(response: str) -> bool:
    """Tool responses that mean a graph call did not help (`GRAPH_FAIL` in train.py)."""
    return _GRAPH_FAIL_RE.search(response[:400]) is not None
