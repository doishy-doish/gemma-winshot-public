from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class TimeLimits:
    """Time limits of the Kaggle kernel (TIME_LIMIT_H, TRAIN_BUDGET_H, VAL_EVAL_MIN)."""

    kernel_hours: float = 11.3
    train_budget_hours: float = 4.5
    validation_eval_minutes: float = 130.0
    reserve_minutes: float = 40.0


@dataclass
class TrainingRecipe:
    """The convergence contract of `dataset/recipe/gemma4_31b_peft_recipe.md` §2 and the constants at the
    top of `kernels/train/train.py`. Changing any field here is a NEW experiment."""

    lora_rank: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05
    learning_rate: float = 1e-4
    warmup_fraction: float = 0.03
    gradient_clip: float = 1.0
    weight_decay: float = 0.0
    epochs: int = 2
    global_batch: int = 16
    seed: int = 42
    max_sequence_length: int = 16384
    max_turns_per_trajectory: int = 8
    max_runs_per_task: int = 2
    target_modules: list[str] = field(default_factory=lambda: [
        "q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj",
    ])
    expected_wrapped_projections: int = 410
    training_fold: list[str] = field(default_factory=lambda: ["fastapi/fastapi", "psf/requests", "encode/httpx"])
    validation_fold: list[str] = field(default_factory=lambda: ["Textualize/rich"])
    sampling_temperature: float = 0.7
    validation_temperature: float = 0.2

    @property
    def approximate_adapter_bytes(self) -> int:
        """Adapter size in bytes for bf16 LoRA weights on the 31B (about 234 MiB at r=16)."""
        return int(234.0 * 1024 * 1024 * self.lora_rank / 16.0)


TrainingRecipe.shipped = TrainingRecipe()
TrainingRecipe.TimeLimits = TimeLimits
TrainingRecipe.context_ladder = [16384, 12288, 8192, 6144, 4096]
TrainingRecipe.attention_chunk = 2048
TrainingRecipe.cross_entropy_chunk = 512


@dataclass
class LearningRateSchedule:
    """Linear warmup then cosine decay to zero, exactly the `LambdaLR` lambda in train.py."""

    total_steps: int
    warmup_fraction: float
    peak: float
    warmup_steps: int = field(init=False)

    def __post_init__(self):
        self.warmup_steps = max(1, round(self.warmup_fraction * self.total_steps))

    def factor(self, step: int) -> float:
        if step < self.warmup_steps:
            return (step + 1) / self.warmup_steps
        progress = (step - self.warmup_steps) / max(1, self.total_steps - self.warmup_steps)
        return 0.5 * (1 + math.cos(math.pi * progress))

    def learning_rate(self, step: int) -> float:
        return self.peak * self.factor(step)

    @property
    def curve(self) -> list[float]:
        return [self.learning_rate(s) for s in range(self.total_steps)]


def optimizer_steps(samples: int, recipe: TrainingRecipe = TrainingRecipe.shipped) -> int:
    return math.ceil((samples * recipe.epochs) / recipe.global_batch)


def estimated_hours(tokens: int, ms_per_token: float, epochs: int) -> float:
    """Hours for `epochs` passes over `tokens` at a measured per-token cost."""
    return tokens * epochs * ms_per_token / 1000.0 / 3600.0


def training_budget_seconds(elapsed_seconds: float, limits: TimeLimits = TimeLimits()) -> float:
    """Seconds available for training: min(TRAIN_BUDGET_H, TIME_LIMIT_H - elapsed - (VAL_EVAL_MIN + 40) min)."""
    return min(
        limits.train_budget_hours * 3600,
        (limits.kernel_hours * 3600 - elapsed_seconds) - (limits.validation_eval_minutes + limits.reserve_minutes) * 60,
    )


def token_budget(budget_seconds: float, epochs: int, seconds_per_token: float) -> float:
    return budget_seconds / (epochs * seconds_per_token)


@dataclass
class SampleInfo:
    """One rendered SFT sample's bookkeeping (not the token ids themselves)."""

    task_id: str
    run: str
    turn: int
    tool: str
    tokens: int
    prompt_tokens: int

    @property
    def supervised_tokens(self) -> int:
        return self.tokens - self.prompt_tokens


@dataclass(frozen=True)
class TimeBoxSummary:
    samples: int
    tokens: int
    supervised_tokens: int
    tasks: int
    estimated_hours: float


def time_box_select(samples: list[SampleInfo], token_budget_value: float) -> list[SampleInfo]:
    """The time box of train.py: when 2 epochs will not fit, keep the shortest samples of every task
    round-robin until the token budget is used, so every task keeps representation."""
    by_task: dict[str, list[SampleInfo]] = {}
    order: list[str] = []
    for s in samples:
        if s.task_id not in by_task:
            order.append(s.task_id)
        by_task.setdefault(s.task_id, []).append(s)
    queues = [sorted(by_task[t], key=lambda s: s.tokens) for t in order]
    keep: list[SampleInfo] = []
    used = 0.0
    while any(queues) and used < token_budget_value:
        for i in range(len(queues)):
            if not queues[i]:
                continue
            first = queues[i][0]
            if used + first.tokens <= token_budget_value:
                keep.append(queues[i].pop(0))
                used += first.tokens
            else:
                queues[i] = []
    return keep


def time_box_summary(samples: list[SampleInfo], seconds_per_token: float, epochs: int) -> TimeBoxSummary:
    tokens = sum(s.tokens for s in samples)
    return TimeBoxSummary(
        samples=len(samples), tokens=tokens,
        supervised_tokens=sum(s.supervised_tokens for s in samples),
        tasks=len({s.task_id for s in samples}),
        estimated_hours=round(epochs * tokens * seconds_per_token / 3600, 2),
    )
