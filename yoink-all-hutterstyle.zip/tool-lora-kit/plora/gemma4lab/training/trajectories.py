from __future__ import annotations

import json
from dataclasses import dataclass, field

from gemma4lab.core import competition
from gemma4lab.training.tool_call_format import ToolCall


def pick_turns(tool_names_per_call: list[list[str]], max_turns: int = 8) -> list[int]:
    """Which turns of a trajectory become SFT samples (`pick_turns` in train.py): at most 8 per
    trajectory, chosen as graph-call turns, the first two turns, the first edit, the submit, then an
    even spread of the rest."""
    n = len(tool_names_per_call)
    order: list[int | None] = []
    for i, names in enumerate(tool_names_per_call):
        if competition.GRAPH_TOOLS & set(names):
            order.append(i)
    order += [0, 1]
    order.append(next((i for i, names in enumerate(tool_names_per_call) if "edit_file" in names), None))
    order.append(next((i for i, names in enumerate(tool_names_per_call) if "submit_patch" in names), None))
    chosen = {i for i in order if i is not None}
    rest = [i for i in range(n) if i not in chosen]
    step = max(1, len(rest) // max_turns)
    order += rest[0:len(rest):step]
    seen: set[int] = set()
    out: list[int] = []
    for i in order:
        if i is not None and i < n and i not in seen:
            seen.add(i)
            out.append(i)
    return out[:max_turns]


@dataclass(frozen=True)
class TrajectoryFeatures:
    """Features used to rank resolved runs of the same task: productive graph calls first, then
    fewer calls."""

    call_count: int
    productive_graph_calls: int
    tool_names: tuple[str, ...]


def preferred(a: TrajectoryFeatures, over_b: TrajectoryFeatures) -> bool:
    """Sort key of `build_samples`: `(-graph_ok, n_calls)`."""
    if a.productive_graph_calls != over_b.productive_graph_calls:
        return a.productive_graph_calls > over_b.productive_graph_calls
    return a.call_count < over_b.call_count


@dataclass
class LoggedCall:
    """One `/chat/completions` record from the sampling proxy (`calls/<run>.jsonl`), reduced to what
    attribution needs."""

    index: int
    time: float
    response_tool_calls: list[ToolCall] = field(default_factory=list)
    history_tool_call_ids: list[str] = field(default_factory=list)
    history_tool_response_ids: list[str] = field(default_factory=list)


@dataclass
class TraceIndex:
    """Harness-side evidence from `traces/trace_<task>.json`: which task each tool-call id or
    (name, args) belongs to."""

    task_by_call_id: dict[str, str] = field(default_factory=dict)
    tasks_by_call: dict[str, set[str]] = field(default_factory=dict)

    def record(self, task_id: str, call_id: str | None, name: str, arguments_key: str) -> None:
        if call_id:
            self.task_by_call_id[call_id] = task_id
        self.tasks_by_call.setdefault(f"{name}\0{arguments_key}", set()).add(task_id)

    def anchor(self, call: ToolCall) -> str | None:
        if call.id and call.id in self.task_by_call_id:
            return self.task_by_call_id[call.id]
        args_key = json.dumps(ToolCall.parse_arguments(call.arguments), sort_keys=True, separators=(",", ":"))
        key = f"{call.name}\0{args_key}"
        candidates = self.tasks_by_call.get(key, set())
        return next(iter(candidates)) if len(candidates) == 1 else None


@dataclass(frozen=True)
class LinkResult:
    calls_by_task: dict[str, list[LoggedCall]]
    unmatched: int
    total: int


def link(calls: list[LoggedCall], trace: TraceIndex) -> LinkResult:
    """Attribute logged model calls to tasks (`load_run` in train.py). Harness trace ids (`call_N`)
    differ from vLLM ids, so: (1) anchor a response whose tool call occurs in exactly one task's trace,
    (2) union requests whose history contains a tool-call id an earlier response produced, (3) a
    component takes the task that wins >= 80% of its anchor votes."""
    anchor: dict[int, str] = {}
    for i, r in enumerate(calls):
        for tc in r.response_tool_calls:
            t = trace.anchor(tc)
            if t is not None:
                anchor[i] = t
                break

    parent = list(range(len(calls)))

    def root(x: int) -> int:
        i = x
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    made_by: dict[str, int] = {}
    for i, r in enumerate(calls):
        for tc in r.response_tool_calls:
            if tc.id:
                made_by[tc.id] = i

    for i, r in enumerate(calls):
        for cid in r.history_tool_call_ids:
            if cid in made_by:
                parent[root(i)] = root(made_by[cid])
        for cid in r.history_tool_response_ids:
            if cid in made_by:
                parent[root(i)] = root(made_by[cid])

    votes: dict[int, dict[str, int]] = {}
    for i, task in anchor.items():
        votes.setdefault(root(i), {})[task] = votes.setdefault(root(i), {}).get(task, 0) + 1

    component_task: dict[int, str] = {}
    for c, v in votes.items():
        total = sum(v.values())
        best_task, best_count = max(v.items(), key=lambda kv: kv[1])
        if best_count >= 0.8 * total:
            component_task[c] = best_task

    per_task: dict[str, list[LoggedCall]] = {}
    unmatched = 0
    for i, r in enumerate(calls):
        t = component_task.get(root(i))
        if t is None:
            unmatched += 1
            continue
        per_task.setdefault(t, []).append(r)
    for k in per_task:
        per_task[k].sort(key=lambda r: r.time)
    return LinkResult(calls_by_task=per_task, unmatched=unmatched, total=len(calls))


class TrieError(Exception):
    pass


@dataclass
class ToolTrie:
    """Greedy walk over the tool-name token trie (`greedy_tool` in train.py). Tool names share first
    tokens, so the next-tool metric must walk the trie instead of comparing first tokens."""

    token_ids: dict[str, list[int]]

    def __post_init__(self):
        distinct = {",".join(map(str, v)) for v in self.token_ids.values()}
        if len(distinct) != len(self.token_ids):
            raise TrieError("ambiguous tokenization")

    def greedy_tool(self, argmax) -> str:
        """`argmax(candidate_next_token_ids, prefix) -> token_id` picks the id with the highest logit."""
        prefix: list[int] = []
        while True:
            cands = {k: v for k, v in self.token_ids.items() if v[:len(prefix)] == prefix}
            if len(cands) == 1 and prefix:
                return next(iter(cands))
            next_ids = sorted({v[len(prefix)] for v in cands.values() if len(v) > len(prefix)})
            done = {k: v for k, v in cands.items() if len(v) == len(prefix)}
            if not next_ids:
                if not done:
                    raise TrieError("no candidates")
                return sorted(done.keys())[0]
            prefix.append(argmax(next_ids, prefix))
