"""Loads ``check_submission.py``, the repo's authoritative static checker and YAML-subset parser.

Searched locations, in order: ``$GEMMA4LAB_CHECKER`` (a file path), then for every ancestor of this
file and of the cwd both ``dataset/tools/check_submission.py`` (the repo checkout) and
``tools/check_submission.py`` (the published kit dataset, where ``plora/gemma4lab`` sits next to
``tools/``), then ``/kaggle/input/*/tools/check_submission.py``.
"""

import importlib.util
import os
import sys
from pathlib import Path

RELATIVE_CANDIDATES = ("dataset/tools/check_submission.py", "tools/check_submission.py")


def locate_check_submission() -> Path | None:
    env = os.environ.get("GEMMA4LAB_CHECKER")
    if env and Path(env).is_file():
        return Path(env)
    starts = [Path(__file__).resolve(), Path.cwd().resolve()]
    for start in starts:
        for parent in [start, *start.parents]:
            for rel in RELATIVE_CANDIDATES:
                candidate = parent / rel
                if candidate.is_file():
                    return candidate
    for candidate in sorted(Path("/kaggle/input").glob("*/tools/check_submission.py")):
        return candidate
    return None


def _load():
    path = locate_check_submission()
    if path is None:
        raise ImportError(
            "could not locate check_submission.py: expected dataset/tools/ (repo) or tools/ (kit) above "
            "gemma4lab or the cwd, or set GEMMA4LAB_CHECKER"
        )
    spec = importlib.util.spec_from_file_location("gemma4lab._check_submission", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


check_submission = _load()
