from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from gemma4lab.core.submission_guard import SubmissionLogEntry

_REPO_MARKERS = (".git", "ops/kenv.sh", "tools/check_submission.py")


def _walk_up_for_repo(start: Path) -> Path | None:
    for parent in [start, *start.parents]:
        if any((parent / marker).exists() for marker in _REPO_MARKERS):
            return parent
    return None


def _detect_root() -> Path | None:
    env = os.environ.get("GEMMA4LAB_WORKSPACE")
    if env and Path(env).is_dir():
        return Path(env)
    if Path("/kaggle/input").is_dir() or Path("/kaggle/working").is_dir():
        for candidate in sorted(Path("/kaggle/input").glob("*")):
            if _walk_up_for_repo(candidate) == candidate:
                return candidate
        if Path("/kaggle/working/ops").is_dir():
            return Path("/kaggle/working")
    if Path("/content").is_dir():
        for candidate in sorted(Path("/content").glob("*")):
            if _walk_up_for_repo(candidate) == candidate:
                return candidate
    found = _walk_up_for_repo(Path(__file__).resolve())
    if found is not None:
        return found
    found = _walk_up_for_repo(Path.cwd())
    if found is not None:
        return found
    return None


@dataclass(frozen=True)
class Workspace:
    """Path resolution for the two layouts the library runs in: the repo checkout (.git, ops/kenv.sh,
    dataset/bundles, dataset/tools) and the published kit dataset (tools/, bundles/, plora/ at the top).
    Root detection: env override, then Kaggle/Colab mounts, then walking up from this file or the cwd."""

    root: Path

    @property
    def is_kit(self) -> bool:
        return (self.root / "tools" / "check_submission.py").is_file() and not (self.root / "ops").is_dir()

    @property
    def bundles_dir(self) -> Path:
        repo = self.root / "dataset" / "bundles"
        return repo if repo.is_dir() else self.root / "bundles"

    @property
    def checker_script(self) -> Path:
        repo = self.root / "dataset" / "tools" / "check_submission.py"
        return repo if repo.is_file() else self.root / "tools" / "check_submission.py"

    @classmethod
    def locate(cls) -> "Workspace | None":
        root = _detect_root()
        return cls(root=root) if root is not None else None

    @property
    def ops(self) -> Path:
        return self.root / "ops"

    @property
    def kernels(self) -> Path:
        return self.root / "kernels"

    @property
    def ledger_cache(self) -> Path:
        return self.ops / "ledger_cache"

    @property
    def training_metrics(self) -> Path:
        return self.root / "train_out" / "metrics.json"

    @property
    def submissions_log(self) -> Path:
        return self.root / ".claude" / "output" / "state" / "submissions.jsonl"

    def latest_ledger_cache(self) -> Path | None:
        if not self.ledger_cache.is_dir():
            return None
        caches = sorted(self.ledger_cache.glob("evh_*.json"))
        return caches[-1] if caches else None

    def submission_log_entries(self) -> list[SubmissionLogEntry]:
        path = self.submissions_log
        if not path.is_file():
            return []
        return SubmissionLogEntry.parse_jsonl(path.read_text())
