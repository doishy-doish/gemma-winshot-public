from __future__ import annotations

import os
from dataclasses import dataclass

from gemma4lab.plora.cost_model import CostModel
from gemma4lab.plora.report import ReproductionResults
from gemma4lab.viz import palette


@dataclass(frozen=True)
class Bar:
    group: str
    source: str
    value: float


def figure4_bars(results: ReproductionResults) -> list[Bar]:
    out = []
    for r in results.makespans_small_batch:
        paper = r.paper[0] if r.paper else 0
        out.append(Bar(r.model, "paper", paper))
        out.append(Bar(r.model, "ours", r.plora_speedup))
    return out


def figure5_bars(results: ReproductionResults) -> list[Bar]:
    out = []
    for t in results.throughputs:
        g = f"{t.model.replace('Qwen2.5-', '')} bs{t.batch_size}"
        out.append(Bar(g, "paper", t.paper or 0))
        out.append(Bar(g, "ours", t.plora_over_min_gpu))
    return out


def max_gpu_bars(results: ReproductionResults) -> list[Bar]:
    out = []
    for r in results.makespans_small_batch:
        paper = r.paper[1] if r.paper else 0
        out.append(Bar(r.model, "paper", paper))
        out.append(Bar(r.model, "ours", r.max_gpu_normalized))
    return out


@dataclass(frozen=True)
class GanttRow:
    job_id: int
    label: str
    start_hours: float
    end_hours: float
    adapters: int


def gantt_rows(results: ReproductionResults) -> list[GanttRow]:
    if len(results.makespans_small_batch) <= 1:
        return []
    jobs = results.makespans_small_batch[1].plora.jobs
    return [
        GanttRow(job_id=j.id, label=f"job {j.id} - {j.degree} GPU", start_hours=j.start_seconds / 3600, end_hours=j.end_seconds / 3600, adapters=len(j.configs))
        for j in jobs
    ]


def challenge_speedup_bars(results: ReproductionResults) -> list[Bar]:
    """Gemma challenge: speedup per alias, one series per assumed L4 floor (fixed categorical
    order)."""
    return [
        Bar(r.model.replace(" (nf4 QLoRA)", ""), f"floor {int(r.floor_tokens)}", r.speedup)
        for r in results.challenge
    ]


def challenge_fit_bars(results: ReproductionResults) -> list[Bar]:
    if not results.challenge:
        return []
    first_floor = results.challenge[0].floor_tokens
    return [
        Bar(r.model.replace(" (nf4 QLoRA)", ""), "fit", float(r.adapters_that_fit))
        for r in results.challenge if r.floor_tokens == first_floor
    ]


def kpi_summary(results: ReproductionResults, cost: CostModel) -> list[dict]:
    seven = results.makespans_small_batch[1] if len(results.makespans_small_batch) > 1 else (results.makespans_small_batch[0] if results.makespans_small_batch else None)
    fig5_7b_bs1 = next((t for t in results.throughputs if t.model == "Qwen2.5-7B" and t.batch_size == 1), None)
    return [
        {"title": "Calibration", "value": "x1.10 / x3.60",
         "detail": f"batch 1->8 and naive 8-pack claims reproduced; T_sat {int(cost.saturation_tokens)} tokens", "status": "good"},
        {"title": "Fig. 5 throughput, 7B bs1", "value": f"{fig5_7b_bs1.plora_over_min_gpu:.1f}x" if fig5_7b_bs1 else "-",
         "detail": "paper 12.8x", "status": "good"},
        {"title": "Fig. 4 makespan, 7B", "value": f"{seven.plora_speedup:.2f}x" if seven else "-",
         "detail": "paper 6.52x; small-batch mix", "status": "warning" if seven and seven.plora_speedup <= 3 else "good"},
        {"title": "Theorem D.1 bound", "value": f"AR <= {seven.plora.tail_effect_bound:.3f}" if seven else "-",
         "detail": "paper observes 1.05-1.14", "status": "good"},
    ]


def plot_plora_dashboard(results: ReproductionResults, cost: CostModel = None, show: bool = True):
    """Matplotlib recreation of the PLoRA dashboard: KPI tiles, Figure 4/5 bar comparisons, the
    challenge sweep, the planner's Gantt schedule and the CPU kernel benchmark."""
    import matplotlib.pyplot as plt

    cost = cost or CostModel()
    fig = plt.figure(figsize=(14, 16), facecolor=palette.PAGE)
    gs = fig.add_gridspec(5, 2, hspace=0.6, wspace=0.3)

    def grouped_bar(ax, bars: list[Bar], title: str, scale: dict[str, str] | None = None):
        groups = sorted({b.group for b in bars}, key=lambda g: [b.group for b in bars].index(g))
        sources = sorted({b.source for b in bars}, key=lambda s: [b.source for b in bars].index(s))
        width = 0.8 / max(1, len(sources))
        for i, source in enumerate(sources):
            values = [next((b.value for b in bars if b.group == g and b.source == source), 0) for g in groups]
            color = (scale or {}).get(source, palette.SERIES[i % len(palette.SERIES)])
            xs = [x + i * width for x in range(len(groups))]
            ax.bar(xs, values, width=width, label=source, color=color)
        ax.set_xticks([x + width * (len(sources) - 1) / 2 for x in range(len(groups))])
        ax.set_xticklabels(groups, rotation=30, ha="right", fontsize=8)
        ax.set_title(title, fontsize=10, color=palette.PRIMARY_INK)
        ax.legend(fontsize=7)
        ax.set_facecolor(palette.SURFACE)

    source_scale = {"paper": palette.DE_EMPHASIS, "ours": palette.BLUE}

    ax1 = fig.add_subplot(gs[0, 0])
    grouped_bar(ax1, figure4_bars(results), "Figure 4: makespan speedup over Min GPU", source_scale)
    ax2 = fig.add_subplot(gs[0, 1])
    grouped_bar(ax2, max_gpu_bars(results), "Figure 4: Max GPU makespan normalised", source_scale)
    ax3 = fig.add_subplot(gs[1, :])
    grouped_bar(ax3, figure5_bars(results), "Figure 5: job throughput over Min GPU", source_scale)
    ax4 = fig.add_subplot(gs[2, :])
    grouped_bar(ax4, challenge_speedup_bars(results), "Gemma 4 aliases on Kaggle 4x L4: speedup by L4 floor")

    ax5 = fig.add_subplot(gs[3, 0])
    gantt = gantt_rows(results)
    for row in gantt:
        shade = palette.SEQUENTIAL_BLUE[min(4, max(0, row.adapters // 6))]
        ax5.barh(row.label, row.end_hours - row.start_hours, left=row.start_hours, color=shade)
        ax5.text(row.end_hours, row.label, str(row.adapters), fontsize=7, va="center")
    ax5.set_title("Planner schedule, Qwen2.5-7B", fontsize=10)
    ax5.set_xlabel("hours")

    ax6 = fig.add_subplot(gs[3, 1])
    kernel_bars = []
    for k in results.kernels:
        kernel_bars.append(Bar(f"{k.adapters} adapters", "forward", k.forward_speedup))
        kernel_bars.append(Bar(f"{k.adapters} adapters", "backward", k.backward_speedup))
    grouped_bar(ax6, kernel_bars, f"Table 7 analogue on {os.cpu_count()} CPU cores", {"forward": palette.BLUE, "backward": palette.ORANGE})

    ax7 = fig.add_subplot(gs[4, :])
    ax7.axis("off")
    kpis = kpi_summary(results, cost)
    for i, kpi in enumerate(kpis):
        x = i / len(kpis)
        ax7.text(x, 0.6, kpi["title"], fontsize=9, color=palette.SECONDARY_INK, transform=ax7.transAxes)
        ax7.text(x, 0.3, kpi["value"], fontsize=16, color=palette.PRIMARY_INK, fontweight="bold", transform=ax7.transAxes)
        ax7.text(x, 0.05, kpi["detail"], fontsize=7, color=palette.MUTED_INK, transform=ax7.transAxes, wrap=True)

    fig.suptitle("PLoRA reproduction (Yan et al., ICML 2026)", fontsize=14, color=palette.PRIMARY_INK)
    if show:
        plt.show()
    return fig
