from __future__ import annotations

from dataclasses import dataclass, field

from gemma4lab.training.gates import EffectGate, GoCriteria, LossSentinel, PairedOutcome, ToolAccuracy, TrainingStep
from gemma4lab.training.training_recipe import LearningRateSchedule, TimeBoxSummary, TrainingRecipe
from gemma4lab.viz import palette


@dataclass
class TrainingDashboardData:
    """Everything the Training dashboard shows, computed by the caller (or a test) and handed in."""

    recipe: TrainingRecipe
    schedule: LearningRateSchedule
    history: list[TrainingStep]
    history_source: str
    tool_accuracy: ToolAccuracy | None = None
    held_out_base: float | None = None
    held_out_adapter: float | None = None
    effect_gate: EffectGate | None = None
    paired: PairedOutcome | None = None
    go_criteria: "GoCriteria.Evaluation | None" = None
    full_set: TimeBoxSummary | None = None
    boxed_set: TimeBoxSummary | None = None
    picked_turns: list[str] = field(default_factory=list)
    exported_tensors: int | None = None
    exported_mib: float | None = None


def kpi_summary(data: TrainingDashboardData) -> list[dict]:
    sentinel = LossSentinel.from_history(data.history)
    return [
        {"title": "LoRA", "value": f"r={data.recipe.lora_rank} alpha={data.recipe.lora_alpha}",
         "detail": f"{data.recipe.expected_wrapped_projections} projections, dropout {data.recipe.lora_dropout}"},
        {"title": "Optimizer steps", "value": str(data.schedule.total_steps),
         "detail": f"warmup {data.schedule.warmup_steps}, peak lr {data.schedule.peak:.0e}"},
        {"title": "Loss sentinel", "value": "decreasing" if sentinel.decreased else "not decreasing",
         "detail": "no history" if not sentinel.first3 else f"{sum(sentinel.first3)/len(sentinel.first3):.3f} -> {sum(sentinel.last3)/len(sentinel.last3):.3f}",
         "status": "good" if sentinel.passed else "critical"},
        {"title": "Effect gate", "value": ("adapter acts" if data.effect_gate.passed else "no-op adapter") if data.effect_gate else "-",
         "detail": f"max |logit delta| {data.effect_gate.max_abs_logit_delta:.2f}" if data.effect_gate else None,
         "status": ("good" if data.effect_gate.passed else "critical") if data.effect_gate else None},
    ]


def plot_training_dashboard(data: TrainingDashboardData, show: bool = True):
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(12, 9), facecolor=palette.PAGE)
    fig.suptitle("Training: tool-use LoRA for Gemma 4 31B", fontsize=13, color=palette.PRIMARY_INK)

    ax = axes[0, 0]
    steps = list(range(data.schedule.total_steps))
    ax.plot(steps, [data.schedule.learning_rate(s) for s in steps], color=palette.BLUE, linewidth=2)
    ax.set_title("Learning rate (warmup + cosine decay)", fontsize=10)
    ax.set_xlabel("optimizer step")
    ax.set_facecolor(palette.SURFACE)

    ax = axes[0, 1]
    if data.history:
        xs = [s.step for s in data.history]
        ys = [s.loss for s in data.history]
        ax.plot(xs, ys, color=palette.BLUE, marker="o", markersize=3, linewidth=2)
    else:
        ax.text(0.5, 0.5, "no training history", ha="center", color=palette.MUTED_INK)
    ax.set_title(f"Training loss ({data.history_source})", fontsize=10)
    ax.set_xlabel("optimizer step")
    ax.set_facecolor(palette.SURFACE)

    ax = axes[1, 0]
    if data.tool_accuracy:
        top = data.tool_accuracy.top_confusions[:8]
        ax.barh([p for p, _ in top], [c for _, c in top], color=palette.SEQUENTIAL_BLUE[3])
        ax.set_title("Next-tool confusions (expected -> predicted)", fontsize=10)
    else:
        ax.text(0.5, 0.5, "no decision points", ha="center", color=palette.MUTED_INK)
    ax.set_facecolor(palette.SURFACE)

    ax = axes[1, 1]
    if data.paired:
        ax.barh(["gained"], [data.paired.gained], color=palette.DIVERGING_POSITIVE)
        ax.barh(["lost"], [-data.paired.lost], color=palette.DIVERGING_NEGATIVE)
        ax.axvline(0, color=palette.DE_EMPHASIS)
        ax.set_title("Rich fold, base vs adapter", fontsize=10)
    else:
        ax.text(0.5, 0.5, "no paired outcome", ha="center", color=palette.MUTED_INK)
    ax.set_facecolor(palette.SURFACE)

    fig.tight_layout()
    if show:
        plt.show()
    return fig
