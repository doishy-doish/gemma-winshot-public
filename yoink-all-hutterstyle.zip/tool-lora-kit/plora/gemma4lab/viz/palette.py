from __future__ import annotations

"""The validated reference data-viz palette (light mode). Categorical slots are used in fixed
order, never cycled; status colors are reserved for state and always appear with an icon/marker
and a label."""

SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
BLUE = SERIES[0]
ORANGE = SERIES[1]
AQUA = SERIES[2]

DIVERGING_POSITIVE = "#2a78d6"
DIVERGING_NEGATIVE = "#e34948"

GOOD = "#0ca30c"
WARNING = "#fab219"
SERIOUS = "#ec835a"
CRITICAL = "#d03b3b"

PRIMARY_INK = "#0b0b0b"
SECONDARY_INK = "#52514e"
MUTED_INK = "#898781"
GRIDLINE = "#e1e0d9"
DE_EMPHASIS = "#c3c2b7"
SURFACE = "#fcfcfb"
PAGE = "#f9f9f7"

SEQUENTIAL_BLUE = ["#86b6ef", "#5598e7", "#2a78d6", "#1c5cab", "#104281"]
"""Sequential blue ramp, light -> dark (steps 250, 350, 450, 550, 650)."""


class KPIStatus:
    """A state a KPI tile can report; each comes with a marker so colour never carries meaning
    alone."""

    GOOD = "good"
    WARNING = "warning"
    CRITICAL = "critical"
    NEUTRAL = "neutral"


_KPI_COLOR = {KPIStatus.GOOD: GOOD, KPIStatus.WARNING: WARNING, KPIStatus.CRITICAL: CRITICAL, KPIStatus.NEUTRAL: MUTED_INK}
_KPI_MARKER = {KPIStatus.GOOD: "o", KPIStatus.WARNING: "^", KPIStatus.CRITICAL: "x", KPIStatus.NEUTRAL: "."}


def kpi_color(status: str) -> str:
    return _KPI_COLOR[status]


def kpi_marker(status: str) -> str:
    return _KPI_MARKER[status]
