from __future__ import annotations

from dataclasses import dataclass, field

from gemma4lab.core.adoption_rule import Verdict
from gemma4lab.core.experiment import Ledger
from gemma4lab.viz import palette


@dataclass
class ExperimentsDashboardData:
    ledger: Ledger
    ledger_source: str
    today: str
    days_to_deadline: int
    quota_reset: str
    verdicts: list[tuple[str, Verdict]]
    ready_candidate: object | None
    next_idea: object | None
    dry_run_commands: list[str] = field(default_factory=list)


def public_scores(data: ExperimentsDashboardData) -> list[tuple[str, float, bool]]:
    scores = [(r.exp_id, r.public_score, r.is_arch) for r in data.ledger.rows if r.public_score is not None]
    return sorted(scores, key=lambda s: -s[1])


def status_counts(data: ExperimentsDashboardData) -> list[tuple[str, int]]:
    counts: dict[str, int] = {}
    for r in data.ledger.rows:
        counts[str(r.status)] = counts.get(str(r.status), 0) + 1
    return sorted(counts.items(), key=lambda kv: -kv[1])


def kpi_summary(data: ExperimentsDashboardData) -> list[dict]:
    scores = public_scores(data)
    best = scores[0][1] if scores else 0
    arch = data.ledger.arch
    return [
        {"title": "Champion (ARCH)", "value": arch.output if arch else "-", "detail": arch.input if arch else None},
        {"title": "Best public score", "value": f"{best:.2f}", "detail": scores[0][0] if scores else None},
        {"title": "Days to deadline", "value": str(data.days_to_deadline),
         "detail": f"one submission per UTC day; GPU quota resets {data.quota_reset}",
         "status": "good" if data.days_to_deadline > 7 else "warning"},
        {"title": "Ledger", "value": f"{len(data.ledger.rows)} rows", "detail": data.ledger_source},
    ]


def plot_experiments_dashboard(data: ExperimentsDashboardData, show: bool = True):
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(12, 5), facecolor=palette.PAGE)
    fig.suptitle("Experiments: ledger, adoption verdicts", fontsize=13, color=palette.PRIMARY_INK)

    ax = axes[0]
    scores = public_scores(data)
    if scores:
        colors = [palette.BLUE if champion else palette.DE_EMPHASIS for _, _, champion in scores]
        ax.barh([s[0] for s in scores], [s[1] for s in scores], color=colors)
    ax.set_title("Public leaderboard scores", fontsize=10)
    ax.invert_yaxis()
    ax.set_facecolor(palette.SURFACE)

    ax = axes[1]
    counts = status_counts(data)
    if counts:
        ax.barh([c[0] for c in counts], [c[1] for c in counts], color=palette.SEQUENTIAL_BLUE[2])
    ax.set_title("Ledger rows by status", fontsize=10)
    ax.invert_yaxis()
    ax.set_facecolor(palette.SURFACE)

    fig.tight_layout()
    if show:
        plt.show()
    return fig
