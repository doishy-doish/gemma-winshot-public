from __future__ import annotations

from dataclasses import dataclass

from gemma4lab.checker import CheckReport
from gemma4lab.core import competition
from gemma4lab.core.budgets import EvalBudget, SamplingConfig
from gemma4lab.viz import palette


@dataclass
class TestingDashboardData:
    bundle_name: str
    bundle_hash: str
    ledger_hash: str | None
    adapter_hash: str
    report: CheckReport
    budget: EvalBudget
    sampling: SamplingConfig
    zip_bytes: int
    zip_verified: bool
    guard_allowed: bool
    candidate_name: str | None = None
    candidate_report: CheckReport | None = None


def status_counts(report: CheckReport) -> dict[str, int]:
    counts = {"pass": 0, "warn": 0, "fail": 0, "skip": 0}
    for entry in report.results.values():
        status = entry["status"]
        if status in counts:
            counts[status] += 1
    return counts


def kpi_summary(data: TestingDashboardData) -> list[dict]:
    hash_ok = (data.ledger_hash == data.bundle_hash) if data.ledger_hash else None
    worst = data.budget.worst_case_scorer_hours()
    counts = status_counts(data.report)
    return [
        {"title": "Bundle hash", "value": data.bundle_hash,
         "detail": "matches the ledger" if hash_ok else (f"ledger has {data.ledger_hash}" if data.ledger_hash else "no ledger value"),
         "status": "neutral" if hash_ok is None else ("good" if hash_ok else "critical")},
        {"title": "Checker", "value": f"{len(data.report.failures)} fail",
         "detail": f"{counts['pass']} pass, {len(data.report.warnings)} warn",
         "status": "critical" if data.report.failures else ("good" if not data.report.warnings else "warning")},
        {"title": "Scorer budget", "value": f"{worst:.1f} h",
         "detail": f"worst case for {competition.SCORER_TASK_COUNT} tasks at {int(data.budget.max_time_minutes)} min, limit {int(competition.SCORER_HOURS)} h",
         "status": "critical" if worst > competition.SCORER_HOURS else ("warning" if worst > competition.SCORER_HOURS - 1 else "good")},
        {"title": "submission.zip", "value": "verified" if data.zip_verified else "mismatch",
         "detail": f"{data.zip_bytes} bytes, kernel layout", "status": "good" if data.zip_verified else "critical"},
    ]


def plot_testing_dashboard(data: TestingDashboardData, show: bool = True):
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(12, 5), facecolor=palette.PAGE)
    fig.suptitle("Testing: bundle checker, budgets, submission.zip", fontsize=13, color=palette.PRIMARY_INK)

    ax = axes[0]
    labels = [data.bundle_name] + ([data.candidate_name or "candidate"] if data.candidate_report else [])
    reports = [data.report] + ([data.candidate_report] if data.candidate_report else [])
    status_colors = {"pass": palette.GOOD, "warn": palette.WARNING, "fail": palette.CRITICAL, "skip": palette.DE_EMPHASIS}
    bottoms = [0.0] * len(labels)
    for status in ("pass", "warn", "fail", "skip"):
        values = [status_counts(r)[status] for r in reports]
        ax.barh(labels, values, left=bottoms, color=status_colors[status], label=status)
        bottoms = [b + v for b, v in zip(bottoms, values)]
    ax.legend(fontsize=8)
    ax.set_title("Checker results by status", fontsize=10)
    ax.set_facecolor(palette.SURFACE)

    ax = axes[1]
    worst = data.budget.worst_case_scorer_hours()
    meters = [
        ("scorer hours", worst, competition.SCORER_HOURS),
        ("thinking tokens", data.sampling.thinking_budget, data.sampling.max_output_tokens),
        ("tool calls", data.budget.max_tool_calls, data.budget.max_turns),
    ]
    ax.barh([m[0] for m in meters], [m[1] / m[2] for m in meters], color=palette.SEQUENTIAL_BLUE[2])
    ax.set_xlim(0, 1.2)
    ax.axvline(1, color=palette.DE_EMPHASIS, linestyle="--")
    ax.set_title("Budgets (fraction of limit)", fontsize=10)
    ax.set_facecolor(palette.SURFACE)

    fig.tight_layout()
    if show:
        plt.show()
    return fig
