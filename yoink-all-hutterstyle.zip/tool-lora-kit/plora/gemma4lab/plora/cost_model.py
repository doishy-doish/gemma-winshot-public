from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum

from gemma4lab.plora.lora_config import LoRAConfig
from gemma4lab.plora.specs import GPUSpec, ModelSpec


class Execution(str, Enum):
    PACKED = "packed"
    """PLoRA: batched base model + packed LoRA kernels."""
    SEQUENTIAL_ADAPTERS = "sequential_adapters"
    """Sequential PLoRA (Fig. 6 ablation): batched base model, adapters computed one after another."""


@dataclass
class CostModelParameters:
    saturated_efficiency: float = 0.5
    """Fraction of peak FLOP/s reached by large, saturated steps."""
    batch_one_to_eight_slowdown: float = 1.10
    """Iteration-time growth the paper reports for batch 1 -> 8 on Qwen2.5-7B (A100)."""
    saturation_exponent: float = 3.0
    """Shape of the latency-to-compute transition: 1 = linear floor, inf = hard knee."""
    naive_eight_pack_slowdown: float = 3.6
    """Slowdown of a naive 8-adapter pack over a single adapter (§C.1)."""
    packed_kernel_loss: float = 0.0025
    """Packed-kernel speedup s(n) = n x (1 - packed_kernel_loss x (n - 1)), fitted to Table 7 on A100."""
    reference_rank: int = 32
    """Rank at which the LoRA kernel share was measured (§4.3 fixes r = 32 for the throughput study)."""
    rank_sensitivity: float = 0.25
    """How much LoRA kernel time grows with rank: share x (1 - w + w x r/32)."""
    measured_seconds_per_token_equivalent: float | None = None
    """Measured single-GPU-equivalent seconds per token of a complete single-adapter step; replaces
    the FLOP formula when set (Gemma 4 on L4)."""
    saturation_tokens_override: float | None = None
    """Replaces the calibrated saturation floor when set (compute-bound QLoRA steps have a much
    smaller floor)."""
    lora_share_override: float | None = None
    """Replaces the calibrated LoRA share when set (the §C.1 identity only holds for the paper's A100
    setup)."""


@dataclass
class CostModel:
    """Iteration-time model T(H, d) for a packed fine-tuning job. The paper measures T from the first
    10 iterations of a real run; without GPUs we use an analytical model with a few knobs calibrated
    to the paper's own statements (see each property's docstring)."""

    parameters: CostModelParameters = field(default_factory=CostModelParameters)

    @staticmethod
    def calibrated_saturation_tokens(slowdown: float, exponent: float) -> float:
        """T_sat in tokens from the +10% claim: ((8192^p + T^p) / (1024^p + T^p))^(1/p) = g
        -> T = ((8192^p - g^p x 1024^p) / (g^p - 1))^(1/p)."""
        g = slowdown ** exponent
        return ((8192 ** exponent - g * 1024 ** exponent) / (g - 1)) ** (1 / exponent)

    @property
    def saturation_tokens(self) -> float:
        if self.parameters.saturation_tokens_override is not None:
            return self.parameters.saturation_tokens_override
        return self.calibrated_saturation_tokens(self.parameters.batch_one_to_eight_slowdown, self.parameters.saturation_exponent)

    def _shape(self, tokens: float) -> float:
        """Shape function: token-equivalents of a step processing `tokens` on one GPU."""
        p = self.parameters.saturation_exponent
        t = self.saturation_tokens
        return (max(0, tokens) ** p + t ** p) ** (1 / p)

    @property
    def lora_share(self) -> float:
        """LoRA kernel share lambda of a single-adapter (bs 1, s 1024, r 32) step, relative to the
        base-model time: base(8192) + 8 x lora(1024) = 3.6 x (base(1024) + lora(1024))."""
        if self.parameters.lora_share_override is not None:
            return self.parameters.lora_share_override
        p = self.parameters.saturation_exponent
        t = self.calibrated_saturation_tokens(self.parameters.batch_one_to_eight_slowdown, p)

        def s(x: float) -> float:
            return (x ** p + t ** p) ** (1 / p)

        b1, b8 = s(1024), s(8192)
        n = self.parameters.naive_eight_pack_slowdown
        return (n * b1 - b8) / (8 * b1 - n * b1)

    def packed_speedup(self, adapters: int) -> float:
        """Packed-kernel speedup over sequential adapter computation for n adapters (Table 7 fit)."""
        if adapters <= 1:
            return 1
        return adapters * max(0.5, 1 - self.parameters.packed_kernel_loss * (adapters - 1))

    def tp_overhead(self, degree: int, gpu: GPUSpec) -> float:
        """Communication overhead factor of tensor parallelism at degree d."""
        return 1 + gpu.tp_overhead_per_doubling * math.log2(max(1, degree))

    def seconds_per_token_equivalent(self, model: ModelSpec, gpu: GPUSpec) -> float:
        """Seconds per token-equivalent at saturation on one GPU for the base model alone."""
        if self.parameters.measured_seconds_per_token_equivalent is not None:
            return self.parameters.measured_seconds_per_token_equivalent / (1 + self.lora_share)
        return 4 * model.parameters / (gpu.peak_tflops * 1e12 * self.parameters.saturated_efficiency)

    def base_step_seconds(self, model: ModelSpec, gpu: GPUSpec, tokens: int, degree: int) -> float:
        """Base-model time for one iteration processing `tokens` tokens on `degree` GPUs."""
        return self.seconds_per_token_equivalent(model, gpu) * self._shape(tokens / degree) * self.tp_overhead(degree, gpu)

    def lora_step_seconds(self, model: ModelSpec, gpu: GPUSpec, config: LoRAConfig, degree: int) -> float:
        """Sequential (per-adapter) LoRA kernel time for one adapter."""
        rank_factor = 1 - self.parameters.rank_sensitivity + self.parameters.rank_sensitivity * config.rank / self.parameters.reference_rank
        return self.lora_share * rank_factor * self.base_step_seconds(model, gpu, config.tokens_per_iteration, degree)

    def step_seconds(self, model: ModelSpec, gpu: GPUSpec, configs: list[LoRAConfig], degree: int, execution: Execution = Execution.PACKED) -> float:
        """T(H, d): one iteration of a job with adapters `configs` on `degree` GPUs."""
        if not configs:
            return 0
        tokens = sum(c.tokens_per_iteration for c in configs)
        base = self.base_step_seconds(model, gpu, tokens, degree)
        lora_sequential = sum(self.lora_step_seconds(model, gpu, c, degree) for c in configs)
        if execution == Execution.PACKED:
            return base + lora_sequential / self.packed_speedup(len(configs))
        return base + lora_sequential

    def job_seconds(self, model: ModelSpec, gpu: GPUSpec, configs: list[LoRAConfig], degree: int, execution: Execution = Execution.PACKED) -> float:
        """Duration of a whole job. Adapters have different step counts, so the job runs in phases:
        after the adapter with the fewest steps finishes, the remaining ones continue with a cheaper
        step."""
        remaining = sorted(configs, key=lambda c: c.steps)
        done = 0
        total = 0.0
        while remaining:
            target = remaining[0].steps
            delta = target - done
            if delta > 0:
                total += delta * self.step_seconds(model, gpu, remaining, degree, execution)
            done = target
            remaining = remaining[1:]
        return total

    def throughput(self, model: ModelSpec, gpu: GPUSpec, configs: list[LoRAConfig], degree: int) -> float:
        """Objective of eq. 1 / eq. 6: sum r_k / T(H, d) (LoRA FLOPs are linear in rank, §2.1)."""
        if not configs:
            return 0
        return sum(c.rank for c in configs) / self.step_seconds(model, gpu, configs, degree)

    @classmethod
    def gemma_on_l4(cls, measured_ms_per_token: float = 16.722, group_size: int = 4) -> "CostModel":
        """This project's training kernel, from train_out/metrics.json: 16.722 ms/token for the whole
        4x L4 group at 16k context with one r=16 adapter."""
        p = CostModelParameters()
        p.measured_seconds_per_token_equivalent = (
            measured_ms_per_token / 1000 * group_size / (1 + GPUSpec.l4_24.tp_overhead_per_doubling * math.log2(group_size))
        )
        p.saturation_tokens_override = 128
        p.lora_share_override = 0.15
        return cls(parameters=p)
