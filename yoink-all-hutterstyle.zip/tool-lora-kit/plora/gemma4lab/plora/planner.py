from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum

from gemma4lab.plora.cost_model import CostModel, Execution
from gemma4lab.plora.lora_config import LoRAConfig
from gemma4lab.plora.memory_model import MemoryModel
from gemma4lab.plora.specs import ModelSpec, Testbed


@dataclass
class PackedJob:
    """A packed fine-tuning job: adapters that share one frozen base model on `degree` GPUs."""

    id: int
    configs: list[LoRAConfig]
    degree: int
    start_seconds: float
    duration_seconds: float

    @property
    def end_seconds(self) -> float:
        return self.start_seconds + self.duration_seconds

    @property
    def total_rank(self) -> int:
        return sum(c.rank for c in self.configs)

    @property
    def gpu_seconds(self) -> float:
        return self.degree * self.duration_seconds


@dataclass
class Schedule:
    """The outcome of scheduling a configuration set on a testbed."""

    strategy: str
    model: str
    gpu_count: int
    jobs: list[PackedJob]
    infeasible: list[LoRAConfig]
    """Configurations that fit on no degree <= G and were skipped."""

    @property
    def makespan_seconds(self) -> float:
        return max((j.end_seconds for j in self.jobs), default=0)

    @property
    def makespan_hours(self) -> float:
        return self.makespan_seconds / 3600

    @property
    def utilization(self) -> float:
        """Busy GPU-seconds over G x makespan."""
        if self.makespan_seconds <= 0:
            return 0
        return sum(j.gpu_seconds for j in self.jobs) / (self.gpu_count * self.makespan_seconds)

    @property
    def adapters_per_job(self) -> float:
        if not self.jobs:
            return 0
        return sum(len(j.configs) for j in self.jobs) / len(self.jobs)

    @property
    def max_adapters_in_a_job(self) -> int:
        return max((len(j.configs) for j in self.jobs), default=0)

    @property
    def tail_effect_bound(self) -> float:
        """Theorem D.1: AR <= F / (F - T_last x (G - D) / G), with T_last and D the duration and
        degree of the last job to start."""
        if not self.jobs or self.makespan_seconds <= 0:
            return 1
        last = max(self.jobs, key=lambda j: j.start_seconds)
        g, d, f = float(self.gpu_count), float(last.degree), self.makespan_seconds
        denominator = f - last.duration_seconds * (g - d) / g
        return f / denominator if denominator > 0 else math.inf


@dataclass(frozen=True)
class Pack:
    """One job of a scheduling policy: a pack and its degree."""

    configs: list[LoRAConfig]
    degree: int


@dataclass
class Packer:
    """Per-degree packing: F(D, K) = max sum r_k / T(H, D) subject to the memory constraint
    (eq. 6-7). The paper solves an ILP with Gurobi after fixing D; here the knapsack is solved
    exactly by dynamic programming over memory units and cardinality, then T is evaluated for every
    cardinality and the best sum r / T is kept."""

    model: ModelSpec
    testbed: Testbed
    cost: CostModel = field(default_factory=CostModel)
    memory: MemoryModel = field(default_factory=MemoryModel)
    execution: Execution = Execution.PACKED
    unit_bytes: float = 128e6
    """Memory granularity of the knapsack, bytes."""

    def adapter_bytes_per_gpu(self, c: LoRAConfig, degree: int) -> float:
        """Per-GPU bytes an adapter adds to a job at `degree` (its LoRA state plus the base
        activations of its tokens)."""
        return (self.memory.lora_bytes(self.model, c) + self.memory.base_activation_bytes(self.model, c.tokens_per_iteration)) / degree

    def fits(self, c: LoRAConfig, degree: int) -> bool:
        return self.memory.fits(self.model, [c], degree, self.testbed)

    def minimum_degree(self, c: LoRAConfig) -> int | None:
        """Smallest power-of-two degree <= G on which the configuration fits alone (the Min GPU
        rule), never below the degree the base weights alone require."""
        d = self.model.minimum_degree(self.testbed.gpu, load_factor=self.testbed.load_factor, max_degree=self.testbed.gpu_count)
        while d <= self.testbed.gpu_count:
            if self.fits(c, d):
                return d
            d *= 2
        return None

    def best_pack(self, configs: list[LoRAConfig], degree: int) -> list[LoRAConfig] | None:
        """The best pack of `configs` on `degree` GPUs by eq. 6, or None when nothing fits."""
        headroom = self.memory.headroom_bytes_per_gpu(self.model, degree, self.testbed)
        if headroom <= 0:
            return None
        capacity = int(headroom / self.unit_bytes)
        items = [
            {"config": c, "weight": max(1, math.ceil(self.adapter_bytes_per_gpu(c, degree) / self.unit_bytes)), "value": c.rank}
            for c in configs
        ]
        items = [it for it in items if it["weight"] <= capacity]
        if not items:
            return None
        min_weight = min(it["weight"] for it in items)
        max_count = min(len(items), capacity // min_weight)
        if max_count < 1:
            return None

        width = capacity + 1
        dp = [[-1] * width for _ in range(max_count + 1)]
        dp[0] = [0] * width
        choice = [[[False] * width for _ in range(max_count + 1)] for _ in range(len(items))]
        for i, item in enumerate(items):
            n = min(i + 1, max_count)
            while n >= 1:
                c = capacity
                while c >= item["weight"]:
                    prev = dp[n - 1][c - item["weight"]]
                    if prev >= 0 and prev + item["value"] > dp[n][c]:
                        dp[n][c] = prev + item["value"]
                        choice[i][n][c] = True
                    c -= 1
                n -= 1

        best: tuple[float, list[LoRAConfig]] | None = None
        for n in range(1, max_count + 1):
            if dp[n][capacity] < 0:
                continue
            chosen: list[LoRAConfig] = []
            remaining_n, c = n, capacity
            i = len(items) - 1
            while remaining_n > 0 and i >= 0:
                if choice[i][remaining_n][c]:
                    chosen.append(items[i]["config"])
                    c -= items[i]["weight"]
                    remaining_n -= 1
                i -= 1
            if len(chosen) != n:
                continue
            f = sum(cc.rank for cc in chosen) / self.cost.step_seconds(self.model, self.testbed.gpu, chosen, degree, self.execution)
            if best is None or f > best[0]:
                best = (f, chosen)
        if best is None:
            return None
        chosen = best[1]

        f = self.cost.throughput(self.model, self.testbed.gpu, chosen, degree)
        chosen_ids = {c.id for c in chosen}
        leftovers = sorted((it for it in items if it["config"].id not in chosen_ids), key=lambda it: -it["value"])
        for item in leftovers:
            candidate = chosen + [item["config"]]
            if not self.memory.fits(self.model, candidate, degree, self.testbed):
                continue
            f2 = self.cost.throughput(self.model, self.testbed.gpu, candidate, degree)
            if f2 > f:
                chosen = candidate
                f = f2
        return chosen

    def dtm(self, gpus: int, configs: list[LoRAConfig], beam_width: int = 2) -> list[Pack]:
        """Algorithm 1 (DTM): for g available GPUs, try degrees g' = 2^floor(log2 g), g'/2, ..., 1;
        pack the best job for each, recurse on the remaining GPUs and configurations, and return the
        policy with the highest concurrent throughput sum_j F_j (eq. 1)."""
        policies: list[list[Pack]] = []
        self._dtm_helper(gpus, [], configs, beam_width, policies)

        def score(p: list[Pack]) -> float:
            return sum(
                sum(c.rank for c in pack.configs) / self.cost.step_seconds(self.model, self.testbed.gpu, pack.configs, pack.degree, self.execution)
                for pack in p
            )

        return max(policies, key=score, default=[])

    def _dtm_helper(self, gpus: int, current: list[Pack], configs: list[LoRAConfig], beam_width: int, policies: list[list[Pack]]) -> None:
        if gpus <= 0 or not configs:
            policies.append(current)
            return
        degree = 1 << int(math.log2(gpus))
        options: list[tuple[Pack, float]] = []
        while degree >= 1:
            chosen = self.best_pack(configs, degree)
            if chosen is not None:
                f = sum(c.rank for c in chosen) / self.cost.step_seconds(self.model, self.testbed.gpu, chosen, degree, self.execution)
                options.append((Pack(configs=chosen, degree=degree), f / degree))
            degree //= 2
        if not options:
            policies.append(current)
            return
        options.sort(key=lambda o: -o[1])
        for pack, _per_gpu in options[:beam_width]:
            used = {c.id for c in pack.configs}
            self._dtm_helper(gpus - pack.degree, current + [pack], [c for c in configs if c.id not in used], beam_width, policies)


@dataclass
class JobPlanner:
    """Algorithm 2 (the job planner) as an event simulation: whenever GPUs are free, call DTM on the
    remaining configurations, launch the packs, predict the next completion from the cost model, and
    release its GPUs."""

    packer: Packer
    beam_width: int = 2

    def schedule(self, configs: list[LoRAConfig], strategy_name: str = "PLoRA") -> Schedule:
        feasible = [c for c in configs if self.packer.minimum_degree(c) is not None]
        infeasible = [c for c in configs if self.packer.minimum_degree(c) is None]
        remaining = list(feasible)
        running: list[PackedJob] = []
        done: list[PackedJob] = []
        available = self.packer.testbed.gpu_count
        now = 0.0
        next_id = 0
        while remaining or running:
            if available > 0 and remaining:
                policy = self.packer.dtm(available, remaining, self.beam_width)
                if not policy:
                    if not running:
                        break
                else:
                    for pack in policy:
                        duration = self.packer.cost.job_seconds(self.packer.model, self.packer.testbed.gpu, pack.configs, pack.degree, self.packer.execution)
                        running.append(PackedJob(id=next_id, configs=pack.configs, degree=pack.degree, start_seconds=now, duration_seconds=duration))
                        next_id += 1
                        available -= pack.degree
                        used = {c.id for c in pack.configs}
                        remaining = [c for c in remaining if c.id not in used]
                    if available > 0 and remaining:
                        continue
            if not running:
                break
            next_end = min(j.end_seconds for j in running)
            now = next_end
            finished = [j for j in running if j.end_seconds <= now + 1e-9]
            running = [j for j in running if j.end_seconds > now + 1e-9]
            for j in finished:
                available += j.degree
                done.append(j)
        done.extend(running)
        return Schedule(
            strategy=strategy_name, model=self.packer.model.name, gpu_count=self.packer.testbed.gpu_count,
            jobs=sorted(done, key=lambda j: j.start_seconds), infeasible=infeasible,
        )


class BaselineKind(str, Enum):
    MIN_GPU = "Min GPU"
    MAX_GPU = "Max GPU"


@dataclass
class BaselineScheduler:
    """The paper's baselines (§4.1): one configuration per job, either on the minimum GPUs that fit
    (Min GPU, jobs run in parallel to fill the machine) or on all GPUs with one job at a time
    (Max GPU). Longest job first, which is the standard list-scheduling order for makespan."""

    packer: Packer
    kind: BaselineKind

    def schedule(self, configs: list[LoRAConfig]) -> Schedule:
        g = self.packer.testbed.gpu_count
        jobs: list[dict] = []
        infeasible: list[LoRAConfig] = []
        for c in configs:
            min_degree = self.packer.minimum_degree(c)
            if min_degree is None:
                infeasible.append(c)
                continue
            degree = min_degree if self.kind == BaselineKind.MIN_GPU else g
            duration = self.packer.cost.job_seconds(self.packer.model, self.packer.testbed.gpu, [c], degree, Execution.PACKED)
            jobs.append({"config": c, "degree": degree, "duration": duration})
        jobs.sort(key=lambda j: -j["duration"])

        running: list[PackedJob] = []
        done: list[PackedJob] = []
        available, now, next_id = g, 0.0, 0
        queue = list(jobs)
        while queue or running:
            launched = False
            i = 0
            while i < len(queue):
                if queue[i]["degree"] <= available:
                    j = queue.pop(i)
                    running.append(PackedJob(id=next_id, configs=[j["config"]], degree=j["degree"], start_seconds=now, duration_seconds=j["duration"]))
                    next_id += 1
                    available -= j["degree"]
                    launched = True
                else:
                    i += 1
            if launched and available > 0 and queue:
                continue
            if not running:
                break
            next_end = min(j.end_seconds for j in running)
            now = next_end
            finished = [j for j in running if j.end_seconds <= now + 1e-9]
            running = [j for j in running if j.end_seconds > now + 1e-9]
            for j in finished:
                available += j.degree
                done.append(j)
        done.extend(running)
        return Schedule(
            strategy=self.kind.value, model=self.packer.model.name, gpu_count=g,
            jobs=sorted(done, key=lambda j: j.start_seconds), infeasible=infeasible,
        )
