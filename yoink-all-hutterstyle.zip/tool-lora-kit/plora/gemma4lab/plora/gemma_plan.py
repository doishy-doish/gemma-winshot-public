from __future__ import annotations

from dataclasses import dataclass, field

from gemma4lab.core import competition
from gemma4lab.core.experiment import ExperimentRecord, PENDING_GPU
from gemma4lab.plora.cost_model import CostModel
from gemma4lab.plora.lora_config import FineTuningTask, LoRAConfig
from gemma4lab.plora.memory_model import MemoryModel
from gemma4lab.plora.planner import BaselineKind, BaselineScheduler, JobPlanner, Packer, Schedule
from gemma4lab.plora.specs import ModelSpec, Testbed
from gemma4lab.training.training_recipe import TrainingRecipe


def _gemma_memory_model() -> MemoryModel:
    """QLoRA keeps fp32 master weights for the adapter plus two Adam moments: 4 + 4 + 4 bytes per
    bf16 parameter."""
    return MemoryModel(gradient_factor=6)


@dataclass
class GemmaPLoRAOutcome:
    plora: Schedule
    one_adapter_per_kernel: Schedule
    configs: list[LoRAConfig]
    headroom_gb: float
    adapter_gb: float

    @property
    def plora_hours(self) -> float:
        return self.plora.makespan_hours

    @property
    def sequential_hours(self) -> float:
        return self.one_adapter_per_kernel.makespan_hours

    @property
    def speedup(self) -> float:
        return self.sequential_hours / self.plora_hours

    @property
    def plora_quota_hours(self) -> float:
        """Kaggle quota: 4x L4 counts double, 30 h per week."""
        return self.plora_hours * competition.QUAD_L4_MULTIPLIER

    @property
    def sequential_quota_hours(self) -> float:
        return self.sequential_hours * competition.QUAD_L4_MULTIPLIER


@dataclass
class GemmaPLoRAPlan:
    """PLoRA applied to this project: the tool-use LoRA for Gemma 4 31B (nf4 QLoRA) trained on
    Kaggle's 4x L4. Today the training kernel trains one r=16 adapter per 4.5 h budget
    (`TrainingRecipe.shipped`). The paper's question is how many adapter configurations could share
    that base model and that time."""

    testbed: Testbed = Testbed.kaggle_l4x4
    model: ModelSpec = ModelSpec.gemma4_31B_nf4
    cost: CostModel = field(default_factory=CostModel.gemma_on_l4)
    memory: MemoryModel = field(default_factory=_gemma_memory_model)
    sequence_length: int = 5835
    """Mean rendered sample length in the kept training set (484,321 tokens / 83 samples)."""
    epochs: int = TrainingRecipe.shipped.epochs
    samples: int = 83

    def candidate_configs(self) -> list[LoRAConfig]:
        """The configuration family a PLoRA sweep would explore for the tool-use adapter: ranks
        around the recipe's 16, learning rates around 1e-4, alpha = 2r as in the recipe. 9
        configurations."""
        out = []
        for r in (8, 16, 32):
            for lr in (5e-5, 1e-4, 2e-4):
                out.append(LoRAConfig(
                    id=len(out), task=FineTuningTask.GEMMA_TOOL_USE, learning_rate=lr, batch_size=1,
                    rank=r, alpha=2 * r, sequence_length=self.sequence_length, epochs=self.epochs,
                    steps_override=self.samples * self.epochs,
                ))
        return out

    def plan(self) -> GemmaPLoRAOutcome:
        configs = self.candidate_configs()
        packer = Packer(model=self.model, testbed=self.testbed, cost=self.cost, memory=self.memory)
        plora = JobPlanner(packer=packer).schedule(configs, "PLoRA on 4x L4")
        sequential = BaselineScheduler(packer=packer, kind=BaselineKind.MAX_GPU).schedule(configs)
        headroom = self.memory.headroom_bytes_per_gpu(self.model, self.testbed.gpu_count, self.testbed)
        adapter = packer.adapter_bytes_per_gpu(configs[3], self.testbed.gpu_count)  # r=16 reference
        return GemmaPLoRAOutcome(
            plora=plora, one_adapter_per_kernel=sequential, configs=configs,
            headroom_gb=headroom / 1e9, adapter_gb=adapter / 1e9,
        )

    def proposed_ledger_rows(self, outcome: GemmaPLoRAOutcome, starting_index: int = 20) -> list[ExperimentRecord]:
        """Ledger rows the experiment-analyst could add: a GPU idea per packed job, phrased by the
        project's rules (one change per experiment; GPU rows start as `pending_gpu`; local results
        never justify adoption)."""
        rows = []
        for i, job in enumerate(outcome.plora.jobs):
            desc = ", ".join(f"r{c.rank}/lr{c.learning_rate}" for c in job.configs)
            rows.append(ExperimentRecord(
                exp_id=f"I{starting_index + i}", status=PENDING_GPU, priority=str(5 + i), parent="E08",
                prompt=f"Does packing {len(job.configs)} tool-use adapters ({desc}) into one 4x L4 kernel reproduce PLoRA's throughput gain on Gemma 4 31B?",
                input=f"kernels/train with packed adapters: shared nf4 base, {len(job.configs)} LoRA configs per step ({desc}), {job.duration_seconds / 3600:.1f} h projected",
                output="",
                feedback="Projection from Gemma4PLoRA cost model; offline only. Pick the best adapter by held-out next-tool accuracy, then submit it as one experiment.",
            ))
        return rows
