from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class GPUSpec:
    """A GPU type of the paper's testbeds (§4.1) plus this project's Kaggle L4."""

    name: str
    memory_gb: float
    peak_tflops: float
    """Dense bf16 tensor-core peak, TFLOP/s."""
    tp_overhead_per_doubling: float
    """Interconnect communication overhead per doubling of tensor-parallel degree (fraction of step time)."""


GPUSpec.a100_40 = GPUSpec("A100-40GB", memory_gb=40, peak_tflops=312, tp_overhead_per_doubling=0.08)
GPUSpec.a10_24 = GPUSpec("A10-24GB", memory_gb=24, peak_tflops=125, tp_overhead_per_doubling=0.20)
GPUSpec.l4_24 = GPUSpec("L4-24GB", memory_gb=24, peak_tflops=121, tp_overhead_per_doubling=0.20)


@dataclass(frozen=True)
class ModelSpec:
    """A transformer base model as the memory model needs it (Appendix B): projection shapes,
    layer count, parameters."""

    name: str
    hidden: int
    intermediate: int
    layers: int
    heads: int
    kv_heads: int
    vocab: int
    parameters: float
    bytes_per_weight: float = 2
    """Bytes per base weight: 2 for bf16, 0.5 for nf4 QLoRA (§E.3)."""
    activation_factor: float = 2
    """Base-model activation bytes kept per token per layer, after activation checkpointing, divided by
    hidden. Gemma 4 uses 4, matching the measured 0.95 MB/token/GPU of train_out/metrics.json."""
    measured_lora_params_at_rank16: float | None = None
    """Overrides the analytical LoRA parameter count (measured: 122.7M params at r=16 over 410
    projections for Gemma 4 31B, since the 10 global-attention layers have no v_proj adapter)."""

    @property
    def head_dim(self) -> int:
        return self.hidden // self.heads

    @property
    def kv_dim(self) -> int:
        return self.kv_heads * self.head_dim

    @property
    def projection_shapes(self) -> list[tuple[str, int, int]]:
        """The seven LoRA-able projections of Appendix B eq. 19: (name, h_in, h_out) per layer."""
        return [
            ("q_proj", self.hidden, self.hidden), ("k_proj", self.hidden, self.kv_dim),
            ("v_proj", self.hidden, self.kv_dim), ("o_proj", self.hidden, self.hidden),
            ("gate_proj", self.hidden, self.intermediate), ("up_proj", self.hidden, self.intermediate),
            ("down_proj", self.intermediate, self.hidden),
        ]

    def minimum_degree(self, gpu: GPUSpec, load_factor: float = 0.9, max_degree: int = 8) -> int:
        """Smallest tensor-parallel degree whose per-GPU share of the base weights stays under 70% of
        the card."""
        d = 1
        while d <= max_degree:
            weights = self.parameters * self.bytes_per_weight / d / 1e9
            if weights <= 0.7 * gpu.memory_gb:
                return d
            d *= 2
        return max_degree


ModelSpec.qwen2_5_3B = ModelSpec("Qwen2.5-3B", hidden=2048, intermediate=11008, layers=36, heads=16, kv_heads=2, vocab=151_936, parameters=3.09e9)
ModelSpec.qwen2_5_7B = ModelSpec("Qwen2.5-7B", hidden=3584, intermediate=18944, layers=28, heads=28, kv_heads=4, vocab=152_064, parameters=7.62e9)
ModelSpec.qwen2_5_14B = ModelSpec("Qwen2.5-14B", hidden=5120, intermediate=13824, layers=48, heads=40, kv_heads=8, vocab=152_064, parameters=14.77e9)
ModelSpec.qwen2_5_32B = ModelSpec("Qwen2.5-32B", hidden=5120, intermediate=27648, layers=64, heads=40, kv_heads=8, vocab=152_064, parameters=32.76e9)
ModelSpec.llama3_2_3B = ModelSpec("Llama-3.2-3B", hidden=3072, intermediate=8192, layers=28, heads=24, kv_heads=8, vocab=128_256, parameters=3.21e9)
ModelSpec.llama3_1_8B = ModelSpec("Llama-3.1-8B", hidden=4096, intermediate=14336, layers=32, heads=32, kv_heads=8, vocab=128_256, parameters=8.03e9)
ModelSpec.gemma4_31B_nf4 = ModelSpec(
    "Gemma-4-31B (nf4 QLoRA)", hidden=5376, intermediate=21504, layers=60, heads=32, kv_heads=16,
    vocab=262_144, parameters=31e9, bytes_per_weight=0.5, activation_factor=4, measured_lora_params_at_rank16=122.7e6,
)
ModelSpec.gemma4_12B_nf4 = ModelSpec("Gemma-4-12B (nf4 QLoRA)", hidden=3840, intermediate=15360, layers=48, heads=16, kv_heads=8, vocab=262_144, parameters=12e9, bytes_per_weight=0.5, activation_factor=4)
ModelSpec.gemma4_E4B_nf4 = ModelSpec("Gemma-4-E4B (nf4 QLoRA)", hidden=2560, intermediate=10240, layers=35, heads=8, kv_heads=2, vocab=262_144, parameters=4.4e9, bytes_per_weight=0.5, activation_factor=4)
ModelSpec.gemma4_E2B_nf4 = ModelSpec("Gemma-4-E2B (nf4 QLoRA)", hidden=2048, intermediate=8192, layers=30, heads=8, kv_heads=2, vocab=262_144, parameters=2.0e9, bytes_per_weight=0.5, activation_factor=4)
ModelSpec.gemma_challenge_family = [ModelSpec.gemma4_31B_nf4, ModelSpec.gemma4_12B_nf4, ModelSpec.gemma4_E4B_nf4, ModelSpec.gemma4_E2B_nf4]
ModelSpec.qwen_family = [ModelSpec.qwen2_5_3B, ModelSpec.qwen2_5_7B, ModelSpec.qwen2_5_14B, ModelSpec.qwen2_5_32B]
ModelSpec.llama_family = [ModelSpec.llama3_2_3B, ModelSpec.llama3_1_8B]


@dataclass(frozen=True)
class Testbed:
    """A GPU pool: the paper's instances have 8 GPUs; this project's Kaggle kernel has 4."""

    gpu: GPUSpec
    gpu_count: int
    load_factor: float = 0.9
    """Memory load factor C in eq. 2 / Appendix B (fragmentation headroom)."""

    @property
    def usable_memory_per_gpu_bytes(self) -> float:
        return self.load_factor * self.gpu.memory_gb * 1e9


Testbed.p4d = Testbed(gpu=GPUSpec.a100_40, gpu_count=8)
Testbed.g5 = Testbed(gpu=GPUSpec.a10_24, gpu_count=8)
Testbed.kaggle_l4x4 = Testbed(gpu=GPUSpec.l4_24, gpu_count=4)
