from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field

import numpy as np

from gemma4lab.plora.lora_config import SplitMix64


@dataclass(frozen=True)
class LoRAAdapter:
    """One LoRA adapter on a d x k projection: A is d x r, B is r x k (Figure 1)."""

    a: np.ndarray
    b: np.ndarray

    def __post_init__(self):
        assert self.a.shape[1] == self.b.shape[0]

    @property
    def rank(self) -> int:
        return self.a.shape[1]

    @staticmethod
    def random(rows: int, cols: int, rank: int, scale: float, rng: SplitMix64) -> "LoRAAdapter":
        a = _random_matrix(rows, rank, scale, rng)
        b = _random_matrix(rank, cols, scale, rng)
        return LoRAAdapter(a=a, b=b)


def _random_matrix(rows: int, cols: int, scale: float, rng: SplitMix64) -> np.ndarray:
    data = np.empty(rows * cols, dtype=np.float32)
    for i in range(rows * cols):
        data[i] = (rng.next_double() * 2 - 1) * scale
    return data.reshape(rows, cols)


@dataclass(frozen=True)
class LoRAGradients:
    """Gradients of one adapter's forward y = x A B for an upstream gradient dy (the four cases of
    Appendix C.2)."""

    d_b: np.ndarray
    """Case 1: dB = (xA)^T dy, tiled over the output dimension k."""
    d_a: np.ndarray
    """Case 3: dA = x^T (dy B^T), reduction over the sequence."""
    d_x: np.ndarray
    """Cases 2 and 4: dx = (dy B^T) A^T, reductions over k then r."""


def forward(x: np.ndarray, adapter: LoRAAdapter) -> np.ndarray:
    return x @ adapter.a @ adapter.b


def backward(x: np.ndarray, dy: np.ndarray, adapter: LoRAAdapter) -> LoRAGradients:
    xa = x @ adapter.a                       # s x r
    d_b = xa.T @ dy                          # r x k   (case 1)
    dy_bt = dy @ adapter.b.T                 # s x r   (case 2: input grad of the B projection)
    d_a = x.T @ dy_bt                        # d x r   (case 3)
    d_x = dy_bt @ adapter.a.T                # s x d   (case 4)
    return LoRAGradients(d_b=d_b, d_a=d_a, d_x=d_x)


def sequential_forward(inputs: list[np.ndarray], adapters: list[LoRAAdapter]) -> list[np.ndarray]:
    """Sequential baseline: adapters one after another."""
    return [forward(x, a) for x, a in zip(inputs, adapters)]


def sequential_backward(inputs: list[np.ndarray], upstream: list[np.ndarray], adapters: list[LoRAAdapter]) -> list[LoRAGradients]:
    return [backward(inputs[i], upstream[i], adapters[i]) for i in range(len(adapters))]


def _concatenate(ms: list[np.ndarray]) -> np.ndarray:
    return np.concatenate(ms, axis=0)


def _slice(packed: np.ndarray, rows: list[np.ndarray], index: int) -> np.ndarray:
    start = sum(r.shape[0] for r in rows[:index])
    count = rows[index].shape[0]
    return packed[start:start + count]


def packed_forward(inputs: list[np.ndarray], adapters: list[LoRAAdapter]) -> list[np.ndarray]:
    """Packed: the inputs are concatenated along the sequence dimension into one buffer (as the
    kernels see them) and the adapter tiles run concurrently."""
    packed = _concatenate(inputs)
    with ThreadPoolExecutor() as pool:
        futures = [pool.submit(forward, _slice(packed, inputs, i), adapters[i]) for i in range(len(adapters))]
        return [f.result() for f in futures]


def packed_backward(inputs: list[np.ndarray], upstream: list[np.ndarray], adapters: list[LoRAAdapter]) -> list[LoRAGradients]:
    packed_x = _concatenate(inputs)
    packed_dy = _concatenate(upstream)
    with ThreadPoolExecutor() as pool:
        futures = [
            pool.submit(backward, _slice(packed_x, inputs, i), _slice(packed_dy, upstream, i), adapters[i])
            for i in range(len(adapters))
        ]
        return [f.result() for f in futures]


def padded_rank_flop_waste(adapters: list[LoRAAdapter]) -> float:
    """The "pad every rank to r_max and run one block-diagonal batch" alternative the paper avoids:
    its FLOP count relative to the exact per-adapter computation."""
    r_max = max((a.rank for a in adapters), default=0)
    exact = sum(a.rank for a in adapters)
    return 1.0 if exact == 0 else (r_max * len(adapters)) / exact


@dataclass(frozen=True)
class PackedLoRABenchmarkResult:
    adapters: int
    forward_speedup: float
    backward_speedup: float
    max_abs_difference: float
    padded_flop_waste: float
    sequential_seconds: float
    packed_seconds: float


@dataclass
class PackedLoRABenchmark:
    """Table 7's experiment shape on the CPU: n adapters, hidden d, output k, sequence s, mixed
    ranks."""

    sequence: int = 128
    hidden: int = 256
    output: int = 256
    ranks: list[int] = field(default_factory=lambda: [8, 16, 32, 64])

    def run(self, adapters: int, seed: int = 7) -> PackedLoRABenchmarkResult:
        rng = SplitMix64(seed)
        n = adapters
        adapter_list = [
            LoRAAdapter.random(self.hidden, self.output, self.ranks[i % len(self.ranks)], 0.1, rng)
            for i in range(n)
        ]
        inputs = [_random_matrix(self.sequence, self.hidden, 1.0, rng) for _ in range(n)]
        upstream = [_random_matrix(self.sequence, self.output, 1.0, rng) for _ in range(n)]

        t0 = time.monotonic()
        seq_f = sequential_forward(inputs, adapter_list)
        t1 = time.monotonic()
        seq_b = sequential_backward(inputs, upstream, adapter_list)
        t2 = time.monotonic()
        pack_f = packed_forward(inputs, adapter_list)
        t3 = time.monotonic()
        pack_b = packed_backward(inputs, upstream, adapter_list)
        t4 = time.monotonic()

        diff = 0.0
        for i in range(n):
            diff = max(diff, float(np.abs(seq_f[i] - pack_f[i]).max()))
            diff = max(
                diff,
                float(np.abs(seq_b[i].d_a - pack_b[i].d_a).max()),
                float(np.abs(seq_b[i].d_b - pack_b[i].d_b).max()),
                float(np.abs(seq_b[i].d_x - pack_b[i].d_x).max()),
            )
        seq_seconds = t2 - t0
        pack_seconds = t4 - t2
        return PackedLoRABenchmarkResult(
            adapters=n,
            forward_speedup=(t1 - t0) / max(1e-9, t3 - t2),
            backward_speedup=(t2 - t1) / max(1e-9, t4 - t3),
            max_abs_difference=diff,
            padded_flop_waste=padded_rank_flop_waste(adapter_list),
            sequential_seconds=seq_seconds, packed_seconds=pack_seconds,
        )
