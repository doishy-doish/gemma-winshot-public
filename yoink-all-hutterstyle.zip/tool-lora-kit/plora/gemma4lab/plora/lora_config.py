from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum


class FineTuningTask(str, Enum):
    """The four downstream tasks of §4.1 with their training-set sizes (one epoch defines a
    configuration's step count)."""

    GSM8K = "gsm8k"
    MRPC = "mrpc"
    COLA = "cola"
    WNLI = "wnli"
    GEMMA_TOOL_USE = "gemma_tool_use"
    """This project's rejection-sampled tool-use trajectories (kernels/train/train.py)."""

    @property
    def training_examples(self) -> int:
        return {
            FineTuningTask.GSM8K: 7473, FineTuningTask.MRPC: 3668, FineTuningTask.COLA: 8551,
            FineTuningTask.WNLI: 635, FineTuningTask.GEMMA_TOOL_USE: 83,
        }[self]


FineTuningTask.paper_tasks = [FineTuningTask.GSM8K, FineTuningTask.MRPC, FineTuningTask.COLA, FineTuningTask.WNLI]


@dataclass(frozen=True)
class LoRAConfig:
    """One LoRA fine-tuning configuration: the four knobs of Table 1 plus the task that fixes its
    data."""

    id: int
    task: FineTuningTask
    learning_rate: float
    batch_size: int
    rank: int
    alpha: float
    sequence_length: int = 1024
    epochs: int = 1
    steps_override: int | None = None
    """Explicit optimizer-step count (otherwise one epoch over the task's training set at batch_size)."""

    @property
    def tokens_per_iteration(self) -> int:
        """Tokens the base model must process per iteration for this adapter (inputs are replicated
        per adapter, §C.1)."""
        return self.batch_size * self.sequence_length

    @property
    def steps(self) -> int:
        if self.steps_override is not None:
            return self.steps_override
        return math.ceil((self.task.training_examples * self.epochs) / self.batch_size)

    @property
    def label(self) -> str:
        return f"{self.task.value} lr={self.learning_rate} bs={self.batch_size} r={self.rank} a={self.alpha}"


class SplitMix64:
    """Tiny deterministic PRNG so the 120-configuration sample is reproducible across runs and
    machines."""

    MASK = (1 << 64) - 1

    def __init__(self, seed: int):
        self.state = seed & self.MASK

    def next(self) -> int:
        self.state = (self.state + 0x9E3779B97F4A7C15) & self.MASK
        z = self.state
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & self.MASK
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & self.MASK
        return z ^ (z >> 31)

    def next_double(self) -> float:
        return (self.next() >> 11) / float(1 << 53)


LEARNING_RATES = [2e-5, 5e-5, 1e-4, 2e-4, 4e-4]
BATCH_SIZES = [1, 2, 4, 8, 16, 32]
SMALL_BATCH_SIZES = [1, 2, 4]
RANKS = [8, 16, 32, 64, 128]
ALPHA_MULTIPLIERS = [0.25, 0.5, 1, 2, 4]


def full_grid(task: FineTuningTask, sequence_length: int = 1024) -> list[LoRAConfig]:
    """The full grid of Table 1 for one task: 5 x 6 x 5 x 5 = 750 configurations."""
    out = []
    for lr in LEARNING_RATES:
        for bs in BATCH_SIZES:
            for r in RANKS:
                for m in ALPHA_MULTIPLIERS:
                    out.append(LoRAConfig(id=len(out), task=task, learning_rate=lr, batch_size=bs, rank=r, alpha=r * m, sequence_length=sequence_length))
    return out


def paper_120(batch_sizes: list[int] | None = None, seed: int = 2508, sequence_length: int = 1024) -> list[LoRAConfig]:
    """The paper selected 120 configurations "based on a detailed empirical sensitivity analysis"
    (Appendix E.1) without listing them. We take 30 per task: a deterministic, seeded, stratified
    sample of the grid that keeps every rank and every batch size equally represented."""
    batch_sizes = batch_sizes if batch_sizes is not None else BATCH_SIZES
    rng = SplitMix64(seed)
    out: list[LoRAConfig] = []
    per_task = 30
    repeats = max(1, per_task // (len(batch_sizes) * len(RANKS)))
    for task in FineTuningTask.paper_tasks:
        i = 0
        task_count = 0
        done = False
        for bs in batch_sizes:
            if done:
                break
            for r in RANKS:
                if done:
                    break
                for _ in range(repeats):
                    if task_count >= per_task:
                        done = True
                        break
                    lr = LEARNING_RATES[rng.next() % len(LEARNING_RATES)]
                    m = ALPHA_MULTIPLIERS[i % len(ALPHA_MULTIPLIERS)]
                    out.append(LoRAConfig(id=len(out), task=task, learning_rate=lr, batch_size=bs, rank=r, alpha=r * m, sequence_length=sequence_length))
                    i += 1
                    task_count += 1
    return out


def identical(count: int, batch_size: int, rank: int = 32, task: FineTuningTask = FineTuningTask.GSM8K) -> list[LoRAConfig]:
    """Identical configurations for the job-throughput study of §4.3 (rank fixed at 32, one batch
    size)."""
    return [LoRAConfig(id=i, task=task, learning_rate=1e-4, batch_size=batch_size, rank=rank, alpha=float(rank)) for i in range(count)]


TABLE4_BEST = [
    ("Qwen2.5-3B", FineTuningTask.MRPC, 16, 4e-5, 1, 1), ("Qwen2.5-3B", FineTuningTask.COLA, 64, 4e-4, 1, 0.25),
    ("Qwen2.5-3B", FineTuningTask.WNLI, 32, 2e-4, 2, 1), ("Qwen2.5-3B", FineTuningTask.GSM8K, 32, 1e-4, 2, 1),
    ("Qwen2.5-7B", FineTuningTask.MRPC, 32, 6e-5, 1, 1), ("Qwen2.5-7B", FineTuningTask.COLA, 32, 8e-5, 1, 0.5),
    ("Qwen2.5-7B", FineTuningTask.WNLI, 32, 2e-4, 4, 0.5), ("Qwen2.5-7B", FineTuningTask.GSM8K, 16, 3e-4, 1, 1),
]
