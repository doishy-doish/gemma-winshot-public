from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from pathlib import Path

from gemma4lab.plora.cost_model import CostModel, CostModelParameters
from gemma4lab.plora.specs import GPUSpec


@dataclass(frozen=True)
class Point:
    tokens: int
    seconds: float
    peak_gib: float
    ok: bool


@dataclass(frozen=True)
class PackPoint:
    adapters: int
    tokens_per_adapter: int
    seconds: float
    peak_gib: float
    ok: bool


@dataclass(frozen=True)
class ModelRun:
    model: str
    single: list[Point]
    packed: list[PackPoint]
    naive: list[PackPoint]
    layers: int | None = None
    hidden: int | None = None
    wrapped_projections: int | None = None
    error: str | None = None


def _num(d: dict, key: str, default: float = math.nan) -> float:
    v = d.get(key)
    return float(v) if isinstance(v, (int, float)) else default


def _point(d: dict) -> Point:
    return Point(tokens=int(_num(d, "tokens", 0)), seconds=_num(d, "seconds"), peak_gib=_num(d, "peak_gib"), ok=bool(d.get("ok", False)))


def _pack_point(d: dict) -> PackPoint:
    return PackPoint(
        adapters=int(_num(d, "adapters", 0)), tokens_per_adapter=int(_num(d, "tokens_per_adapter", 0)),
        seconds=_num(d, "seconds"), peak_gib=_num(d, "peak_gib"), ok=bool(d.get("ok", False)),
    )


@dataclass
class PLoRABenchmark:
    """Reads `plora_bench.json` written by `kernels/plora/plora_bench.py` on a real GPU (Colab or
    Kaggle) and turns the measurements into cost-model parameters, replacing the assumptions the
    paper-calibrated model otherwise uses."""

    gpu: str
    gpu_count: int
    rank: int
    models: list[ModelRun] = field(default_factory=list)

    @classmethod
    def from_json(cls, data: dict) -> "PLoRABenchmark":
        return cls(
            gpu=data.get("gpu", "?"), gpu_count=int(_num(data, "gpus", 1)), rank=int(_num(data, "rank", 16)),
            models=[
                ModelRun(
                    model=m.get("model", "?"), layers=m.get("layers"), hidden=m.get("hidden"),
                    single=[_point(p) for p in m.get("single", [])],
                    packed=[_pack_point(p) for p in m.get("packed", [])],
                    naive=[_pack_point(p) for p in m.get("naive", [])],
                    wrapped_projections=m.get("wrapped_projections"), error=m.get("error"),
                )
                for m in data.get("models", [])
            ],
        )

    @classmethod
    def from_file(cls, path: str | Path) -> "PLoRABenchmark":
        return cls.from_json(json.loads(Path(path).read_text()))

    @dataclass(frozen=True)
    class Fit:
        """Fitted parameters for one model: per-token cost at saturation, the floor T_sat (p-norm,
        p = 3) and the measured throughput gain of packing."""

        model: str
        seconds_per_token: float
        saturation_tokens: float
        packed_gain: list[tuple[int, float]]
        kernel_speedup: list[tuple[int, float]]
        peak_gib_single: list[tuple[int, float]]

    def fit(self, run: ModelRun, gpu_count: int | None = None) -> "PLoRABenchmark.Fit | None":
        """Least-squares fit of t(s) = c x (s^3 + T^3)^(1/3) over the single-adapter points, by a
        1-D search on T."""
        pts = [p for p in run.single if p.ok and math.isfinite(p.seconds) and p.tokens > 0]
        if len(pts) < 2:
            return None

        def residual(t: float) -> tuple[float, float]:
            shapes = [(p.tokens ** 3 + t ** 3) ** (1 / 3) for p in pts]
            c = sum(p.seconds * s for p, s in zip(pts, shapes)) / sum(s * s for s in shapes)
            err = sum((p.seconds - c * s) ** 2 for p, s in zip(pts, shapes))
            return c, err

        best_t = 0.0
        best = residual(0)
        t = 32.0
        while t <= 131_072:
            r = residual(t)
            if r[1] < best[1]:
                best = r
                best_t = t
            t *= 1.25

        g = gpu_count if gpu_count is not None else self.gpu_count
        gains = []
        for p in run.packed:
            if not p.ok:
                continue
            one = next((x for x in run.packed if x.adapters == 1 and x.ok), None)
            if one is None:
                single_match = next((s for s in run.single if s.tokens == p.tokens_per_adapter and s.ok), None)
                if single_match is None:
                    continue
                one_seconds = single_match.seconds
            else:
                one_seconds = one.seconds
            gains.append((p.adapters, p.adapters * one_seconds / p.seconds))

        speedups = []
        for n in run.naive:
            if not n.ok:
                continue
            p = next((x for x in run.packed if x.adapters == n.adapters and x.ok), None)
            if p is None:
                continue
            speedups.append((n.adapters, n.seconds / p.seconds))

        return PLoRABenchmark.Fit(
            model=run.model, seconds_per_token=best[0], saturation_tokens=best_t,
            packed_gain=gains, kernel_speedup=speedups,
            peak_gib_single=[(p.tokens, p.peak_gib) for p in pts],
        )

    def cost_model(self, run: ModelRun, lora_share: float = 0.15) -> CostModel | None:
        """A cost model whose floor and per-token cost come from the benchmark instead of the
        paper."""
        f = self.fit(run)
        if f is None:
            return None
        group_overhead = 1 + GPUSpec.l4_24.tp_overhead_per_doubling * math.log2(max(1, self.gpu_count))
        p = CostModelParameters(
            measured_seconds_per_token_equivalent=f.seconds_per_token * self.gpu_count / group_overhead,
            saturation_tokens_override=f.saturation_tokens, lora_share_override=lora_share,
        )
        return CostModel(parameters=p)

    def markdown(self) -> str:
        out = [
            "| Model | GPU | floor T_sat (tokens) | s/token saturated | packed gain by adapters | packed-vs-naive speedup | peak GiB (1 adapter) |",
            "|---|---|---|---|---|---|---|",
        ]
        for run in self.models:
            if run.error:
                out.append(f"| {run.model} | {self.gpu} | error | {run.error[:60]} | | | |")
                continue
            f = self.fit(run)
            if f is None:
                out.append(f"| {run.model} | {self.gpu} | too few points | | | | |")
                continue
            gain_str = ", ".join(f"{a}: {g:.2f}x" for a, g in f.packed_gain)
            speedup_str = ", ".join(f"{a}: {s:.2f}x" for a, s in f.kernel_speedup)
            peak_str = ", ".join(f"{t}t {g:.1f}" for t, g in f.peak_gib_single)
            out.append(
                f"| {run.model} | {self.gpu} x{self.gpu_count} | {f.saturation_tokens:.0f} | {f.seconds_per_token:.2e} | "
                f"{gain_str} | {speedup_str} | {peak_str} |"
            )
        return "\n".join(out)
