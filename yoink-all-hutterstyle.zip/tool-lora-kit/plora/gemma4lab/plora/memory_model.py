from __future__ import annotations

from dataclasses import dataclass

from gemma4lab.plora.lora_config import LoRAConfig
from gemma4lab.plora.specs import ModelSpec, Testbed

ALL_COMPONENTS = frozenset({"q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"})


@dataclass
class MemoryModel:
    """Appendix B of the paper: memory of a packed job = base model + sum_k LoRA_k, where each
    adapter costs parameters, gradient/optimizer state and activations, all divided by the
    tensor-parallel degree."""

    bytes_per_parameter: float = 2
    """Training precision bytes per parameter (c_prec), bf16."""
    gradient_factor: float = 3
    """c_grad: set to 3 in AdamW, representing momentum, velocity, and primary gradients."""
    components: frozenset[str] = ALL_COMPONENTS
    """Which of the seven components carry LoRA (indicator I_i in eq. 19). Default: all seven."""
    runtime_overhead_bytes: float = 1.5e9
    """Fixed per-process overhead (CUDA context, allocator, workspace), bytes."""
    logits_bytes_per_token: float = 0
    """Bytes of logits kept per token. 0 = chunked cross-entropy; set to 4 x vocab for frameworks that
    materialise the full fp32 logits."""

    def lora_parameter_count(self, model: ModelSpec, rank: int) -> float:
        """Eq. 19 + parameter term: n_layers x sum_i (h_in r + h_out r) x c_prec."""
        if model.measured_lora_params_at_rank16 is not None:
            return model.measured_lora_params_at_rank16 * rank / 16.0
        count = 0.0
        for name, h_in, h_out in model.projection_shapes:
            if name in self.components:
                count += h_in * rank + rank * h_out
        return count * model.layers

    def lora_parameter_bytes(self, model: ModelSpec, rank: int) -> float:
        return self.lora_parameter_count(model, rank) * self.bytes_per_parameter

    def lora_gradient_bytes(self, model: ModelSpec, rank: int) -> float:
        """M_lora_grad = c_grad x M_lora_param."""
        return self.gradient_factor * self.lora_parameter_bytes(model, rank)

    def lora_activation_bytes(self, model: ModelSpec, rank: int, tokens: int) -> float:
        """M_lora_act = b x s x r x c_prec per adapted component per layer: the low-rank intermediate
        kept for backward."""
        adapted = sum(1 for name, _, _ in model.projection_shapes if name in self.components)
        return tokens * rank * self.bytes_per_parameter * (adapted * model.layers)

    def lora_bytes(self, model: ModelSpec, config: LoRAConfig) -> float:
        """Eq. 20 for one adapter, before any sharding."""
        return (
            self.lora_parameter_bytes(model, config.rank)
            + self.lora_gradient_bytes(model, config.rank)
            + self.lora_activation_bytes(model, config.rank, config.tokens_per_iteration)
        )

    def base_weight_bytes(self, model: ModelSpec) -> float:
        return model.parameters * model.bytes_per_weight

    def base_activation_bytes(self, model: ModelSpec, tokens: int) -> float:
        """M_base_act: emb + attn + mlp activations per token after checkpointing, plus any logits
        kept."""
        return tokens * model.hidden * model.layers * model.activation_factor * self.bytes_per_parameter + tokens * self.logits_bytes_per_token

    def job_bytes_per_gpu(self, model: ModelSpec, configs: list[LoRAConfig], degree: int) -> float:
        """Per-GPU memory of a packed job with tensor-parallel degree `degree` (Appendix B.0.1:
        weights, activations and adapters are all divided by d_tp)."""
        tokens = sum(c.tokens_per_iteration for c in configs)
        base = self.base_weight_bytes(model) + self.base_activation_bytes(model, tokens)
        lora = sum(self.lora_bytes(model, c) for c in configs)
        return (base + lora) / degree + self.runtime_overhead_bytes

    def fits(self, model: ModelSpec, configs: list[LoRAConfig], degree: int, testbed: Testbed) -> bool:
        """Constraint (2): M_base + sum H_k M_lora,k <= C x M_gpu x d."""
        return self.job_bytes_per_gpu(model, configs, degree) <= testbed.usable_memory_per_gpu_bytes

    def headroom_bytes_per_gpu(self, model: ModelSpec, degree: int, testbed: Testbed) -> float:
        """Bytes still free on each GPU after the base model alone (what adapters can be packed
        into)."""
        return testbed.usable_memory_per_gpu_bytes - self.job_bytes_per_gpu(model, [], degree)


def gib(bytes_value: float) -> str:
    return f"{bytes_value / 1_073_741_824:.2f} GiB"


def gb(bytes_value: float) -> str:
    return f"{bytes_value / 1e9:.2f} GB"
