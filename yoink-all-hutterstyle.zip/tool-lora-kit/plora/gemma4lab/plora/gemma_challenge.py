from __future__ import annotations

import math
from dataclasses import dataclass, field, replace

from gemma4lab.core import competition
from gemma4lab.core.experiment import ExperimentRecord, PENDING_GPU
from gemma4lab.plora.cost_model import CostModel, CostModelParameters
from gemma4lab.plora.lora_config import FineTuningTask, LoRAConfig, identical
from gemma4lab.plora.memory_model import MemoryModel
from gemma4lab.plora.planner import BaselineKind, BaselineScheduler, JobPlanner, Packer, Schedule
from gemma4lab.plora.specs import ModelSpec, Testbed
from gemma4lab.training.training_recipe import TrainingRecipe


def _gemma_memory_model() -> MemoryModel:
    return MemoryModel(gradient_factor=6)


@dataclass(frozen=True)
class ChallengeRow:
    model: str
    floor_tokens: float
    configs: int
    min_degree: int
    headroom_gb: float
    adapter_gb: float
    adapters_that_fit: int
    plora: Schedule
    one_adapter_per_kernel: Schedule

    @property
    def plora_hours(self) -> float:
        return self.plora.makespan_hours

    @property
    def sequential_hours(self) -> float:
        return self.one_adapter_per_kernel.makespan_hours

    @property
    def speedup(self) -> float:
        return self.sequential_hours / self.plora_hours

    @property
    def plora_quota_hours(self) -> float:
        return self.plora_hours * competition.QUAD_L4_MULTIPLIER

    @property
    def sequential_quota_hours(self) -> float:
        return self.sequential_hours * competition.QUAD_L4_MULTIPLIER

    @property
    def sweeps_per_week_plora(self) -> float:
        """Sweeps per 30 h week at each strategy."""
        return competition.WEEKLY_GPU_QUOTA_HOURS / max(0.01, self.plora_quota_hours)

    @property
    def sweeps_per_week_sequential(self) -> float:
        return competition.WEEKLY_GPU_QUOTA_HOURS / max(0.01, self.sequential_quota_hours)


@dataclass
class GemmaChallengeStudy:
    """PLoRA for the models this challenge actually allows. The paper studied Qwen 2.5 and Llama 3
    on 8x A100; the competition scores `gemma-4-{31b,12b,e4b,e2b}-it-qat-w4a16-ct`, and this project
    trains adapters for them on Kaggle's 4x L4 with nf4 QLoRA."""

    testbed: Testbed = Testbed.kaggle_l4x4
    models: list[ModelSpec] = field(default_factory=lambda: list(ModelSpec.gemma_challenge_family))
    sequence_length: int = 5835
    samples: int = 83
    epochs: int = TrainingRecipe.shipped.epochs
    ranks: list[int] = field(default_factory=lambda: [8, 16, 32])
    learning_rates: list[float] = field(default_factory=lambda: [5e-5, 1e-4, 2e-4])
    floors: list[float] = field(default_factory=lambda: [128, 2048, 11832])
    """Floors (token-equivalents per GPU per step) to sweep: compute-bound, moderate, and the
    paper's A100 value."""
    measured_31b_seconds_per_token: float = 0.016722

    def memory(self) -> MemoryModel:
        return _gemma_memory_model()

    def configs(self, model: ModelSpec) -> list[LoRAConfig]:
        out = []
        for r in self.ranks:
            for lr in self.learning_rates:
                out.append(LoRAConfig(
                    id=len(out), task=FineTuningTask.GEMMA_TOOL_USE, learning_rate=lr, batch_size=1,
                    rank=r, alpha=2 * r, sequence_length=self.sequence_length, epochs=self.epochs,
                    steps_override=self.samples * self.epochs,
                ))
        return out

    def cost_model(self, model: ModelSpec, floor: float) -> CostModel:
        """Cost model for one alias: the 31B's measured group cost scaled by parameters, with the
        chosen floor."""
        group_overhead = 1 + self.testbed.gpu.tp_overhead_per_doubling * math.log2(self.testbed.gpu_count)
        p = CostModelParameters(
            measured_seconds_per_token_equivalent=(
                self.measured_31b_seconds_per_token * self.testbed.gpu_count / group_overhead
                * (model.parameters / ModelSpec.gemma4_31B_nf4.parameters)
            ),
            saturation_tokens_override=floor,
            lora_share_override=0.15,
        )
        return CostModel(parameters=p)

    def run(self, floor: float) -> list[ChallengeRow]:
        rows = []
        for model in self.models:
            cost = self.cost_model(model, floor)
            packer = Packer(model=model, testbed=self.testbed, cost=cost, memory=self.memory())
            configs = self.configs(model)
            probe = configs[3]  # r=16, the recipe's rank
            degree = packer.minimum_degree(probe) or self.testbed.gpu_count
            fit_pool = [
                replace(c, sequence_length=self.sequence_length, steps_override=self.samples * self.epochs)
                for c in identical(32, 1, rank=16, task=FineTuningTask.GEMMA_TOOL_USE)
            ]
            fit_pack = packer.best_pack(fit_pool, degree)
            fit = len(fit_pack) if fit_pack else 0
            rows.append(ChallengeRow(
                model=model.name, floor_tokens=floor, configs=len(configs), min_degree=degree,
                headroom_gb=self.memory().headroom_bytes_per_gpu(model, degree, self.testbed) / 1e9,
                adapter_gb=packer.adapter_bytes_per_gpu(probe, degree) / 1e9,
                adapters_that_fit=fit,
                plora=JobPlanner(packer=packer).schedule(configs, "PLoRA"),
                one_adapter_per_kernel=BaselineScheduler(packer=packer, kind=BaselineKind.MAX_GPU).schedule(configs),
            ))
        return rows

    def run_sweep(self) -> list[ChallengeRow]:
        """All floors x all models."""
        out = []
        for floor in self.floors:
            out.extend(self.run(floor))
        return out

    @staticmethod
    def markdown(rows: list[ChallengeRow]) -> str:
        out = [
            "| Gemma alias | L4 floor (tokens) | Min GPUs | headroom/GPU | r=16 adapter/GPU | adapters that fit | one per kernel | PLoRA | speedup | quota: sweeps per 30 h week (seq -> PLoRA) |",
            "|---|---|---|---|---|---|---|---|---|---|",
        ]
        for r in rows:
            out.append(
                f"| {r.model} | {r.floor_tokens:.0f} | {r.min_degree} | {r.headroom_gb:.1f} GB | {r.adapter_gb:.1f} GB | "
                f"{r.adapters_that_fit} | {r.sequential_hours:.1f} h | {r.plora_hours:.1f} h | {r.speedup:.2f}x | "
                f"{r.sweeps_per_week_sequential:.1f} -> {r.sweeps_per_week_plora:.1f} |"
            )
        return "\n".join(out)

    def proposed_ledger_rows(self, rows: list[ChallengeRow], floor: float, starting_index: int = 20) -> list[ExperimentRecord]:
        """Ledger ideas for the best plan per alias: `pending_gpu`, one change per experiment,
        parent E08 (the adapter run)."""
        out = []
        matching = [r for r in rows if r.floor_tokens == floor]
        for i, r in enumerate(matching):
            job = max(r.plora.jobs, key=lambda j: len(j.configs), default=None)
            desc = ", ".join(f"r{c.rank}/lr{c.learning_rate}" for c in job.configs) if job else "-"
            job_count = len(job.configs) if job else 0
            job_hours = job.duration_seconds / 3600 if job else 0
            out.append(ExperimentRecord(
                exp_id=f"I{starting_index + i}", status=PENDING_GPU, priority=str(5 + i), parent="E08",
                prompt=f"Does packing {job_count} tool-use adapters on {r.model} in one 4x L4 kernel reproduce PLoRA's gain (projected {r.speedup:.2f}x over one adapter per kernel)?",
                input=f"kernels/train with packed adapters on {r.model}: shared nf4 base, one step = {job_count} LoRA configs ({desc}), {job_hours:.1f} h projected",
                output="",
                feedback=f"Projection from GemmaChallengeStudy (floor {int(floor)} tokens); offline only. Pick the best adapter by held-out next-tool accuracy, then submit it as one experiment.",
            ))
        return out
