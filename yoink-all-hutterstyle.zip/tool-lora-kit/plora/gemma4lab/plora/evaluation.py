from __future__ import annotations

import os
from dataclasses import dataclass, field

from gemma4lab.plora.cost_model import CostModel, Execution
from gemma4lab.plora.lora_config import LoRAConfig, identical, paper_120
from gemma4lab.plora.memory_model import MemoryModel
from gemma4lab.plora.packed_lora import PackedLoRABenchmarkResult
from gemma4lab.plora.planner import BaselineKind, BaselineScheduler, JobPlanner, Packer, Schedule
from gemma4lab.plora.specs import GPUSpec, ModelSpec, Testbed


class PaperReference:
    """Numbers read from the paper, used as the reference the reproduction is compared against."""

    FIGURE4 = [
        ("Qwen2.5-3B", 7.08, 0.09), ("Qwen2.5-7B", 6.52, 0.09), ("Qwen2.5-14B", 6.33, 0.25), ("Qwen2.5-32B", 6.51, 0.50),
        ("Llama-3.2-3B", 7.52, 0.10), ("Llama-3.1-8B", 6.78, 0.10),
    ]
    """Figure 4: makespan speedup of PLoRA over Min GPU, and Max GPU's makespan normalised to Min GPU."""

    FIGURE5 = [
        ("Qwen2.5-3B", 1, 11.6), ("Qwen2.5-3B", 2, 7.6), ("Qwen2.5-3B", 4, 5.1),
        ("Qwen2.5-7B", 1, 12.8), ("Qwen2.5-7B", 2, 6.7), ("Qwen2.5-7B", 4, 2.9),
        ("Qwen2.5-14B", 1, 10.9), ("Qwen2.5-14B", 2, 8.7), ("Qwen2.5-14B", 4, 5.4),
        ("Qwen2.5-32B", 1, 9.1), ("Qwen2.5-32B", 2, 6.8), ("Qwen2.5-32B", 4, 4.8),
    ]
    """Figure 5 (read from the chart): PLoRA job throughput over Min GPU at rank 32 on A100."""

    FIGURE6 = [("Qwen2.5-3B", 1.80, 7.08), ("Qwen2.5-7B", 1.78, 6.52)]
    """Figure 6: Sequential PLoRA (planner only) and full PLoRA speedups over Min GPU."""

    FIGURE7 = [("Qwen2.5-3B", 5.94), ("Qwen2.5-7B", 2.56)]
    """Figure 7 / §E.3: best throughput speedup on A10 (rank 32)."""

    TABLE7 = [(2, 2.00, 2.01), (8, 7.98, 7.96), (32, 29.0, 30.0)]
    """Table 7: packed-kernel speedup over sequential on A100 (forward / backward), by adapter
    count, 3B attention column."""

    APPROXIMATION_RATIO_RANGE = (1.05, 1.14)
    """Appendix D: observed approximation ratios of the job planner."""

    BATCH_ONE_TO_EIGHT_SLOWDOWN = 1.10
    NAIVE_EIGHT_PACK_SLOWDOWN = 3.6
    """§C.1 microbenchmarks the cost model is calibrated to."""


@dataclass(frozen=True)
class MakespanResult:
    """One row of the makespan study (Figure 4 and Figure 6)."""

    model: str
    plora: Schedule
    sequential_plora: Schedule
    min_gpu: Schedule
    max_gpu: Schedule

    @property
    def plora_speedup(self) -> float:
        return self.min_gpu.makespan_seconds / self.plora.makespan_seconds

    @property
    def sequential_speedup(self) -> float:
        return self.min_gpu.makespan_seconds / self.sequential_plora.makespan_seconds

    @property
    def max_gpu_normalized(self) -> float:
        return self.min_gpu.makespan_seconds / self.max_gpu.makespan_seconds

    @property
    def paper(self) -> tuple[float, float] | None:
        for model, plora_speedup, max_gpu_normalized in PaperReference.FIGURE4:
            if model == self.model:
                return plora_speedup, max_gpu_normalized
        return None


@dataclass(frozen=True)
class ThroughputResult:
    """One row of the job-throughput study (Figure 5 / Figure 7)."""

    model: str
    batch_size: int
    degree: int
    packed_adapters: int
    plora_over_min_gpu: float
    max_gpu_over_min_gpu: float

    @property
    def paper(self) -> float | None:
        for model, batch_size, speedup in PaperReference.FIGURE5:
            if model == self.model and batch_size == self.batch_size:
                return speedup
        return None


@dataclass
class Reproduction:
    """Runs the paper's studies on the cost model and formats the comparison."""

    cost: CostModel = field(default_factory=CostModel)
    memory: MemoryModel = field(default_factory=MemoryModel)
    beam_width: int = 2

    def makespan_study(self, model: ModelSpec, testbed: Testbed = Testbed.p4d, configs: list[LoRAConfig] | None = None) -> MakespanResult:
        """§4.2: makespan of 120 configurations under PLoRA, Sequential PLoRA, Min GPU and Max GPU."""
        configs = configs if configs is not None else paper_120()
        packed = Packer(model=model, testbed=testbed, cost=self.cost, memory=self.memory, execution=Execution.PACKED)
        sequential = Packer(model=model, testbed=testbed, cost=self.cost, memory=self.memory, execution=Execution.SEQUENTIAL_ADAPTERS)
        return MakespanResult(
            model=model.name,
            plora=JobPlanner(packer=packed, beam_width=self.beam_width).schedule(configs, "PLoRA"),
            sequential_plora=JobPlanner(packer=sequential, beam_width=self.beam_width).schedule(configs, "Sequential PLoRA"),
            min_gpu=BaselineScheduler(packer=packed, kind=BaselineKind.MIN_GPU).schedule(configs),
            max_gpu=BaselineScheduler(packer=packed, kind=BaselineKind.MAX_GPU).schedule(configs),
        )

    def throughput_study(self, model: ModelSpec, testbed: Testbed = Testbed.p4d, batch_size: int = 1, rank: int = 32) -> ThroughputResult | None:
        """§4.3: throughput of one packed job versus one Min GPU job on the same GPUs, identical
        adapters at rank 32. PLoRA packs as many as fit at the Min GPU degree; Max GPU runs one
        adapter on all GPUs."""
        packer = Packer(model=model, testbed=testbed, cost=self.cost, memory=self.memory)
        probe = identical(1, batch_size, rank)[0]
        degree = packer.minimum_degree(probe)
        if degree is None:
            return None
        pool = identical(64, batch_size, rank)
        pack = packer.best_pack(pool, degree)
        if pack is None:
            return None
        gpu = testbed.gpu
        min_per_gpu = 1.0 / self.cost.step_seconds(model, gpu, [probe], degree) / degree
        plora_per_gpu = len(pack) / self.cost.step_seconds(model, gpu, pack, degree) / degree
        max_per_gpu = 1.0 / self.cost.step_seconds(model, gpu, [probe], testbed.gpu_count) / testbed.gpu_count
        return ThroughputResult(
            model=model.name, batch_size=batch_size, degree=degree, packed_adapters=len(pack),
            plora_over_min_gpu=plora_per_gpu / min_per_gpu, max_gpu_over_min_gpu=max_per_gpu / min_per_gpu,
        )

    def calibration_check(self) -> tuple[float, float]:
        """The two calibration identities the cost model must reproduce, evaluated on Qwen2.5-7B /
        A100. Returns (batch_one_to_eight, naive_eight_pack)."""
        m, g = ModelSpec.qwen2_5_7B, GPUSpec.a100_40
        one = identical(1, 1)[0]
        eight = identical(1, 8)[0]
        single = self.cost.step_seconds(m, g, [one], 1)
        bs8 = self.cost.step_seconds(m, g, [eight], 1)
        naive = self.cost.step_seconds(m, g, identical(8, 1), 1, Execution.SEQUENTIAL_ADAPTERS)
        return bs8 / single, naive / single

    def markdown_report(self, makespans_uniform: list[MakespanResult], makespans_small_batch: list[MakespanResult],
                         throughputs: list[ThroughputResult], a10: list[ThroughputResult],
                         kernels: list[PackedLoRABenchmarkResult]) -> str:
        out: list[str] = []
        cal_batch, cal_naive = self.calibration_check()
        out.append("## Cost-model calibration (Qwen2.5-7B, A100)")
        out.append("| Claim (§C.1) | Paper | Model |\n|---|---|---|")
        out.append(f"| iteration time, batch 1 -> 8 | x{PaperReference.BATCH_ONE_TO_EIGHT_SLOWDOWN:.2f} | x{cal_batch:.2f} |")
        out.append(f"| naive 8-adapter pack vs single adapter | x{PaperReference.NAIVE_EIGHT_PACK_SLOWDOWN:.2f} | x{cal_naive:.2f} |")
        out.append(f"| saturation floor T_sat (tokens per GPU per step) | - | {int(self.cost.saturation_tokens)} |")
        out.append(f"| LoRA kernel share of a single-adapter step | - | {self.cost.lora_share / (1 + self.cost.lora_share) * 100:.1f}% |")
        for n in (2, 8, 32):
            fwd, bwd = next((f, b) for a, f, b in PaperReference.TABLE7 if a == n)
            out.append(f"| packed-kernel speedup, {n} adapters (Table 7 fwd/bwd) | {fwd:.2f}x / {bwd:.2f}x | {self.cost.packed_speedup(n):.2f}x |")
        out.append("")
        out.append("## Figure 4 / Figure 6: makespan of 120 configurations on 8x A100 (normalised to Min GPU)")
        out.append("")
        out.append("### Batch sizes uniform over Table 1 (1, 2, 4, 8, 16, 32 - 20 configurations each)")
        out.extend(_makespan_table(makespans_uniform))
        out.append("")
        out.append("### Small-batch mix (1, 2, 4 - 40 configurations each), as Appendix E.1 recommends")
        out.extend(_makespan_table(makespans_small_batch))
        out.append("")
        out.append("## Figure 5: job throughput over Min GPU, rank 32, 8x A100")
        out.append("| Model | BS | packed adapters | PLoRA (paper) | PLoRA (ours) | Max GPU (ours) |\n|---|---|---|---|---|---|")
        for t in throughputs:
            paper = f"{t.paper:.1f}x" if t.paper is not None else "-"
            out.append(f"| {t.model} | {t.batch_size} | {t.packed_adapters} on {t.degree} GPU(s) | {paper} | {t.plora_over_min_gpu:.1f}x | {t.max_gpu_over_min_gpu:.2f}x |")
        out.append("")
        out.append("## Figure 7 / §E.3: job throughput over Min GPU on 8x A10, rank 32 (best over BS 1, 2, 4)")
        out.append("| Model | paper | ours (BS) |\n|---|---|---|")
        for model, speedup in PaperReference.FIGURE7:
            candidates = [r for r in a10 if r.model == model]
            if candidates:
                best = max(candidates, key=lambda r: r.plora_over_min_gpu)
                out.append(f"| {model} | {speedup:.2f}x | {best.plora_over_min_gpu:.2f}x (BS {best.batch_size}, {best.packed_adapters} adapters) |")
        out.append("")
        out.append(f"## Packed LoRA on the CPU (analogue of Table 7, {os.cpu_count()} cores)")
        out.append("| adapters | max |packed - sequential| | fwd speedup | bwd speedup | padded-rank FLOP waste |\n|---|---|---|---|---|")
        for k in kernels:
            out.append(f"| {k.adapters} | {k.max_abs_difference:.1e} | {k.forward_speedup:.2f}x | {k.backward_speedup:.2f}x | {k.padded_flop_waste:.1f}x |")
        return "\n".join(out)


def _makespan_table(rows: list[MakespanResult]) -> list[str]:
    out = [
        "| Model | PLoRA speedup (paper) | PLoRA speedup (ours) | Seq. PLoRA (paper Fig. 6) | Seq. PLoRA (ours) | Max GPU norm. (paper) | Max GPU norm. (ours) | PLoRA makespan | adapters/job (max) | tail bound AR <= |",
        "|---|---|---|---|---|---|---|---|---|---|",
    ]
    for r in rows:
        p = r.paper
        seq_paper = next((f"{s:.2f}x" for model, s, _ in PaperReference.FIGURE6 if model == r.model), "-")
        paper_plora = f"{p[0]:.2f}x" if p else "-"
        paper_max = f"{p[1]:.2f}" if p else "-"
        out.append(
            f"| {r.model} | {paper_plora} | {r.plora_speedup:.2f}x | {seq_paper} | {r.sequential_speedup:.2f}x | "
            f"{paper_max} | {r.max_gpu_normalized:.2f} | {r.plora.makespan_hours:.1f} h | "
            f"{r.plora.adapters_per_job:.1f} ({r.plora.max_adapters_in_a_job}) | {r.plora.tail_effect_bound:.3f} |"
        )
    return out
