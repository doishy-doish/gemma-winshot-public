# PLoRA kit

An addition to the Gemma 4 Developer Agent Tool-Use LoRA Kit: the CPU-side library behind the
tool-use adapter, and a reproduction of **"PLoRA: Efficient Concurrent LoRA Training for Large
Language Models"** (Yan, Wang, Jia, Venkataraman, Wang; ICML 2026, arXiv:2508.02932v2) pointed at
the four Gemma 4 aliases the competition serves on Kaggle's 4x L4. Nothing here is competition data
(Rule 2.4): only the author's library, notebooks, and aggregate numbers.

```
plora/
  gemma4lab/            pip-installable library (pip install -e plora/)
    core/               competition rules, bundle hash (== ops/build_sub.py), ledger + strict adoption rule, submission guard
    checker/            wraps ../tools/check_submission.py, the kit's static checker
    training/           LoRA recipe, warmup+cosine schedule, turn selection, Gemma 4 tool-call target format, gates
    plora/              memory model (App. B), calibrated iteration-time model, DTM packing planner, job planner,
                        CPU packed-LoRA kernels, Figures 4-7 studies, the Gemma 4 31B plan, the four-alias sweep
    viz/                matplotlib dashboards
  tests/                pytest; pins the bundle hash 49051a92f0c74756 and the paper's x1.10 / x3.60 calibration identities
  notebooks/            training-lab, testing-lab, experiments-lab, plora-lab (.ipynb; run on Kaggle or Colab, CPU only)
  benchmarks/           plora_bench.py: real step times, packed vs naive vs single adapter, on a Gemma 4 checkpoint (L4)
  PLORA-REPRODUCTION.md what is reproduced exactly, what is modelled, and the assumptions
  PLORA-RESULTS.md      the numbers
```

## Run it

On Kaggle, attach this dataset to a CPU notebook and open `plora/notebooks/plora-lab.ipynb`
(or any of the four); the first cell finds the kit under `/kaggle/input`, puts `gemma4lab` on the
path and installs numpy + matplotlib. On Colab, clone or upload the dataset and run the same
notebook. Locally:

```bash
pip install -e plora/ && pytest plora/tests
jupyter nbconvert --to notebook --execute plora/notebooks/plora-lab.ipynb
```

`plora-lab` takes one to two minutes on a CPU: it runs the 120-configuration makespan study on six
models, the throughput studies, the packed-kernel equivalence check, and the Gemma 4 plans.

## What it finds, in one paragraph

With the cost model calibrated only to the paper's own microbenchmarks, the planner reproduces the
paper's headline shape (packing lifts throughput by an order of magnitude at batch 1 on A100, and
the makespan gain is dominated by the batch-size mix). On this project's own measured case — the
31B tool-use adapter, nf4 QLoRA, 5.8k-token samples on 4x L4 — the step is compute-bound, so
packing nine configurations saves little wall clock; the smaller aliases (12B, E4B, E2B) gain only
if the L4 step has a sizeable latency floor, which `benchmarks/plora_bench.py` exists to measure.
See `PLORA-RESULTS.md` for the tables and `PLORA-REPRODUCTION.md` for every caveat.

## Licence

Apache-2.0, like the rest of the kit. The PLoRA paper and its numbers belong to its authors; this is
an independent reproduction of the published method.
