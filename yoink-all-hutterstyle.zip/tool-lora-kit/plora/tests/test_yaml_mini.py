from gemma4lab.yaml_mini import MiniYAML, YAMLProblem
import pytest


def test_parses_simple_mapping():
    doc = MiniYAML.parse("a: 1\nb: two\nc: true\n")
    assert doc == {"a": 1, "b": "two", "c": True}


def test_parses_sequence():
    doc = MiniYAML.parse("- a\n- b\n- c\n")
    assert doc == ["a", "b", "c"]


def test_rejects_tab_indentation():
    with pytest.raises(YAMLProblem):
        MiniYAML.parse("a:\n\tb: 1\n")


def test_include_tag():
    doc = MiniYAML.parse("instruction: !include prompts/system.md\n")
    assert doc["instruction"].path == "prompts/system.md"


def test_duplicate_key_rejected():
    with pytest.raises(YAMLProblem):
        MiniYAML.parse("a: 1\na: 2\n")
