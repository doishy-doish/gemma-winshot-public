from pathlib import Path

import pytest

from gemma4lab import Workspace


@pytest.fixture
def bundle_dir() -> Path:
    ws = Workspace.locate()
    bundle = ws.bundles_dir / "a1_graph_decision_6min" if ws else None
    if bundle is None or not bundle.is_dir():
        pytest.skip("reference bundle not present in this checkout")
    return bundle
