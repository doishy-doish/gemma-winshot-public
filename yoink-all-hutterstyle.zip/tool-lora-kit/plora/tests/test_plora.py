from gemma4lab.plora import CostModel, GPUSpec, ModelSpec, identical, PaperReference
from gemma4lab.plora.evaluation import Reproduction
from gemma4lab.plora.packed_lora import PackedLoRABenchmark


def test_cost_model_reproduces_batch_slowdown():
    cost = CostModel()
    one = identical(1, 1)[0]
    eight = identical(1, 8)[0]
    single = cost.step_seconds(ModelSpec.qwen2_5_7B, GPUSpec.a100_40, [one], degree=1)
    bs8 = cost.step_seconds(ModelSpec.qwen2_5_7B, GPUSpec.a100_40, [eight], degree=1)
    assert abs(bs8 / single - PaperReference.BATCH_ONE_TO_EIGHT_SLOWDOWN) < 0.01


def test_calibration_check_matches_paper_identities():
    repro = Reproduction()
    batch, naive = repro.calibration_check()
    assert abs(batch - 1.10) < 0.01
    assert abs(naive - 3.6) < 0.01


def test_packed_lora_matches_sequential_exactly():
    bench = PackedLoRABenchmark()
    result = bench.run(adapters=4)
    assert result.max_abs_difference < 1e-5


def test_gemma_on_l4_cost_model_has_overrides():
    cost = CostModel.gemma_on_l4()
    assert cost.parameters.saturation_tokens_override == 128
    assert cost.parameters.lora_share_override == 0.15
