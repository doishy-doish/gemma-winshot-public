from gemma4lab.training import (
    TrainingRecipe, LearningRateSchedule, optimizer_steps, pick_turns, target_text,
    AssistantMessage, ToolCall,
)


def test_pick_turns_includes_graph_calls_first_two_edit_and_submit():
    tools_per_call = [["run_command"]] * 14
    tools_per_call[2] = ["read_file"]
    tools_per_call[4] = ["get_code_neighbors"]
    tools_per_call[6] = ["edit_file"]
    tools_per_call[9] = ["search_similar_code"]
    tools_per_call[13] = ["submit_patch"]
    picked = pick_turns(tools_per_call, max_turns=8)
    assert 4 in picked and 9 in picked  # graph calls
    assert 0 in picked and 1 in picked  # first two
    assert 6 in picked  # first edit
    assert 13 in picked  # submit
    assert len(picked) <= 8


def test_learning_rate_schedule_warmup_then_decay():
    recipe = TrainingRecipe.shipped
    steps = optimizer_steps(420, recipe)
    schedule = LearningRateSchedule(total_steps=steps, warmup_fraction=recipe.warmup_fraction, peak=recipe.learning_rate)
    assert schedule.learning_rate(0) < schedule.learning_rate(schedule.warmup_steps)
    assert schedule.learning_rate(steps - 1) < schedule.learning_rate(schedule.warmup_steps)


def test_target_text_includes_thought_and_tool_call():
    call = ToolCall(id="t1", name="get_code_neighbors", arguments={"node": "a.b.c", "max_neighbors": 20})
    msg = AssistantMessage(reasoning="because", content="GRAPH: call", tool_calls=[call])
    text = target_text(msg)
    assert "<|channel>thought" in text
    assert "<|tool_call>call:get_code_neighbors" in text
    assert text.endswith("<|tool_response>")


def test_target_text_without_tool_calls_ends_with_turn_token():
    msg = AssistantMessage(content="done")
    assert target_text(msg) == "done<turn|>"
