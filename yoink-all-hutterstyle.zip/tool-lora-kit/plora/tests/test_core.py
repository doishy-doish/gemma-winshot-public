from gemma4lab.core.agent_bundle import AgentBundle, bundle_hash, with_adapter_line
from gemma4lab.core.adoption_rule import judge_scores, Verdict
from gemma4lab.core.experiment import Decision
from gemma4lab.core.submission_guard import check, is_blocked, submit_command
from gemma4lab.core.utc_day import days_until_deadline, next_quota_reset
from datetime import datetime, timezone


def test_bundle_hash_matches_ledger(bundle_dir):
    bundle = AgentBundle.from_directory(bundle_dir)
    assert bundle.hash == "49051a92f0c74756"


def test_bundle_hash_adapter_differs(bundle_dir):
    plain = AgentBundle.from_directory(bundle_dir)
    adapter = AgentBundle.from_directory(bundle_dir, adapter=True)
    assert plain.hash != adapter.hash
    assert "adapter: main_lora" in adapter.files["agent.yaml"]


def test_with_adapter_line_idempotent():
    yaml = "model: gemma-4-31b-it-qat-w4a16-ct\nadapter: main_lora\n"
    assert with_adapter_line(yaml) == yaml


def test_adoption_rule_strict_tie_rejected():
    v = judge_scores(0.17, 0.17)
    assert v.decision == Decision.REJECTED


def test_adoption_rule_strictly_higher_adopted():
    v = judge_scores(0.20, 0.17)
    assert v.decision == Decision.ADOPTED


def test_adoption_rule_below_arch_rejected():
    v = judge_scores(0.20, 0.17, arch_score=0.25)
    assert v.decision == Decision.REJECTED


def test_adoption_rule_no_score_pending():
    v = judge_scores(None, 0.17)
    assert v.decision == Decision.PENDING


def test_submission_guard_blocks_token_leak():
    v = check("cat ~/.kaggle/access_token")
    assert is_blocked(v)


def test_submission_guard_blocks_second_submission_same_day():
    from gemma4lab.core.submission_guard import SubmissionLogEntry
    today = "2026-10-24"
    log = [SubmissionLogEntry(utc_date=today, timestamp="2026-10-24T01:00:00Z", exp_id="E07r", kernel_version="3", message="E07r: x")]
    cmd = submit_command("I02", 3, "test")
    v = check(cmd, log=log, today=today)
    assert is_blocked(v)


def test_submission_guard_allows_valid_submit():
    cmd = submit_command("E07r", 3, "plain A1 6-min, control for E09")
    v = check(cmd, log=[], today="2026-10-24")
    assert not is_blocked(v)


def test_days_until_deadline_is_negative_past_2026_12_02():
    future = datetime(2026, 12, 10, tzinfo=timezone.utc)
    assert days_until_deadline(future) < 0


def test_next_quota_reset_is_a_saturday():
    now = datetime(2026, 10, 24, 12, 0, tzinfo=timezone.utc)
    reset = next_quota_reset(now)
    assert reset.weekday() == 5
    assert reset.hour == 0
