from gemma4lab.kaggle import KernelPushResult, KernelStatus, LeaderboardSubmission, PushFailed, SubmissionNotebook, expected_archive, verify_zip, BuildState
from gemma4lab.core.agent_bundle import AgentBundle
import pytest


def test_kernel_push_result_parses_version():
    r = KernelPushResult.parse("Kernel version 6 successfully pushed.")
    assert r.version == 6


def test_kernel_push_result_raises_on_failure():
    with pytest.raises(PushFailed):
        KernelPushResult.parse("something went wrong")


def test_kernel_status_parses_complete():
    assert KernelStatus.parse('scottweeden/gemma4-agent-submission has status "COMPLETE"') == KernelStatus.COMPLETE


def test_leaderboard_submission_parses_csv():
    csv = "ref,fileName,date,description,status,publicScore\n123,submission.zip,2026-10-24,E07r: test,complete,0.17\n"
    rows = LeaderboardSubmission.parse_csv(csv)
    assert len(rows) == 1
    assert rows[0].exp_id == "E07r"
    assert rows[0].public_score == 0.17


def test_submission_notebook_zip_roundtrip(bundle_dir):
    bundle = AgentBundle.from_directory(bundle_dir)
    notebook = SubmissionNotebook(exp_id="E07r", bundle=bundle)
    assert "EXP, ADAPTER = 'E07r', False" in notebook.code
    archive = expected_archive(bundle)
    state = BuildState(exp_id="E07r", bundle_dir=str(bundle_dir), adapter=False, bundle_hash=bundle.hash, version=3, files=bundle.sorted_paths)
    outcome = verify_zip(archive, state)
    assert outcome.matches
