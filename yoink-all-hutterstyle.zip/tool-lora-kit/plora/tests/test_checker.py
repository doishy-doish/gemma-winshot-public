from gemma4lab.checker import check_bundle, deterministic_zip


def test_check_bundle_runs_and_reports_known_issue_counts(bundle_dir):
    report = check_bundle(bundle_dir)
    assert "pass" in report.summary
    assert isinstance(report.failures, list)


def test_deterministic_zip_is_stable(bundle_dir):
    z1 = deterministic_zip(bundle_dir)
    z2 = deterministic_zip(bundle_dir)
    assert z1 == z2
    assert len(z1) > 0
