# Reproducing "PLoRA: Efficient Concurrent LoRA Training for Large Language Models"

Yan, Wang, Jia, Venkataraman, Wang. ICML 2026 (PMLR 306), arXiv:2508.02932v2. The PDF is in this folder.
The reproduction lives in the Swift module `Gemma4LabKit/Sources/Gemma4PLoRA`, its tests in
`Tests/Gemma4PLoRATests`, and the interactive version is the **PLoRA** page of `Gemma4LabPlayground.playground`.
The numbers are in `PLORA-RESULTS.md`, which `swift test --filter ReportTests` (or `swift run plora-report`) regenerates.

## What the paper claims

1. Isolated LoRA fine-tuning under-utilises GPUs: SM occupancy ≈ 16.7% for batch sizes 1-16 and ranks 8-128;
   iteration time grows only ~10% from batch 1 to 8 (§2.3, §C.1).
2. Packing many adapters on one frozen base model fixes this, but needs (a) a planner that chooses which
   configurations share a job and on how many GPUs under memory constraints (§3.2: a knapsack-like ILP solved per
   parallelism degree, Algorithm 1 "DTM", then Algorithm 2 schedules jobs over time), and (b) packed CUDA kernels
   (§C.2) that scale near-linearly with the number of adapters (Table 7: 2 → 2.0×, 8 → 8.0×, 32 → 29-30×).
3. Results on 8× A100 with 120 configurations: makespan 6.3-7.5× shorter than Min GPU (Fig. 4), job throughput up to
   12.8× (Fig. 5), the planner alone gives ~1.8× (Fig. 6), the job planner is within 1.05-1.14 of optimal (Thm D.1).
4. Searching 120 configurations improves accuracy over default LoRA settings by up to 23.4% (Table 2).

## What is reproduced here, and how

This reproduction was first run CPU-only, so it separates what can be computed from what can only be modelled. GPUs are available for the measurements (Kaggle 4x L4, Google Colab, and the HPCC over VPN); `benchmarks/plora_bench.py` is the GPU step.

| Paper component | Here | Fidelity |
|---|---|---|
| Memory model (Appendix B, eq. 19-20, TP sharding) | `MemoryModel` | Exact formulas. One reading choice: the paper's gradient term multiplies by c_prec twice; we take that as a typo. Activation checkpointing factor 2 per layer input; logits chunked (as this project's trainer does). |
| Table 1 search space, 120 configurations | `ConfigurationSpace` | Grid exact. The paper does not list its 120 picks; we use a seeded stratified sample, in two batch-size mixes (uniform 1…32, and small-batch 1/2/4 per Appendix E.1). |
| Iteration time T(H, d) | `CostModel` | **Analytical model** calibrated to the paper's own statements: +10% for batch 1→8 fixes the saturation floor T_sat (≈ 11.8k tokens/GPU, p-norm shape, p = 3); the 3.6× naive-pack slowdown fixes the LoRA kernel share (36% of a step); Table 7 fixes the packed-kernel speedup s(n); TP divides tokens per GPU, not the floor, plus a per-doubling communication overhead. |
| DTM (Algorithm 1) | `Packer.dtm` | Same recursion over degrees g', g'/2, …, 1. The Gurobi ILP per degree is replaced by an **exact** dynamic program over memory units and cardinality, evaluated with the real T for every cardinality (eq. 6). A beam of width 2 bounds the branching. |
| Job planner (Algorithm 2) | `JobPlanner` | Event simulation: launch DTM's packs when GPUs are free, predict the next completion from the cost model, release GPUs, repeat. Jobs run in phases so adapters with fewer steps stop paying when done. |
| Theorem D.1 tail bound | `Schedule.tailEffectBound` | AR ≤ F / (F − T_last (G−D)/G), computed from the schedule. |
| Min GPU / Max GPU baselines (§4.1) | `BaselineScheduler` | One configuration per job; Min GPU on the smallest degree that fits (3B/7B: 1 A100, 14B: 2, 32B: 4), Max GPU on all 8, longest job first. |
| Sequential PLoRA (Fig. 6) | `CostModel.Execution.sequentialAdapters` | Planner on, packed kernels off. |
| Packed kernels (§C.2, Table 7/8) | `PackedLoRA`, `PackedLoRABenchmark` | CPU analogue: packed forward/backward over one concatenated buffer with per-adapter tiles run concurrently on all cores; the four backward cases of §C.2; gradient equality with per-adapter computation checked (and against finite differences in tests). Speedups are CPU core-parallelism, not GPU numbers. |
| Model quality (Table 2, 4, 5, 6) | — | **Not reproduced**: requires fine-tuning Qwen/Llama on GPUs. |
| This project | `GemmaPLoRAPlan` | The planner applied to the Gemma 4 31B tool-use adapter on Kaggle's 4× L4, calibrated with `train_out/metrics.json` (16.7 ms/token, 20.4 GiB peak, 122.7M params at r=16). A projection, labelled as such. |

## What the reproduction found

Read the current numbers in `PLORA-RESULTS.md`. In summary:

- **Calibration holds by construction**: the model reproduces the +10% and 3.6× claims exactly and Table 7 within 2%.
- **Max GPU vs Min GPU (Fig. 4) reproduces**: ≈ 0.10 normalised makespan for 3B/7B, ≈ 0.22 for 14B, ≈ 0.47 for 32B
  (paper 0.09, 0.25, 0.50). This follows from the latency floor not shrinking with tensor parallelism; it is the
  paper's own explanation ("even lower hardware utilization").
- **Job throughput (Fig. 5) reproduces for single-GPU jobs** (3B, 7B: within ±25-40%, with the right trend across
  batch sizes 1/2/4). For 14B and 32B the model overshoots by up to ~2× because its per-GPU floor stays constant under
  TP, which makes packing on 2-4 GPUs look nearly free; the paper measured smaller gains there.
- **Sequential PLoRA (Fig. 6) lands at 1.1-1.9× vs the paper's 1.8×**: packing without packed kernels buys little,
  as the paper says.
- **End-to-end makespan (Fig. 4) depends on the batch-size mix the paper did not publish.** With batch sizes uniform
  over Table 1 the planner reaches 2.3-3.1×; with the small-batch mix that Appendix E.1 recommends it reaches
  3-5.6× (the paper: 6.3-7.5×). The critical path is always a job of batch-1 adapters with 7,000-8,500 steps; the
  gap to the paper is in how many such adapters share a GPU and how cheap the shared step is, which our cost model
  takes from two sentences of §C.1 rather than from measurements.
- **Theorem D.1**: observed bounds 1.00-1.26, the paper reports 1.05-1.14.
- **Kernels**: packed and sequential computations agree to floating-point rounding (max difference 0); on 12 CPU cores
  the concurrent packed path is 1.5×/3.6×/6.7× faster for 2/8/32 adapters, versus the paper's 2×/8×/29× on an A100.
  The padded-rank alternative the paper rejects would waste 1.3-2.1× FLOPs on mixed ranks.
- **Gemma 4 on 4× L4: PLoRA's premise does not hold here.** The measured 16.7 ms/token at 16k context means the
  QLoRA step is compute-bound (nf4 dequantisation, long sequences), so sharing the base model saves almost nothing per
  step: the planner's objective Σr/T is flat in the number of packed adapters and it ends up running one adapter per
  job, two 2-GPU jobs side by side. The projected gain over one adapter per 4-GPU kernel is ~1.1× (GPU bin-packing,
  not packing). Memory would allow 2-3 adapters per job (16 GB headroom per GPU, ~4 GB per adapter with 5.8k-token
  activations). The ledger rows it proposes are `pending_gpu` ideas that would have to be measured on Kaggle, and
  by this project's rules offline results never justify adoption.

## Diverging from the paper: the models the challenge needs

The paper's testbed is Qwen 2.5 / Llama 3 on 8× A100. This project trains on Kaggle's 4× L4 and the competition
accepts exactly four aliases: `gemma-4-31b/12b/e4b/e2b-it-qat-w4a16-ct`. `GemmaChallengeStudy` points the same
planner at those (`ModelSpec.gemmaChallengeFamily`), with the challenge's own data (83 rejection-sampled
trajectories × 2 epochs, 5,835 tokens per sample on average) and a 9-configuration tool-use sweep per alias
(r ∈ {8, 16, 32} × lr ∈ {5e-5, 1e-4, 2e-4}, α = 2r). The 31B's measured per-token cost is scaled by parameter count
for the smaller aliases; their architecture constants are approximated from the Gemma 3 cards. The one unmeasured
input, the L4 latency floor, is swept (128 / 2,048 / 11,832 tokens) because it decides the answer: a compute-bound
step gains nothing from sharing the base model, a latency-bound one gains up to the number of adapters that fit.
The results table in `PLORA-RESULTS.md` reports, per alias and floor, the adapters that fit one job, the wall clock
of the sweep with one adapter per kernel versus packed, and how many sweeps a 30 h weekly quota buys. The ledger
rows it proposes are `pending_gpu` ideas (parent E08); measuring the floor on Kaggle is the first thing to do before
believing any of them.

## Caveats

- Every time in this reproduction comes from an analytical cost model. It is calibrated to numbers the paper reports,
  not to measurements of the paper's hardware, and absolute hours are not meaningful; only ratios are compared.
- The 120 configurations, the Min GPU job order, and the exact adapter-memory accounting of the paper are unknown.
- Qwen 2.5 and Llama 3 architecture constants (hidden size, layers, heads, vocabulary) are taken from the public
  model cards; Gemma 4 31B hidden sizes are not needed because the adapter size was measured.
- `swift test` runs the full study in debug mode in about a minute; the playground page takes about as long.
