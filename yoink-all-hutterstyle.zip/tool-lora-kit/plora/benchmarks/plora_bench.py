"""PLoRA microbenchmark for the challenge's Gemma 4 models (runs on Colab or on a Kaggle 4x L4 kernel).

Measures, with nf4 QLoRA exactly as kernels/train/train.py trains (r=16, alpha=32, all seven projections of the
language model, bf16 autocast, fp32 LoRA master weights, AdamW):
  1. step time (forward + backward + optimizer step) of ONE adapter vs tokens per step  -> the latency floor T_sat
     and the saturated per-token cost c that Gemma4PLoRA.CostModel otherwise assumes,
  2. step time of N adapters PACKED on the shared frozen base (one batched base pass, per-adapter LoRA via
     batched matmuls) vs N single-adapter steps (the paper's Min GPU unit) vs the NAIVE pack (batched base,
     adapters looped)  -> the paper's Figure 5 / Table 7 on Gemma,
  3. peak memory per configuration                                                        -> the memory model.
Writes plora_bench.json; `GemmaChallengeStudy`/`CostModel.calibrated(from:)` read it in Swift.

Usage (Colab):  colab run --gpu L4 plora_bench.py --models google/gemma-4-e2b-it google/gemma-4-e4b-it
Usage (Kaggle): the notebook made by make_notebook.py; models are discovered under /kaggle/input.
No task data is read: the inputs are random token ids, which is all a timing/memory benchmark needs.
"""
import argparse, gc, glob, json, math, os, sys, time
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--models", nargs="*", default=[], help="HF ids or local dirs; default: discover under /kaggle/input or use Gemma 4 E2B")
ap.add_argument("--seq", nargs="*", type=int, default=[256, 1024, 2048, 4096], help="tokens per adapter per step")
ap.add_argument("--packs", nargs="*", type=int, default=[1, 2, 4, 8], help="adapters packed per step")
ap.add_argument("--pack-seq", type=int, default=1024, help="tokens per adapter in the packing study")
ap.add_argument("--rank", type=int, default=16)
ap.add_argument("--alpha", type=float, default=32)
ap.add_argument("--reps", type=int, default=5, help="timed steps per point (after 2 warm-up steps)")
ap.add_argument("--out", default=None)
ap.add_argument("--time-limit-min", type=float, default=50)
args = ap.parse_args() if __name__ == "__main__" else ap.parse_args([])

T0 = time.time()
for k, v in {"TRANSFORMERS_NO_TF": "1", "TRANSFORMERS_NO_FLAX": "1", "PYTORCH_CUDA_ALLOC_CONF": "expandable_segments:True",
             "TOKENIZERS_PARALLELISM": "false"}.items():
    os.environ.setdefault(k, v)
ON_KAGGLE = Path("/kaggle/working").exists()
OUT = Path(args.out or ("/kaggle/working/plora_bench.json" if ON_KAGGLE else "/content/plora_bench.json"))


def log(*a):
    print(f"[{(time.time() - T0) / 60:6.1f} min]", *a, flush=True)


# ---------------------------------------------------------------- packages
if ON_KAGGLE:
    # Offline: the competition wheelhouse (cp312), as train.py does.
    import importlib, subprocess
    wh = next((Path(p) for p in ("/kaggle/input/datasets/metric/gemma-4-developer-agent-wheelhouse", "/kaggle/input/gemma-4-developer-agent-wheelhouse") if Path(p).exists()), None)
    if wh:
        tmp = Path("/tmp/wheelhouse"); tmp.mkdir(exist_ok=True)
        for w in wh.glob("*.whl"):
            if "cutlass" in w.name.lower():
                continue
            t = tmp / (w.name.replace("cu128", "+cu128") if ("cu128" in w.name and "+" not in w.name) else w.name)
            if not t.exists():
                os.symlink(w, t)
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--no-deps", "--force-reinstall", *sorted(map(str, tmp.glob("*.whl")))], check=True)
        importlib.invalidate_caches()
else:
    import subprocess
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-U", "transformers>=5.0", "peft", "bitsandbytes", "accelerate", "safetensors"], check=False)

import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoConfig, BitsAndBytesConfig

ngpu = torch.cuda.device_count()
gpu_name = torch.cuda.get_device_name(0) if ngpu else "cpu"
log("gpus:", ngpu, gpu_name, "| torch", torch.__version__)
assert ngpu >= 1, "a GPU is required"


def discover_models():
    if args.models:
        return args.models
    if ON_KAGGLE:
        hits = sorted(set(str(Path(p).parent) for p in glob.glob("/kaggle/input/**/config.json", recursive=True) if "gemma-4" in p and "qat-w4a16" not in p))
        return hits or [str(Path(p).parent) for p in glob.glob("/kaggle/input/**/config.json", recursive=True)][:1]
    return ["google/gemma-4-e2b-it"]


# ---------------------------------------------------------------- packed LoRA
class PackedLoRALinear(nn.Module):
    """A frozen (4-bit) linear with N LoRA adapters. Input layout: batch dim = adapters (one sample per adapter,
    sequence length s). Packed mode: one base pass over all rows, then per-adapter LoRA as batched matmuls
    (the Appendix C.2 idea; here two torch.bmm per layer instead of a CUTLASS kernel). Naive mode: a Python
    loop over adapters (the baseline frameworks' behaviour)."""

    def __init__(self, base: nn.Module, n: int, r: int, alpha: float, in_f: int, out_f: int, device, mode="packed"):
        super().__init__()
        self.base, self.n, self.r, self.mode = base, n, r, mode
        self.scaling = alpha / r
        self.A = nn.Parameter(torch.randn(n, in_f, r, device=device, dtype=torch.float32) / math.sqrt(in_f))
        self.B = nn.Parameter(torch.zeros(n, r, out_f, device=device, dtype=torch.float32))

    def forward(self, x):
        y = self.base(x)
        xb = x.to(torch.bfloat16)
        if self.mode == "packed":
            # x: [n, s, in] -> [n, s, r] -> [n, s, out]; both are a single batched GEMM across adapters.
            h = torch.bmm(xb, self.A.to(torch.bfloat16))
            d = torch.bmm(h, self.B.to(torch.bfloat16))
        else:
            d = torch.stack([(xb[i] @ self.A[i].to(torch.bfloat16)) @ self.B[i].to(torch.bfloat16) for i in range(self.n)])
        return y + (d * self.scaling).to(y.dtype)


TARGETS = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")


def wrap(model, n, r, alpha, mode):
    wrapped = 0
    for name, mod in list(model.named_modules()):
        for child_name, child in list(mod.named_children()):
            if child_name in TARGETS and "language_model" in name or (child_name in TARGETS and "vision" not in name and "audio" not in name and "layers." in name):
                in_f, out_f = child.in_features, child.out_features
                dev = next(child.parameters()).device if any(True for _ in child.parameters()) else torch.device("cuda")
                setattr(mod, child_name, PackedLoRALinear(child, n, r, alpha, in_f, out_f, dev, mode))
                wrapped += 1
    return wrapped


def unwrap(model):
    for name, mod in list(model.named_modules()):
        for child_name, child in list(mod.named_children()):
            if isinstance(child, PackedLoRALinear):
                setattr(mod, child_name, child.base)


def load(model_id):
    bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.bfloat16,
                             llm_int8_skip_modules=["vision_tower", "audio_tower", "embed_vision", "embed_audio", "lm_head", "multi_modal_projector"])
    max_memory = {i: f"{int(torch.cuda.get_device_properties(i).total_memory / 2**30) - 3}GiB" for i in range(ngpu)}
    t = time.time()
    m = AutoModelForCausalLM.from_pretrained(model_id, device_map="balanced" if ngpu > 1 else {"": 0}, max_memory=max_memory,
                                             quantization_config=bnb, dtype=torch.bfloat16, attn_implementation="sdpa")
    m.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    m.enable_input_require_grads()
    for p in m.parameters():
        p.requires_grad_(False)
    cfg = getattr(m.config, "get_text_config", lambda: m.config)()
    log(f"loaded {model_id} in {time.time() - t:.0f}s: layers {getattr(cfg, 'num_hidden_layers', '?')}, hidden {getattr(cfg, 'hidden_size', '?')},"
        f" params {sum(p.numel() for p in m.parameters()) / 1e9:.2f}B (counted post-quantisation)")
    return m, cfg


def step_time(model, n, s, mode, reps):
    """Mean seconds per optimizer step for n adapters × s tokens, and peak GiB."""
    vocab = model.get_input_embeddings().num_embeddings
    dev = model.get_input_embeddings().weight.device
    wrapped = wrap(model, n, args.rank, args.alpha, mode)
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=1e-4, weight_decay=0.0)
    ids = torch.randint(0, vocab, (n, s), device=dev)
    for i in range(ngpu):
        torch.cuda.reset_peak_memory_stats(i)
    times = []
    try:
        for it in range(reps + 2):
            torch.cuda.synchronize()
            t = time.time()
            with torch.autocast("cuda", dtype=torch.bfloat16):
                out = model(input_ids=ids, labels=ids)
            out.loss.backward()
            opt.step()
            opt.zero_grad(set_to_none=True)
            torch.cuda.synchronize()
            if it >= 2:
                times.append(time.time() - t)
        peak = max(torch.cuda.max_memory_allocated(i) for i in range(ngpu)) / 2**30
        ok = True
    except torch.cuda.OutOfMemoryError:
        times, peak, ok = [], float("nan"), False
    finally:
        unwrap(model)
        del opt, params, ids
        gc.collect()
        torch.cuda.empty_cache()
    return (sum(times) / len(times) if times else float("nan")), peak, ok, wrapped


results = {"gpu": gpu_name, "gpus": ngpu, "rank": args.rank, "alpha": args.alpha, "torch": torch.__version__, "models": []}
for model_id in discover_models():
    if (time.time() - T0) / 60 > args.time_limit_min:
        log("time limit reached; skipping", model_id)
        break
    try:
        model, cfg = load(model_id)
    except Exception as e:
        log("could not load", model_id, repr(e))
        results["models"].append({"model": model_id, "error": repr(e)})
        continue
    entry = {"model": model_id, "layers": getattr(cfg, "num_hidden_layers", None), "hidden": getattr(cfg, "hidden_size", None),
             "intermediate": getattr(cfg, "intermediate_size", None), "single": [], "packed": [], "naive": []}
    # 1. one adapter, step time vs tokens -> floor and per-token cost
    for s in args.seq:
        t, peak, ok, wrapped = step_time(model, 1, s, "packed", args.reps)
        entry["single"].append({"tokens": s, "seconds": t, "peak_gib": peak, "ok": ok})
        entry["wrapped_projections"] = wrapped
        log(f"{model_id} single adapter, {s} tokens: {t:.3f} s/step, peak {peak:.1f} GiB{'' if ok else ' (OOM)'}")
        if not ok:
            break
    # 2. packing study at a fixed per-adapter length
    for n in args.packs:
        tp, peakp, okp, _ = step_time(model, n, args.pack_seq, "packed", args.reps)
        entry["packed"].append({"adapters": n, "tokens_per_adapter": args.pack_seq, "seconds": tp, "peak_gib": peakp, "ok": okp})
        log(f"{model_id} packed {n} adapters × {args.pack_seq}: {tp:.3f} s/step, peak {peakp:.1f} GiB{'' if okp else ' (OOM)'}")
        if n > 1 and okp:
            tn, peakn, okn, _ = step_time(model, n, args.pack_seq, "naive", max(2, args.reps // 2))
            entry["naive"].append({"adapters": n, "tokens_per_adapter": args.pack_seq, "seconds": tn, "peak_gib": peakn, "ok": okn})
            log(f"{model_id} naive  {n} adapters × {args.pack_seq}: {tn:.3f} s/step")
        if not okp:
            break
    single_at_pack = next((p["seconds"] for p in entry["single"] if p["tokens"] == args.pack_seq and p["ok"]), None)
    if single_at_pack:
        entry["throughput_gain"] = [{"adapters": p["adapters"], "gain": p["adapters"] * single_at_pack / p["seconds"]} for p in entry["packed"] if p["ok"]]
        log("throughput gain vs one adapter per step:", entry["throughput_gain"])
    results["models"].append(entry)
    del model
    gc.collect()
    torch.cuda.empty_cache()
    OUT.write_text(json.dumps(results, indent=1))

OUT.write_text(json.dumps(results, indent=1))
log("wrote", OUT, "in", round((time.time() - T0) / 60, 1), "min")
