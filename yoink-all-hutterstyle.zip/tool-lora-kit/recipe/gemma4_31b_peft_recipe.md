# Recipe: `gemma4_31b_peft_config` (tool-use LoRA for the swegemma agent)

This follows the nemo-mbridge-recipe-recommender method. It picks the closest shipped recipe, separates the
**convergence contract** from the **execution mapping**, applies the resizing rules, and flags benchmark-only shortcuts.

## 1. Recipe lookup

| Question | Answer |
|---|---|
| Model | Gemma 4 31B dense (`Gemma4ForConditionalGeneration`, text path only). Served as `google/gemma-4-31b-it-qat-w4a16-ct`. |
| Goal | PEFT (LoRA) SFT on rejection-sampled agent trajectories |
| GPUs | Colab: **1 GPU per VM** (A100-80, H100-80 or G4 RTX PRO 6000 96 GB). Future: 1 node of 8× H100. |
| Sequence length | 16,384 (post-compaction contexts; 32k is not needed) |
| Closest shipped recipe | **None for Gemma 4 31B.** The index lists `gemma3_1b_{pretrain,sft,peft}_config` and `gemma3_vl_{4b,12b,27b}_{sft,peft}_config`. Megatron Bridge main has only `gemma4_e4b_pretrain_2gpu_h100_bf16_config` and the Gemma 4 VL 26B-A4B recipes. The Gemma 4 bridge/provider exists, so a custom recipe is buildable. |
| Decision-tree branch | "1 GPU → only PEFT recipes work (TP=1, PP=1)". "> 8K → need CP" applies only on multi-GPU. |

Because no 31B recipe ships, this is a **new library recipe**. The performance-readiness target (200 TFLOP/s/GPU on
H100) applies to pretraining recipes only and **not to PEFT**. Throughput is still recorded (see §5).

## 2. Convergence contract (changing any of these is a NEW experiment)

| Field | Value | Why |
|---|---|---|
| Starting checkpoint | bf16 weights dequantized from `google/gemma-4-31b-it-qat-w4a16-ct` (G4 bf16 mode), or nf4 QLoRA of the same weights (80 GB GPUs) | The adapter learns on the grid it is served on. Plain `gemma-4-31B-it` (pre-QAT) is excluded. |
| Trainable params | LoRA on `model.language_model.layers.{i}.self_attn.{q,k,v,o}_proj` and `.mlp.{gate,up,down}_proj`: **410 projections** (no `v_proj` on the 10 full-attention layers); vision tower frozen and not adapted | Bare names would also hit vision `Gemma4ClippableLinear` wrappers |
| LoRA | r=16, alpha=32, dropout 0.05, no DoRA, no rsLoRA, no `modules_to_save` | vLLM rejects DoRA and `modules_to_save`. r=16 is about 234 MiB bf16. |
| Data | Resolved swegemma trajectories from bundle `bundles/gen_graph_31b`, repo-train fold (fastapi+requests+httpx, 81 tasks), seeds 0–3, T=0.7. Turn-mode samples, at most 8 turns per trajectory. | Rejection sampling (STaR/RFT) |
| Selection | Up to 2 resolved runs per task, **graph-aware**: prefer runs whose graph calls were productive, then fewer calls (see `RALPH_STATE.md` gaps) | Teaches tool selection, not only brevity |
| Masking | Assistant tokens only (thought + `<channel|>` + tool call). Tool outputs, system and user turns are masked out. | |
| Tokenizer / template | The base checkpoint's tokenizer + `chat_template.jinja`, gemma4 tool format, `<|channel>`…`<channel|>` thoughts | Must round-trip through vLLM's gemma4 parser |
| Sequence length / packing | max 16,384, **no packing** (one sample per sequence) | Packing would change the attention contract |
| Global batch | 16 sequences (micro 1 × grad-accum 16 × DP 1) | |
| Token budget | 2 epochs over the rendered set | |
| Optimizer / schedule | AdamW, LR 1e-4, cosine, 3% warmup, grad clip 1.0, weight decay 0 | |
| Precision | bf16 compute; LoRA weights fp32 in training, exported bf16 | |
| Seed | 42 | |
| Held-out set | repo-val fold (rich, 48 tasks). It is never used for training. Shared-base pairs stay in one fold. | |

## 3. Execution mapping A: Colab single GPU (HF PEFT/TRL, `scripts/30_train_lora.py`)

These change only the hardware mapping. The objective and the effective updates are unchanged.

| Setting | G4 96 GB | A100-80 / H100-80 |
|---|---|---|
| Mode | bf16 LoRA (`--mode auto` picks it at ≥ 90 GiB) | QLoRA nf4 |
| TP / PP / CP / DP | 1 / 1 / 1 / 1 | 1 / 1 / 1 / 1 |
| Recompute | full activation checkpointing | full activation checkpointing |
| Loss | chunked CE over supervised positions (`--ce-chunk 512`); full-vocab logits would cost about 43 GB at 16k | same |
| Checkpoints | every 25 min, synced off the VM (`--sync rsync --sync-checkpoints`) | same |

**Caveat:** QLoRA vs bf16 is **not** a pure execution change. It alters the base arithmetic, so the two modes are
different experiments and must be reported separately.

## 4. Execution mapping B: Megatron Bridge, 1 node × 8 H100 (future; not runnable on Colab)

Resizing rules from the recommender:
- **TP must divide num_key_value_heads.** Sliding layers have 16 KV heads; full-attention layers have **4 global KV
  heads**. So the legal TP set is {1, 2, 4}.
- Use the lowest TP that fits the dense state: bf16 62.5 GB / TP=2 ≈ 31 GB per GPU, plus activations.
- **SP=True** whenever TP > 1.
- **CP=2** for 16k sequences.
- DP = 8 / (TP × PP × CP).

| Setting | Value |
|---|---|
| TP / PP / CP / DP | 2 / 1 / 2 / 2 (or TP 4, CP 2, DP 1 if memory requires) |
| sequence_parallel | True |
| Global batch | **16** (unchanged; micro 1 × DP 2 × grad-accum 8) |
| LoRA | canonical LoRA (separate q/k/v and gate/up) so the export maps 1:1 to PEFT names; dim 16, alpha 32 |
| Export | `bridge.save_hf_adapter(...)` to an HF PEFT directory (VERIFY on the exact Bridge revision) |
| Install | NeMo container (TransformerEngine prebuilt). On Colab, TransformerEngine compiles from source on every VM and Bridge requires Python < 3.13, so it is excluded there. |

Mapping B must reproduce mapping A's convergence contract. Compare loss at equal processed-token counts, not
absolute step numbers.

## 5. Validation evidence required before shipping

1. **Fit and throughput:** smoke on the heaviest samples. Record peak allocated/reserved memory, tokens/s and step
   time.
2. **Loss sentinels:** non-NaN, no skipped steps, decreasing over the first 50 steps.
3. **Effect gate:** the adapter changes logits (catches silent no-op LoRA loading in vLLM).
4. **Behaviour metrics on repo-val**, base vs adapter, 2 seeds:
   - resolve rate (paired: McNemar / bootstrap);
   - malformed tool-call rate;
   - graph-call error rate;
   - share of graph queries using exact dotted ids;
   - `search_similar_code` k distribution;
   - median tool calls.
5. **Go criteria:**
   - at least +3 resolved tasks on rich, consistent across seeds;
   - no increase in the malformed-call rate;
   - graph-call error rate down vs base.

## 6. Benchmark-only shortcuts (never convergence evidence)

Mock data, `--smoke-steps` runs and timing-only schedules are benchmark-only. Their losses and checkpoints are not
convergence evidence.
