# Everything built for the Gemma 4 Developer Agent so far (as of 2026-11-01)

Team **Agent G** (scottweeden). Public leaderboard on 2026-10-21: 3,416 teams; top score 0.24, 0.22 reached by 34 teams, median 0.13.

## Leaderboard submissions

| Date | Bundle | Public score | Rank (21 Oct) |
|---|---|---|---|
| 2026-10-07 21:35 | MoE SWE agent: `SequentialAgent(verifier, moe_router + 6 expert AgentTools, swe_coder)`, compiled with adk-submission 0.2.12 / google-adk 1.36.1 | **0.05** | 3,046 / 3,416 |
| 2026-10-22 08:24 | A1 `a1_graph_decision` with `max_time_minutes: 6` (`bundles/a1_graph_decision_6min`) | no score: "Notebook Threw Exception" | — |
| 2026-10-23 02:17 | A1 6-min + tool-use LoRA r16 (`adapters/main_lora`, model `scottweeden/gemma-4-31b-swe-tool-use-lora`) | **0.17** (best so far) | — |
| 2026-10-24 00:46 | A1 6-min, no adapter (control; the 22 Oct bundle resubmitted) | **0.12** | — |
| 2026-10-25 00:11 | A1 6-min + prompt-hygiene fixes; built with the competition's sample dummy adapter by mistake (not the trained LoRA) | **0.13** | — |
| 2026-10-26 03:37 | A1 6-min + tool-use LoRA (correct `main_lora`) + the same prompt-hygiene fixes (corrected rebuild of 25 Oct) | **0.15** | — |
| 2026-10-29 19:46 | A1 6-min + tool-use LoRA with thinking budget 2048 (from 4096) | **0.15** | — |
| 2026-11-02 09:38 | A1 6-min + tool-use LoRA + read-only `code_analyzer` sub-agent (agent_tool: read_file, search_similar_code, get_code_neighbors) | **0.15** | — |
| 2026-11-03 17:22 | A1 6-min + tool-use LoRA retrained 25 Oct (adapter v6: 115 samples / 17 tasks) in place of the 22 Oct adapter | **0.13** | — |
| 2026-11-04 23:45 | A1 6-min + tool-use LoRA + hard edit deadline (get_status every 5 calls; first edit_file by call 10 or 150 s) | **0.12** | — |

The 23 Oct adapter run finished inside the 12-hour limit. Its control, plain A1 6-min without the adapter, scored 0.12 on 24 Oct, so on the public leaderboard the adapter added 0.05 (about 3 of 58 public tasks; one draw each, so within run-to-run noise). A1 + adapter is the current architecture. The 25 Oct build carried the competition's sample dummy adapter instead of the trained LoRA (a build-script bug, since fixed), so its score does not measure the prompt change on the adapter; it scored 0.13, one task above the no-adapter control, which is inside run-to-run noise. The corrected build was submitted on 26 Oct and scored 0.15, below the architecture's 0.17, so the prompt-hygiene change was not adopted.

The 29 Oct build halved the thinking budget (2048 instead of 4096 tokens) on the adapter architecture and scored 0.15, again below the architecture's 0.17, so it was not adopted. Three one-line prompt or decoding changes on A1 + adapter have now scored 0.15, 0.15 and (with the dummy adapter) 0.13: each is within one or two tasks of its parent, inside run-to-run noise. The adapter weights remain the only change with a measured effect, so the next experiment (I06a) changes only the adapter: the 25 Oct retrain on 115 samples from 17 tasks replaces the 22 Oct adapter trained on 83 samples from 14 tasks.

The 3 Nov build swapped only the adapter weights (the 25 Oct retrain, adapter v6) and scored 0.13, below the 22 Oct adapter's 0.17, so it was not adopted; the 2 Nov read-only `code_analyzer` sub-agent also scored 0.15 and was not adopted. A1 6-min + the 22 Oct adapter (0.17) remains the architecture.

The 4 Nov build added a hard edit deadline to the prompt and scored 0.12, three tasks below the architecture, so it was not adopted. Five single changes on A1 + adapter have now scored 0.15, 0.15, 0.15, 0.13 and 0.12 (mean 0.14), which suggests the architecture's 0.17 was a favourable draw; the next experiments test the time budget (7-minute cap) rather than more prompt text.

The 22 Oct run failed during a platform-wide incident: since about 04:00 UTC on 21 Oct many teams report "Notebook Threw Exception" on zips that are byte-identical to ones that scored days earlier (competition discussion 751339). The bundle passes the static checker and the official compiler path.

## Builds that were not submitted

| Date | Build | Status | Evidence |
|---|---|---|---|
| 2026-10-07 | 30 `evidently-*` notebooks: Evidently tracing of swe-agent runs, LLM input/output validation, polygraph graph-edge checks on fastapi/httpx/rich | Tooling and exploration | Notebooks (backed up, deleted from Kaggle 2026-10-21) |
| 2026-10-08 | `gemma4_lora_prophecy`: LoRA training governed by a TLA+ spec with a prophecy variable (Lamport and Merz, *Prophecy Made Simple*) | **Dry run only**, on a 2-layer stand-in model. Its `tool_acc = 1.0` is not a real result | `adapter_dryrun/metrics.json` |
| 2026-10-09/10 | `gemma4-lora-prophecy-wet-31b`: the same spec, QLoRA on the real 31B QAT checkpoint, SWE-smith trajectories, teacher-forced next-tool accuracy | Ran on 4x L4. The staged adapter was not kept | Kernel source only |
| 2026-10-10 | `prophecy-made-simple-gemmadev` (paper track) | Last run errored | Notebook (backed up) |
| 2026-10-17 | **A1 `a1_graph_decision`**: one coder agent, the 9 harness tools, prompt template A1 with a "GRAPH decision line" | Ran end to end in the real swegemma harness: **18/81 and 17/81** public repo-train tasks on two seeds (0.222 / 0.210) | `evidence/a1_harness_runs.json` |
| 2026-10-17 | `skills_lean`, `skills_multi`: A1 plus ADK skills (`py-locate`, `repro-verify`, `swe-rca`, `test-scout`), the multi variant with a read-only `code_analyzer` sub-agent | Built, **not run** in the harness | `bundles/` |
| ~2026-10-17 | **Tool-use LoRA** (`gemma4_31b_peft_config`): r=16, alpha=32, 410 language-model projections, assistant-only loss on rejection-sampled harness trajectories. Mapping A on one Colab GPU (HF PEFT); mapping B on 8x H100 (Megatron Bridge) | **Lost with the disk**: adapter, `scripts/30_train_lora.py`, the `gen_graph_31b` trajectories and `RALPH_STATE.md`. Only the recipe survived | `recipe/gemma4_31b_peft_recipe.md` |

## The 2026-10-21/22 rebuild

Four private scratch kernels on the competition's own 4x L4 hardware:

1. `scripts/sample.py`: rejection sampling. A1 in the real harness on the repo-train fold, two passes at T=0.7, plus the rich fold at T=0.2. A logging proxy between the agent and vLLM keeps the exact request and response of every model call (4,732 calls).
2. `scripts/eval_bundles.py`: A1 and a graph-first prompt on the rich fold at concurrency 2, closer to the scorer, which runs tasks one at a time.
3. `scripts/train.py`: turn-mode SFT samples from resolved runs only, LoRA training, the recipe's gates, and export in the competition's adapter layout.
4. `scripts/eval_adapter.py`: A1 plus the adapter on the rich fold (pending: the weekly GPU quota ran out on 22 Oct).

| Run | Fold | Concurrency | Resolved | Session timeouts |
|---|---|---|---|---|
| A1, T=0.7, pass 1 | repo-train (81) | 8 | 10 | 57 |
| A1, T=0.7, pass 2 | repo-train (81) | 8 | 12 | 50 |
| A1, T=0.2 | rich (48) | 8 | 13 | 33 |
| A1, T=0.2 | rich (48) | 2 | **14** | 19 |
| graph-first, T=0.2 | rich (48) | 2 | 13 | 14 |

Aggregates are in `evidence/`; no task text, patches or tests are included (competition Rule 2.4).
