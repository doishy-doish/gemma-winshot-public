---
name: test-scout
description: Maps a symbol, module or source file to the existing tests that exercise it and prints a ready pytest command with the grading flags. Read-only, about one second.
---
# test-scout

`scripts/tests.py` scans the test files with the `ast` module. It never imports or runs code and
never writes a file.

Run it with `run_skill_script`: skill_name `test-scout`, file_path `scripts/tests.py`, and `args` with
option `name` set to the symbol (`jsonable_encoder`, `Table.add_row`), dotted id
(`rich.table.Table.add_row`) or path (`src/httpx/_urls.py`).

It prints at most 15 pytest node ids (`tests/test_x.py::test_y` or `tests/test_x.py::TestCls::test_y`)
with a score and the reason for each. Tests that use the symbol and import its module rank first,
then tests that use the name, then test files named after the module. FastAPI tutorial tests whose
docs_src module uses the symbol are also included.

The output ends with a quick pytest command (the Phase 2 flags plus `-x`) and a `Gate` line that
runs the coder's check.py over the whole test files, which is what grading runs. Report those test
files and the best node ids under TESTS: the hidden tests are added to these same files. Never edit
test files: changes to them are stripped before grading.
