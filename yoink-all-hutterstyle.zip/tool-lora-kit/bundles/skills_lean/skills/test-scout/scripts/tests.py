#!/usr/bin/env python3
"""test-scout: find the existing tests most likely to exercise a symbol, module or file.

  --name X    X is a symbol (jsonable_encoder, Table.add_row), a dotted id
              (rich.table.Table.add_row) or a source path (src/pkg/mod.py)
  --max N     node ids to print (default 15)
  --root DIR  repository root (default: the git checkout, usually /workspace; without
              --root the script stops if it finds no git checkout)

Ranking: tests that import the symbol or its module and reference the symbol
in their body come first, then tests referencing the name, then test files
named after the module (rich/table.py -> tests/test_table.py), and for FastAPI
the tutorial tests whose docs_src module uses the symbol. The script parses
test files with the ast module only: it never imports or runs repository code
and never writes a file. It prints two commands: a quick pytest run with the
Phase 2 interpreter flags and options plus -x and -p no:cacheprovider, and the
check.py gate over the whole test files, which is what Phase 2 grading runs.
Output stays under the 5,000-character command cap.
"""
import ast
import json
import os
import re
import sys
import time

OUTPUT_CAP = 4500
DEADLINE_S = 4.5
SKIP_DIRS = {".git", ".hg", "node_modules", "__pycache__", ".venv", "venv", "env", "build", "dist",
             ".tox", ".nox", ".eggs", "site-packages", ".mypy_cache", ".pytest_cache", ".ruff_cache"}
TEST_DIRS = {"tests", "test", "testing"}
# Phase 2 flags (HARNESS_README L619-L622) plus -x and -p no:cacheprovider for a quick local run.
PYTEST = ('PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1 python3 -s -m pytest -q -x -p no:anyio -p no:cacheprovider '
          '-o timeout=0 -o python_classes="Test* *Test" --tb=short')


def norm_key(key):
    return key.strip().lstrip("-").replace("-", "_").lower()


def parse_argv(argv):
    opts, pos = {}, []
    if len(argv) == 1 and argv[0].strip().startswith("{"):
        try:
            obj = json.loads(argv[0])
            if isinstance(obj, dict):
                return {norm_key(k): v for k, v in obj.items()}, []
        except ValueError:
            pass
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":  # run_skill_script puts positional_args after "--"
            pos.extend(argv[i + 1:])
            break
        if arg.startswith("-") and len(arg) > 1 and not arg[1].isdigit():
            if "=" in arg:
                key, val = arg.split("=", 1)
                opts[norm_key(key)] = val
            elif i + 1 < len(argv):
                opts[norm_key(arg)] = argv[i + 1]
                i += 1
            else:
                opts[norm_key(arg)] = True
        elif re.match(r"^[A-Za-z_][\w-]*=", arg):
            key, val = arg.split("=", 1)
            opts[norm_key(key)] = val
        else:
            pos.append(arg)
        i += 1
    return opts, pos


def find_root(explicit=None):
    """An explicit --root, else the first git checkout among SWE_WORKSPACE, cwd, /workspace, PWD, else None."""
    if explicit and os.path.isdir(str(explicit)):
        return os.path.realpath(str(explicit))
    for cand in (os.environ.get("SWE_WORKSPACE"), os.getcwd(), "/workspace", os.environ.get("PWD")):
        if cand and os.path.isdir(os.path.join(cand, ".git")):
            return os.path.realpath(cand)
    return None


def is_test_file(rel):
    parts = rel.split("/")
    base = parts[-1]
    if not base.endswith(".py") or base in ("conftest.py", "__init__.py"):
        return False
    return any(p in TEST_DIRS for p in parts[:-1]) or base.startswith("test_") or base.endswith("_test.py")


def walk_py(root):
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.endswith(".egg-info")
                             and not os.path.islink(os.path.join(dirpath, d)))
        for name in sorted(filenames):
            full = os.path.join(dirpath, name)
            if name.endswith(".py") and not os.path.islink(full):
                yield os.path.relpath(full, root).replace(os.sep, "/")


def read(root, rel, limit=1_500_000):
    try:
        full = os.path.join(root, rel)
        if os.path.getsize(full) > limit:
            return None
        with open(full, "rb") as handle:
            return handle.read().decode("utf-8", errors="replace")
    except OSError:
        return None


def module_of(rel):
    mod = rel[:-3] if rel.endswith(".py") else rel
    parts = mod.split("/")
    if parts[-1] == "__init__":
        parts = parts[:-1]
    if len(parts) > 1 and parts[0] in ("src", "lib"):
        parts = parts[1:]
    return ".".join(parts)


def resolve_target(root, name, lib_files):
    """Return (modules, symbol, owner_class) for a symbol, dotted id or path."""
    name = name.strip().strip("`'\"()")
    if name.startswith("/workspace/"):
        name = name[len("/workspace/"):]
    if name.endswith(".py") or "/" in name:
        rel = name.lstrip("./")
        return [module_of(rel)], None, None
    mods = {module_of(rel): rel for rel in lib_files}
    parts = name.split(".")
    for cut in range(len(parts), 0, -1):
        prefix = ".".join(parts[:cut])
        if prefix in mods:
            rest = parts[cut:]
            symbol = rest[-1] if rest else None
            owner = rest[-2] if len(rest) >= 2 else None
            return [prefix], symbol, owner
    symbol = parts[-1]
    owner = parts[-2] if len(parts) >= 2 and parts[-2][:1].isupper() else None
    pattern = re.compile(r"^\s*(async\s+def|def|class)\s+%s\b" % re.escape(symbol), re.M)
    found = []
    for rel in lib_files:
        src = read(root, rel)
        if src and symbol in src and pattern.search(src):
            found.append(module_of(rel))
    return found[:6], symbol, owner


class TestFile:
    def __init__(self, rel, tree):
        self.rel = rel
        self.imports = []  # (module, name or None)
        self.funcs = []    # (node_id, set of names used)
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                for alias in node.names:
                    self.imports.append((node.module, alias.name))
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    self.imports.append((alias.name, None))
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test"):
                self.funcs.append(("%s::%s" % (rel, node.name), names_in(node)))
            elif isinstance(node, ast.ClassDef) and (node.name.startswith("Test") or node.name.endswith("Test")):
                for sub in node.body:
                    if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)) and sub.name.startswith("test"):
                        self.funcs.append(("%s::%s::%s" % (rel, node.name, sub.name), names_in(sub)))


def names_in(node):
    found = set()
    for sub in ast.walk(node):
        if isinstance(sub, ast.Name):
            found.add(sub.id)
        elif isinstance(sub, ast.Attribute):
            found.add(sub.attr)
        elif isinstance(sub, ast.Constant) and isinstance(sub.value, str) and len(sub.value) < 80:
            found.add(sub.value)
    return found


def main(argv):
    opts, pos = parse_argv(argv)
    name = opts.get("name") or opts.get("symbol") or opts.get("module") or opts.get("file") or " ".join(pos)
    if not name or name is True:
        print("usage: tests.py --name SYMBOL|dotted.id|path/to/module.py [--max N] [--root DIR]")
        return 2
    name = str(name)
    try:
        limit = max(1, min(int(opts.get("max", 15)), 60))
    except (TypeError, ValueError):
        limit = 15
    root = find_root(opts.get("root"))
    if root is None:
        print("test-scout: no git checkout found (checked SWE_WORKSPACE, the current directory and /workspace), "
              "so there are no tests to scan. Pass --root DIR, or use git grep on the tests/ directory.")
        return 2
    started = time.time()
    all_py = list(walk_py(root))
    tests = [r for r in all_py if is_test_file(r)]
    lib = [r for r in all_py if not is_test_file(r) and r.split("/")[0] not in ("docs", "docs_src", "examples")
           and not r.endswith("conftest.py")]
    modules, symbol, owner = resolve_target(root, name, lib)
    mod_leafs = {m.split(".")[-1].lstrip("_") for m in modules if m}
    exported = set()
    if symbol is None:
        # Module or path target: tests usually reach it through its public names.
        by_module = {module_of(rel): rel for rel in lib}
        for mod in modules:
            src = read(root, by_module.get(mod, mod.replace(".", "/") + ".py")) or ""
            try:
                tree = ast.parse(src)
            except (SyntaxError, ValueError, RecursionError):
                continue
            for node in tree.body:
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and not node.name.startswith("_"):
                    exported.add(node.name)
    needles = [n for n in [symbol, owner] + sorted(mod_leafs) + sorted(exported)[:40] if n]
    rows, partial, file_hits = [], False, {}
    docs_cache = {}
    for rel in tests:
        if time.time() - started > DEADLINE_S:
            partial = True
            break
        src = read(root, rel)
        if not src:
            continue
        stem = rel.split("/")[-1][:-3]
        stem_match = any(stem in ("test_" + leaf, leaf + "_test", "test_" + leaf + "s") for leaf in mod_leafs)
        if not stem_match and not any(n in src for n in needles):
            continue
        try:
            tf = TestFile(rel, ast.parse(src, filename=rel))
        except (SyntaxError, ValueError, RecursionError):
            continue
        imports_module = any(m == mod or m.startswith(mod + ".") or (n and "%s.%s" % (m, n) == mod)
                             for m, n in tf.imports for mod in modules)
        imports_symbol = bool(symbol) and any(n == symbol for _m, n in tf.imports)
        docs_link = False
        if symbol:
            for m, _n in tf.imports:
                if m.startswith("docs_src."):
                    if m not in docs_cache:
                        text = read(root, m.replace(".", "/") + ".py") or ""
                        docs_cache[m] = symbol in text
                    docs_link = docs_link or docs_cache[m]
        file_score = 2 * imports_module + 2 * imports_symbol + 2 * stem_match + 2 * docs_link
        file_hits[rel] = file_score
        for node_id, used in tf.funcs:
            score, why = 0, []
            if symbol and symbol in used:
                score += 5
                why.append("uses " + symbol)
                if imports_symbol or imports_module:
                    score += 3
            if owner and owner in used:
                score += 1
            shared = sorted(exported & used)
            if shared:
                score += 3
                why.append("uses " + ",".join(shared[:3]))
            if imports_module:
                score += 2
                why.append("imports module")
            if stem_match:
                score += 2
                why.append("file name")
            if docs_link:
                score += 3
                why.append("tutorial uses " + symbol)
            if score >= (3 if symbol else 2):
                rows.append((score, node_id, why))
    rows.sort(key=lambda r: (-r[0], r[1]))
    lines = ["test-scout %r -> module(s) %s, symbol %s%s: %d candidate test(s) in %d file(s) scanned of %d%s" % (
        name, ", ".join(modules) or "?", symbol or "-", (" (class %s)" % owner) if owner else "",
        len(rows), len(file_hits), len(tests), " [PARTIAL: deadline]" if partial else "")]
    for score, node_id, why in rows[:limit]:
        lines.append("%2d  %s  (%s)" % (score, node_id, ", ".join(why)))
    if not rows:
        best_files = sorted((s, f) for f, s in file_hits.items() if s > 0)[::-1][:5]
        if best_files:
            lines.append("No single test references it; closest test files:")
            lines += ["    %s" % f for _s, f in best_files]
            lines.append('Gate (whole files, as grading runs them): python3 /tmp/swe/check.py --tests "%s"' % " ".join(
                f for _s, f in best_files[:3]))
        else:
            lines.append("No related tests found. Write a /tmp/repro.py check instead.")
    picked = [r[1] for r in rows[:8]]
    if picked:
        per_file = {}
        for node_id in picked:
            per_file.setdefault(node_id.split("::")[0], []).append(node_id)
        targets = []
        for f, ids in per_file.items():
            targets.extend([f] if len(ids) >= 4 else ids)
        lines.append("Quick run: %s %s 2>&1 | tail -n 30" % (PYTEST, " ".join(targets)))
        lines.append('Gate (whole files, as grading runs them): python3 /tmp/swe/check.py --tests "%s"' % " ".join(per_file))
    lines.append("(%.1fs, root %s)" % (time.time() - started, root))
    text, used = [], 0
    for line in lines:
        if used + len(line) + 1 > OUTPUT_CAP:
            text.append("... [more results not shown]")
            break
        text.append(line)
        used += len(line) + 1
    print("\n".join(text))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except Exception as exc:
        print("test-scout error: %s: %s" % (type(exc).__name__, str(exc)[:300]))
        sys.exit(1)
