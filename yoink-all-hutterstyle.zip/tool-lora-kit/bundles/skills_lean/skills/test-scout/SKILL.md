---
name: test-scout
description: Maps a symbol, module or source file to the existing tests that exercise it and prints a ready pytest command with the grading flags. Read-only, about one second.
---
# test-scout

`scripts/tests.py` scans the test files with the `ast` module. It never imports or runs code and
never writes a file.

Two ways to run it:
- `run_skill_script` with skill_name `test-scout`, file_path `scripts/tests.py`, and `args` with option
  `name` set to the symbol (`jsonable_encoder`, `Table.add_row`), dotted id (`rich.table.Table.add_row`)
  or path (`src/httpx/_urls.py`).
- After the repro-verify installer has run, from the shell: `python3 /tmp/swe/tests.py --name Table.add_row`.

It prints at most 15 pytest node ids (`tests/test_x.py::test_y` or `tests/test_x.py::TestCls::test_y`)
with a score and the reason for each. Tests that use the symbol and import its module rank first,
then tests that use the name, then test files named after the module. FastAPI tutorial tests whose
docs_src module uses the symbol are also included. The output ends with two ready commands:

    Quick run: PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1 python3 -s -m pytest -q -x -p no:anyio -p no:cacheprovider -o timeout=0 -o python_classes="Test* *Test" --tb=short <ids>
    Gate (whole files, as grading runs them): python3 /tmp/swe/check.py --tests "<files>"

The quick run uses the Phase 2 interpreter flags and pytest options plus `-x` (stop at the first
failure) and `-p no:cacheprovider`, so it is a fast check, not the grading run. Grading runs the
whole test files, and the hidden tests are added to these same files, so finish with the gate line:
every test in those files must pass. Never edit test files: changes to them are stripped before grading.
