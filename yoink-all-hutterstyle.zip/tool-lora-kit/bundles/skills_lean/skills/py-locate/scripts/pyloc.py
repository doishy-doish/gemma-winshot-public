#!/usr/bin/env python3
"""py-locate: read-only, async-aware Python symbol locator (standard library only).

One mode per call:
  --def NAME      where NAME is defined (bare name, Class.method or dotted id)
  --refs NAME     imports, calls and attribute uses of NAME, with the enclosing function
  --query TEXT    rank functions and classes for free text (identifiers, quoted error text)
  --outline FILE  class/def skeleton of one file with line ranges
  --grep PATTERN  regex matches in Python files (add --any for every text file)
Common options: --root DIR (default: the git checkout, usually /workspace; without
--root the script stops if it finds no git checkout), --all (also tests; docs,
docs_src and examples are always searched and ranked after library code), --max N.

The code graph used by the harness has no async def, no nested functions and no
module constants; this script indexes all of them with the ast module. It never
executes repository code, never writes a file, stops indexing at an internal
deadline and keeps its output under the 5,000-character command-output cap.
"""
import ast
import json
import math
import os
import re
import sys
import time
from collections import Counter

OUTPUT_CAP = 4500
DEADLINE_S = 6.0
MAX_FILES = 8000
MAX_FILE_BYTES = 1_500_000
SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv", "env", ".env",
    "build", "dist", ".tox", ".nox", ".eggs", "site-packages", ".mypy_cache", ".pytest_cache",
    ".ruff_cache", "htmlcov", ".idea", ".vscode",
}
AUX_DIRS = {"docs", "doc", "docs_src", "examples", "example", "benchmarks", "bench"}
TEST_DIRS = {"tests", "test", "testing"}
STOP = set(
    "a an and are as at be by can could do does for from has have how if in into is it its may "
    "might must no not of on or should so than that the then this to use used uses using was were "
    "when which while will with would you your we our issue bug fix fixed fixes feature add adds "
    "added support allow allows return returns none true false self cls def class import pr pull "
    "request description checklist type changes change test tests new make makes made also only "
    "get set value values".split()
)
IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
PART = re.compile(r"[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+")

MODES = {
    "def": "def", "definition": "def", "define": "def", "name": "def", "symbol": "def",
    "refs": "refs", "ref": "refs", "references": "refs", "uses": "refs", "usages": "refs",
    "query": "query", "q": "query", "text": "query", "search": "query",
    "outline": "outline", "file": "outline", "skeleton": "outline",
    "grep": "grep", "pattern": "grep", "regex": "grep",
}
FLAGS = {"all", "any", "fixed", "help", "h"}
BOOL_WORDS = {"true", "false", "1", "0", "yes", "no", "on", "off"}


class Out:
    """Collects output lines and stops at OUTPUT_CAP characters."""

    def __init__(self, cap=OUTPUT_CAP):
        self.cap, self.used, self.lines, self.dropped = cap, 0, [], 0

    def add(self, line=""):
        line = str(line)
        if self.used + len(line) + 1 > self.cap:
            self.dropped += 1
            return False
        self.lines.append(line)
        self.used += len(line) + 1
        return True

    def emit(self):
        text = "\n".join(self.lines)
        if self.dropped:
            text += "\n... [%d more lines not shown; narrow the request]" % self.dropped
        sys.stdout.write(text + "\n")


def norm_key(key):
    return key.strip().lstrip("-").replace("-", "_").lower()


def parse_argv(argv):
    """Accept --k v, --k=v, k=v, a JSON object, or bare positional words."""
    opts, pos = {}, []
    if len(argv) == 1 and argv[0].strip().startswith("{"):
        try:
            obj = json.loads(argv[0])
            if isinstance(obj, dict):
                return {norm_key(k): v for k, v in obj.items()}, []
        except ValueError:
            pass
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":  # run_skill_script puts positional_args after "--"
            pos.extend(argv[i + 1:])
            break
        if arg.startswith("-") and len(arg) > 1 and not arg[1].isdigit():
            key = arg
            if "=" in key:
                key, val = key.split("=", 1)
                opts[norm_key(key)] = val
            elif norm_key(key) in FLAGS:
                # run_skill_script turns args {"all": true} into "--all True"
                if i + 1 < len(argv) and argv[i + 1].strip().lower() in BOOL_WORDS:
                    opts[norm_key(key)] = truthy(argv[i + 1])
                    i += 1
                else:
                    opts[norm_key(key)] = True
            elif i + 1 < len(argv):
                opts[norm_key(key)] = argv[i + 1]
                i += 1
            else:
                opts[norm_key(key)] = True
        elif re.match(r"^[A-Za-z_][\w-]*=", arg):
            key, val = arg.split("=", 1)
            opts[norm_key(key)] = val
        else:
            pos.append(arg)
        i += 1
    return opts, pos


def truthy(value):
    return value is True or str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def find_root(explicit=None):
    """An explicit --root, else the first git checkout among SWE_WORKSPACE, cwd, /workspace, PWD, else None."""
    if explicit and os.path.isdir(str(explicit)):
        return os.path.realpath(str(explicit))
    for cand in (os.environ.get("SWE_WORKSPACE"), os.getcwd(), "/workspace", os.environ.get("PWD")):
        if cand and os.path.isdir(os.path.join(cand, ".git")):
            return os.path.realpath(cand)
    return None


def classify(rel):
    parts = rel.split("/")
    base = parts[-1]
    if any(p in TEST_DIRS for p in parts[:-1]) or base.startswith("test_") or base.endswith("_test.py") or base == "conftest.py":
        return "test"
    if parts[0] in AUX_DIRS:
        return "aux"
    return "lib"


def module_name(rel):
    mod = rel[:-3] if rel.endswith(".py") else rel
    parts = mod.split("/")
    if parts[-1] == "__init__":
        parts = parts[:-1]
    if parts and parts[0] in ("src", "lib") and len(parts) > 1:
        parts = parts[1:]
    elif parts and parts[0] == "docs_src" and len(parts) > 1:
        parts = parts[1:]
    return ".".join(parts)


def list_files(root, want, any_text=False):
    """Return [(rel, kind)] sorted lib first; skip symlinks and cache/build dirs."""
    found = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = sorted(
            d for d in dirnames
            if d not in SKIP_DIRS and not d.endswith(".egg-info") and not os.path.islink(os.path.join(dirpath, d))
        )
        for name in sorted(filenames):
            if not any_text and not name.endswith(".py"):
                continue
            full = os.path.join(dirpath, name)
            if os.path.islink(full):
                continue
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            kind = classify(rel)
            if kind in want:
                found.append((rel, kind))
            if len(found) >= MAX_FILES:
                break
    order = {"lib": 0, "aux": 1, "test": 2}
    found.sort(key=lambda item: (order[item[1]], item[0]))
    return found


def read_text(root, rel):
    full = os.path.join(root, rel)
    try:
        if os.path.getsize(full) > MAX_FILE_BYTES:
            return None
        with open(full, "rb") as handle:
            data = handle.read()
    except OSError:
        return None
    if b"\x00" in data[:4096]:
        return None
    return data.decode("utf-8", errors="replace")


def unparse(node, limit=90):
    try:
        text = ast.unparse(node)
    except Exception:  # Python < 3.9 or exotic nodes
        text = "..."
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 3] + "..."


def signature(node):
    if isinstance(node, ast.ClassDef):
        bases = ", ".join(unparse(b, 40) for b in node.bases)
        return "(%s)" % bases if bases else ""
    ret = " -> " + unparse(node.returns, 40) if getattr(node, "returns", None) is not None else ""
    return "(%s)%s" % (unparse(node.args, 110), ret)


def split_words(text):
    out = []
    for word in IDENT.findall(text):
        low = word.lower()
        if len(low) > 1 and low not in STOP:
            out.append(low)
        parts = [p.lower() for p in PART.findall(word)] + word.lower().split("_")
        if len(parts) > 2:
            out.extend(p for p in parts if len(p) > 2 and p not in STOP and p != low)
    return out


class Def:
    __slots__ = ("qual", "kind", "rel", "start", "end", "node", "dotted", "nested",
                 "doc", "tokens", "strings", "fkind", "depth")

    @property
    def sig(self):
        node = self.node
        if node is None:
            return ""
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            return " = " + unparse(node.value, 60) if getattr(node, "value", None) is not None else ""
        return signature(node)

    @property
    def decos(self):
        node = self.node
        return [unparse(x, 50) for x in getattr(node, "decorator_list", [])][:3]


def index_file(rel, fkind, src, want_tokens):
    try:
        tree = ast.parse(src, filename=rel)
    except (SyntaxError, ValueError, RecursionError, MemoryError):
        return []
    module = module_name(rel)
    defs = []

    lines = src.splitlines()
    memo = {}

    def span_tokens(first, last):
        """Words of source lines first..last (1-based, inclusive), tokenized once per line."""
        words = []
        for index in range(max(first, 1) - 1, min(last, len(lines), first + 300)):
            cached = memo.get(index)
            if cached is None:
                cached = memo[index] = split_words(lines[index])
            words.extend(cached)
        return words

    def visit(nodes, prefix, in_func, depth):
        for node in nodes:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                d = Def()
                d.qual = ".".join(prefix + [node.name])
                d.kind = "class" if isinstance(node, ast.ClassDef) else (
                    "async def" if isinstance(node, ast.AsyncFunctionDef) else "def")
                d.rel, d.fkind, d.depth = rel, fkind, depth
                d.start = min([node.lineno] + [x.lineno for x in node.decorator_list])
                d.end = getattr(node, "end_lineno", node.lineno) or node.lineno
                d.node = node
                d.dotted = (module + "." if module else "") + d.qual
                d.nested = in_func
                doc = ast.get_docstring(node, clean=False) or ""
                first = [ln.strip() for ln in doc.splitlines() if ln.strip()]
                d.doc = first[0][:100] if first else ""
                if want_tokens:
                    last = d.end
                    if isinstance(node, ast.ClassDef):
                        children = [n.lineno for n in node.body
                                    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))]
                        last = min(children) - 1 if children else min(d.end, d.start + 80)
                    d.tokens = Counter(split_words(node.name) * 3 + span_tokens(d.start, last))
                else:
                    d.tokens = None
                d.strings = None
                defs.append(d)
                visit(node.body, prefix + [node.name],
                      in_func or not isinstance(node, ast.ClassDef), depth + 1)
            elif isinstance(node, (ast.Assign, ast.AnnAssign)) and not in_func:
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                for target in targets:
                    if isinstance(target, ast.Name):
                        d = Def()
                        d.qual = ".".join(prefix + [target.id])
                        d.kind = "const" if not prefix else "attr"
                        d.rel, d.fkind, d.depth = rel, fkind, depth
                        d.start = node.lineno
                        d.end = getattr(node, "end_lineno", node.lineno) or node.lineno
                        d.node = node
                        d.doc, d.nested = "", False
                        d.dotted = (module + "." if module else "") + d.qual
                        d.tokens = Counter(split_words(target.id)) if want_tokens else None
                        d.strings = None
                        defs.append(d)
            elif isinstance(node, (ast.If, ast.Try, ast.With, ast.AsyncWith, ast.For, ast.While)) and not in_func:
                # Definitions guarded by if TYPE_CHECKING / try-import blocks.
                blocks = [getattr(node, "body", []), getattr(node, "orelse", []), getattr(node, "finalbody", [])]
                blocks += [h.body for h in getattr(node, "handlers", [])]
                for block in blocks:
                    visit(block, prefix, in_func, depth)

    visit(tree.body, [], False, 0)
    return defs


def prefilter(root, files, words, exact, keep):
    """Rank files by presence of query words (file-level idf); keep the best `keep`."""
    texts = {}
    for rel, fkind in files:
        src = read_text(root, rel)
        if src is not None:
            texts[rel] = (fkind, src, src.lower())
    vocab = [w for w in set(words) if len(w) >= 4][:60]
    nfile = float(len(texts) or 1)
    df = {w: sum(1 for _, _, low in texts.values() if w in low) for w in vocab}
    ranked = []
    for rel, (fkind, src, low) in texts.items():
        score = sum(math.log(1 + nfile / (1 + df[w])) for w in vocab if w in low)
        if any(e in src for e in exact):
            score += 100.0
        if fkind != "lib":
            score *= 0.45
        ranked.append((score, rel))
    ranked.sort(reverse=True)
    kinds = dict(files)
    chosen = [(rel, kinds[rel]) for score, rel in ranked[:keep] if score > 0]
    return chosen, {r: v[1] for r, v in texts.items()}


def build_index(root, want, want_tokens, deadline, must_contain=None, only=None, cache=None):
    """Parse candidate files; with must_contain, skip files that lack that text."""
    files = only if only is not None else list_files(root, want)
    defs, sources, partial = [], {}, False
    for rel, fkind in files:
        if time.time() > deadline:
            partial = True
            break
        src = cache.get(rel) if cache else read_text(root, rel)
        if src is None or (must_contain and must_contain not in src):
            continue
        sources[rel] = src
        defs.extend(index_file(rel, fkind, src, want_tokens))
    return defs, sources, partial, len(files)


def fmt_def(d):
    flags = []
    if d.kind == "async def":
        flags.append("async")
    if d.nested:
        flags.append("nested")
    graph = "" if (d.kind in ("def", "class") and not d.nested) else "  [not in code graph]"
    deco = ("  @" + " @".join(d.decos)) if d.decos else ""
    tag = "" if d.fkind == "lib" else "  (%s)" % d.fkind
    return "%s:%d-%d  %s %s%s%s%s\n    id: %s%s" % (
        d.rel, d.start, d.end, d.kind, d.qual, d.sig, deco, tag, d.dotted, graph)


def name_matches(d, name):
    if name == d.qual or name == d.dotted:
        return 3
    if d.dotted.endswith("." + name) or d.qual.endswith("." + name):
        return 2
    return 0


def mode_def(root, name, include_all, limit, out):
    want = {"lib", "aux", "test"} if include_all else {"lib", "aux"}
    name = name.strip().strip("`'\"()")
    if name.endswith(".py"):
        return mode_outline(root, name, limit, out)
    last = name.split(".")[-1]
    defs, _, partial, nfiles = build_index(root, want, False, time.time() + DEADLINE_S, must_contain=last)
    if not any(name_matches(d, name) for d in defs):
        # Fall back to a full index so near-miss names can be suggested.
        defs, _, partial, nfiles = build_index(root, want, False, time.time() + DEADLINE_S / 2)
    hits = sorted((d for d in defs if name_matches(d, name)),
                  key=lambda d: (-name_matches(d, name), {"lib": 0, "aux": 1, "test": 2}[d.fkind], d.rel, d.start))
    out.add("py-locate def %r: %d match(es) in %d files%s" % (name, len(hits), nfiles, " [PARTIAL index]" if partial else ""))
    for d in hits[:limit]:
        if not out.add(fmt_def(d)):
            break
    if not hits:
        last = name.split(".")[-1].lower()
        near = [d for d in defs if last and last in d.qual.lower()][:8]
        if near:
            out.add("No exact match. Names containing %r:" % last)
            for d in near:
                out.add("  %s:%d  %s %s" % (d.rel, d.start, d.kind, d.qual))
        else:
            out.add("No definition found. Try --grep %s or --query with the issue words." % last)


def enclosing(defs_by_file, rel, line):
    best = None
    for d in defs_by_file.get(rel, ()):
        if d.kind in ("const", "attr"):
            continue
        if d.start <= line <= d.end and (best is None or d.depth > best.depth):
            best = d
    return best.qual if best else "<module>"


def mode_refs(root, name, include_all, limit, out):
    want = {"lib", "aux", "test"} if include_all else {"lib", "aux"}
    last = name.strip().strip("`'\"()").split(".")[-1]
    if not last:
        out.add("refs needs a name")
        return
    defs, sources, partial, nfiles = build_index(root, want, False, time.time() + DEADLINE_S, must_contain=last)
    pattern = re.compile(r"\b%s\b" % re.escape(last))
    by_file = {}
    for d in defs:
        by_file.setdefault(d.rel, []).append(d)
    hits, per_file = [], Counter()
    for rel, src in sources.items():
        for lineno, text in enumerate(src.splitlines(), 1):
            if pattern.search(text):
                stripped = text.strip()
                if stripped.startswith("#"):
                    continue
                if re.match(r"(async\s+)?def\s+%s\b|class\s+%s\b" % (re.escape(last), re.escape(last)), stripped):
                    role = "DEF"
                elif stripped.startswith(("import ", "from ")):
                    role = "IMPORT"
                else:
                    role = "use"
                hits.append((rel, lineno, role, stripped))
                per_file[rel] += 1
    out.add("py-locate refs %r: %d line(s) in %d file(s)%s" % (last, len(hits), len(per_file), " [PARTIAL index]" if partial else ""))
    order = {"lib": 0, "aux": 1, "test": 2}
    hits.sort(key=lambda h: (order[classify(h[0])], h[2] != "DEF", h[0], h[1]))
    for rel, lineno, role, text in hits[:limit]:
        if not out.add("%s:%d [%s in %s] %s" % (rel, lineno, role, enclosing(by_file, rel, lineno), text[:110])):
            break
    if len(per_file) > 1:
        out.add("files: " + ", ".join("%s(%d)" % (f, c) for f, c in per_file.most_common(10)))


def query_terms(text):
    quoted = [q for q in re.findall(r"`([^`]{3,120})`|'([^']{6,120})'|\"([^\"]{6,120})\"", text)]
    literals = [next(x for x in q if x) for q in quoted]
    idents = [w for w in IDENT.findall(text) if len(w) >= 3 and ("_" in w or any(c.isupper() for c in w[1:]))]
    idents += [lit.strip("()") for lit in literals if IDENT.fullmatch(lit.strip("()").split(".")[-1] or "-")]
    paths = re.findall(r"[\w./-]+\.py\b", text)
    return split_words(text), list(dict.fromkeys(idents))[:40], [l for l in literals if " " in l][:10], paths


def mode_query(root, text, include_all, limit, out):
    want = {"lib", "aux", "test"} if include_all else {"lib", "aux"}
    started = time.time()
    words, idents, literals, paths = query_terms(text)
    files = list_files(root, want)
    exact = [i.split(".")[-1] for i in idents if len(i.split(".")[-1]) >= 3] + literals
    chosen, cache = prefilter(root, files, words, exact, keep=150)
    defs, sources, partial, _ = build_index(root, want, True, started + DEADLINE_S, only=chosen, cache=cache)
    nfiles = len(files)
    literal_lines = {}
    for rel, src in sources.items():
        low_lines = src.lower().splitlines()
        hits = {i + 1 for i, text in enumerate(low_lines) if any(l.lower() in text for l in literals)}
        if hits:
            literal_lines[rel] = hits
    qcount = Counter(words)
    docs = [d for d in defs if d.tokens]
    if not docs or not qcount:
        out.add("py-locate query: nothing to rank (empty index or no usable words)")
        return
    n = len(docs)
    df = Counter()
    for d in docs:
        df.update(set(d.tokens) & set(qcount))
    avg = sum(sum(d.tokens.values()) for d in docs) / float(n)
    ident_last = {i.split(".")[-1].lower() for i in idents}
    scored = []
    for d in docs:
        score, why = 0.0, []
        length = sum(d.tokens.values()) or 1
        for term, qtf in qcount.items():
            tf = d.tokens.get(term)
            if tf:
                idf = math.log(1 + (n - df[term] + 0.5) / (df[term] + 0.5))
                score += idf * tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * length / avg)) * min(qtf, 3)
        last = d.qual.split(".")[-1].lower()
        if last in ident_last:
            score += 8.0
            why.append("name")
        hit_lines = literal_lines.get(d.rel)
        if hit_lines and any(d.start <= ln <= d.end for ln in hit_lines) and d.kind not in ("class",):
            score += 6.0
            why.append("text")
        if any(p.endswith(d.rel) or d.rel.endswith(p.lstrip("./")) for p in paths):
            score += 3.0
            why.append("path")
        if d.fkind != "lib":
            score *= 0.45
        if d.kind in ("const", "attr"):
            score *= 0.6
        if score > 0:
            scored.append((score, d, why))
    scored.sort(key=lambda item: -item[0])
    out.add("py-locate query over %d symbols (%d of %d files pre-ranked)%s; top %d:" % (
        n, len(chosen), nfiles, " [PARTIAL index]" if partial else "", min(limit, len(scored))))
    for score, d, why in scored[:limit]:
        line = "%5.1f  %s" % (score, fmt_def(d))
        if why:
            line += "  matched: " + ",".join(why)
        if d.doc:
            line += "\n    doc: " + d.doc
        if not out.add(line):
            break
    if not scored:
        out.add("No match. Try --grep with a distinctive string from the issue.")


def mode_outline(root, path, limit, out):
    rel = path.strip()
    for prefix in ("/workspace/", "./"):
        if rel.startswith(prefix):
            rel = rel[len(prefix):]
    rel = rel.lstrip("/")
    if ".." in rel.split("/"):
        out.add("outline: path must stay inside the repository")
        return
    src = read_text(root, rel)
    if src is None:
        out.add("outline: cannot read %s (missing, binary or too large)" % rel)
        return
    defs = index_file(rel, classify(rel), src, False)
    total = src.count("\n") + 1
    out.add("py-locate outline %s (%d lines, %d symbols)" % (rel, total, len(defs)))
    for d in defs[: max(limit, 80)]:
        if d.kind in ("const", "attr") and d.depth > 0:
            continue
        deco = ("  @" + " @".join(d.decos)) if d.decos else ""
        body = d.sig if d.kind not in ("const", "attr") else ""
        if not out.add("%s%d-%d %s %s%s%s%s" % ("  " * d.depth, d.start, d.end, d.kind,
                                                d.qual.split(".")[-1], body[:80], deco, "")):
            break


def mode_grep(root, pattern, include_all, any_text, fixed, limit, out):
    want = {"lib", "aux", "test"} if include_all else {"lib", "aux"}
    try:
        regex = re.compile(re.escape(pattern) if fixed else pattern)
    except re.error:
        regex = re.compile(re.escape(pattern))
    deadline = time.time() + DEADLINE_S
    files = list_files(root, want, any_text=any_text)
    hits, nfiles, partial = 0, 0, False
    out.add("py-locate grep %r over %d files" % (pattern, len(files)))
    for rel, _kind in files:
        if time.time() > deadline:
            partial = True
            break
        src = read_text(root, rel)
        if src is None:
            continue
        matched = False
        for lineno, text in enumerate(src.splitlines(), 1):
            if regex.search(text):
                hits += 1
                matched = True
                if hits <= limit:
                    out.add("%s:%d: %s" % (rel, lineno, text.strip()[:120]))
        nfiles += matched
    out.add("%d match(es) in %d file(s)%s%s" % (
        hits, nfiles, " (showing %d)" % limit if hits > limit else "", " [PARTIAL: deadline]" if partial else ""))


def main(argv):
    opts, pos = parse_argv(argv)
    out = Out()
    if truthy(opts.get("help")) or truthy(opts.get("h")):
        sys.stdout.write(__doc__)
        return 0
    mode, value = None, None
    for key, val in opts.items():
        if key in MODES and not isinstance(val, bool):
            mode, value = MODES[key], str(val)
            break
    if mode is None and pos:
        joined = " ".join(pos)
        if len(pos) == 1 and re.fullmatch(r"[A-Za-z_][\w.]*", pos[0]):
            mode, value = "def", pos[0]
        else:
            mode, value = "query", joined
    if mode is None or not value:
        out.add("usage: pyloc.py --def NAME | --refs NAME | --query TEXT | --outline FILE | --grep PATTERN "
                "[--all] [--any] [--max N] [--root DIR]")
        out.emit()
        return 2
    root = find_root(opts.get("root"))
    if root is None:
        out.add("py-locate: no git checkout found (checked SWE_WORKSPACE, the current directory and /workspace), "
                "so there is no repository to search. Pass --root DIR, or use git grep from the shell.")
        out.emit()
        return 2
    include_all = truthy(opts.get("all", False))
    try:
        limit = max(1, min(int(opts.get("max", 0)) or {"def": 12, "refs": 40, "query": 8, "outline": 120, "grep": 60}[mode], 200))
    except (TypeError, ValueError):
        limit = 12
    started = time.time()
    if mode == "def":
        mode_def(root, value, include_all, limit, out)
    elif mode == "refs":
        mode_refs(root, value, include_all, limit, out)
    elif mode == "query":
        mode_query(root, value[:6000], include_all, limit, out)
    elif mode == "outline":
        mode_outline(root, value, limit, out)
    else:
        mode_grep(root, value, include_all, truthy(opts.get("any", False)), truthy(opts.get("fixed", False)), limit, out)
    out.add("(%.1fs, root %s)" % (time.time() - started, root))
    out.emit()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as exc:  # never crash with a long traceback inside the agent loop
        sys.stdout.write("py-locate error: %s: %s\n" % (type(exc).__name__, str(exc)[:300]))
        sys.exit(1)
