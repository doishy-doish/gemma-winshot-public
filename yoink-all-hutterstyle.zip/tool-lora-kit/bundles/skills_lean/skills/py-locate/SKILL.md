---
name: py-locate
description: Read-only Python symbol locator that also indexes async def, nested functions and module constants, which the code graph lacks. Definitions, references, outlines, ranked search.
---
# py-locate

`scripts/pyloc.py` parses the repository with the `ast` module. It never runs repository
code and never writes a file. Output stays under the 5,000-character command-output cap.

Two ways to run it:
- `run_skill_script` with skill_name `py-locate`, file_path `scripts/pyloc.py`, and `args`
  holding exactly one of the options below (for example option `def` set to `HTTPParser.complete`).
- After the repro-verify installer has run, from the shell: `python3 /tmp/swe/pyloc.py --def HTTPParser.complete`.

| Option | Value | Prints |
|---|---|---|
| `def` | a name, `Class.method` or a dotted id | `path:start-end`, `async def`/`def`/`class`, signature, decorators, and the dotted id. Ids marked `[not in code graph]` are async or nested: do not query the graph tools with them. |
| `refs` | a name | Each import, call and attribute use as `path:line [role in EnclosingFunction] code`. |
| `query` | the task title or issue text | The top 8 functions and classes. Exact identifiers and quoted error text from the issue rank highest. |
| `outline` | a file path | The class and def skeleton with line ranges, so each `read_file` window can stay inside the 150-line limit. |
| `grep` | a regular expression | `path:line: text` for Python files. Add option `any` true for every text file. |

Tests are skipped by default; add option `all` true to include them. docs, docs_src and examples
are always searched and ranked after library code. Add option `max` to change the number of results.

Use the printed line ranges as `start_line`/`end_line` for `read_file`. Prefer `def` over a broad
`query` whenever the issue names an identifier.
