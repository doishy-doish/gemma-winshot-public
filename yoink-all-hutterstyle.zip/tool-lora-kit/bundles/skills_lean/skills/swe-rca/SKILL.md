---
name: swe-rca
description: Root-cause playbook for a code bug. Load it when the first fix did not change the repro or the cause is unclear. Hypotheses, rule-outs and a pre-submit gate.
---
# swe-rca: root cause before the second attempt

Adapted from the `root-cause-investigation` and `analysis-qa-checklist` skills (MIT, see
`references/ATTRIBUTION.txt`). Metric-investigation steps are rewritten for code bugs.

1. **Confirm the signal.** Reproduce under `/tmp` and record the exact wrong output or exception.
   If nothing fails, the task is probably a feature (a new name, parameter or method). Implement
   what the title says, not a guess at a bug.
2. **Scope it.** Find which inputs, types or options fail and which pass. A fix that only covers
   the first example usually fails the hidden tests for the other cases the title names.
3. **Correlate with the executed path.** Use the `trace.py` output and `pyloc.py --refs` on the
   suspicious name. Look for duplicates: sync/async twins, the same logic in a sibling class, or a
   docs_src copy.
4. **Hypotheses.** Write down at most three. For each, give the proposed cause, the effect you would
   see if it were true, and one command that tests it. Test the most likely and cheapest first.
   Mark each one confirmed or refuted, and never re-read a refuted lead.
5. **Accept a root cause only if** it explains every failing input, the fix flips the repro, and the
   existing tests for that module still pass.
6. **Gate before `submit_patch`.** Check each point:
   - The change answers the task title, including any new names or signatures it lists.
   - Edge cases named in the task are handled.
   - The public API stays backward compatible unless the task asks to change it.
   - The diff is minimal: no unrelated edits, debug prints, test or config edits, or scratch files in `/workspace`.
   - `check.py` prints `READY`.
