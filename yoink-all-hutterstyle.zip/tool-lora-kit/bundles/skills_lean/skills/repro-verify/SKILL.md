---
name: repro-verify
description: Installs /tmp/swe helper scripts in one call. trace.py lists the repository functions a repro executes; check.py is the pre-submit gate for compile, import, tests and patch hygiene.
---
# repro-verify

## Install once per task
Call `run_skill_script` with skill_name `repro-verify` and file_path `scripts/install.py`, with no
other arguments. It prints `INSTALLED /tmp/swe` and writes `pyloc.py`, `tests.py`, `trace.py` and
`check.py` there, outside the repository. It prints `INSTALL FAILED` when it cannot see
`/workspace/.git`, because then the shell could not see the helpers either. Install once. If it fails
twice, or a later command reports that a `/tmp/swe` file is missing, stop using the helpers (check.py
included) and work with git grep and the pytest command.

## Reproduce and trace
Write the repro under `/tmp` from the shell, never inside `/workspace`:

    cat > /tmp/repro.py <<'EOF'
    ...minimal code that shows the bug...
    EOF
    python3 /tmp/swe/trace.py --script /tmp/repro.py

It prints the repository functions executed, in first-call order, including coroutines and
TestClient threads. It also prints exceptions raised inside the repository, whether handled or
not, and the uncaught traceback. Edit a function on that path. For a one-liner, use
`python3 /tmp/swe/trace.py -c "..."`.

Offline repro starters:
- FastAPI: `from fastapi.testclient import TestClient`, build a small `app`, then `TestClient(app).get("/path")`.
- Rich: `Console(record=True, width=80, color_system=None)`, print to it, then `console.export_text()`.
- Requests: `requests.Request("GET", url, ...).prepare()` builds a request without network access.
- HTTPX: build objects directly (`httpx.URL`, `httpx.Request`, parsers). Use a mock transport only if
  the package defines one.

## Gate before submit_patch
    python3 /tmp/swe/check.py --tests "tests/test_x.py tests/test_z.py"

Pass whole test files: grading runs every test in them, while node ids cover only part of a file.
It compiles and imports the changed modules and reruns `/tmp/repro.py` if it exists. It runs the
given test files with the Phase 2 grading flags, without `-x`, and prints the passed and failed
counts. It reports patch hygiene: untracked files that would enter the patch, scratch files,
edits to protected test/config files and binary changes, plus a `WARN` line for debug prints. It
deletes leftover `.adk_exec_*` copies. The last line is `READY` or `NOT READY: reasons`. Fix each
reason, check each `WARN` line, then call `submit_patch`. Run it at most twice per task. Its internal
deadline of about two minutes stays below the command timeout; when little session time is left,
add `--time-left` with get_status's `time_seconds_remaining` so it finishes in time.
