#!/usr/bin/env python3
"""check: the pre-submit gate. Run it once after your last edit, before submit_patch.

  --tests "FILES"   test files to run (space or comma separated). Grading runs whole test
                    files, so pass file paths for the final gate; node ids also work for a
                    quick check but only cover part of a file
  --repro PATH      reproduction script to rerun (default: repro.py in the temp dir that
                    holds this install, normally /tmp/repro.py, if it exists)
  --files "A,B"     files to check (default: every file changed against the baseline)
  --timeout S       pytest time limit in seconds (default 60, max 150)
  --time-left S     seconds left in the session (get_status time_seconds_remaining); the
                    gate then stops about 25 s before that
  --no-import       skip the import check
  --keep-adk-exec   do not delete leftover .adk_exec_* helper files
  --root DIR        repository root (default: the git checkout, usually /workspace)

Steps, all bounded by an internal deadline (120 s by default, below the command timeout):
  1. compile every changed or new .py in memory (no bytecode written);
  2. import each changed module in a child process with PYTHONSAFEPATH=1
     PYTHONNOUSERSITE=1, as in Phase 2 grading;
  3. rerun the reproduction script;
  4. run the given tests with the Phase 2 flags
     (-p no:anyio -o timeout=0 -o python_classes="Test* *Test"), without -x, and
     report the passed/failed counts;
  5. hygiene: untracked files that `git add -N .` would put in the patch, scratch
     files at the top level or outside a package, edits to protected test/config
     files (stripped before grading), binary changes and an empty diff. Debug output
     added to library code (a bare print(, breakpoint(, pdb) is a WARN line, not a
     NOT READY reason, because print can be legitimate.
It deletes only leftover .adk_exec_* files (harness script copies) and never
runs git commands that change the index, HEAD or the working tree.
"""
import json
import os
import re
import subprocess
import sys
import time

OUTPUT_CAP = 4600
DEADLINE_S = 120.0
PROTECTED = re.compile(
    r"(^|/)(test_[^/]*\.py|[^/]*_test\.py|conftest\.py|pytest\.ini|pyproject\.toml|tox\.ini|setup\.cfg|"
    r"\.pytest\.ini|sitecustomize\.py|usercustomize\.py|_swegemma_stubs\.py|[^/]*\.pth)$|(^|/)(tests|test|testing)/.*\.py$")
# A scratch-like name (repro.py, scratch_x.py, tmp1.txt, output.log) counts only at the top level or in a
# directory that is not a Python package, so modules such as templates.py, outcome.py or debug_utils.py
# inside a package are never flagged. JUNK matches tool artifacts anywhere.
SCRATCH = re.compile(r"^(repro|reproduce|scratch|debug|tmp|temp|out|output)([_.-]|\d|$)", re.I)
JUNK = re.compile(r"\.(log|orig|rej|bak|swp|db|sqlite3?|out|pyc)$|(^|/)\.adk_exec")
# Added debug output: bare print(/ic( calls (not .print( methods, not def print), breakpoint(), pdb.
DEBUG = re.compile(r"^\+(?!\+\+).*((?<![\w.])(?<!def )print\(|\bbreakpoint\(|\bpdb\.set_trace\(|\bimport pdb\b|"
                   r"(?<![\w.])(?<!def )ic\()")
DEBUG_SKIP = re.compile(r"^(docs|doc|docs_src|examples?|scripts|benchmarks?)/")
GIT = ["git", "-c", "core.fsmonitor=false", "-c", "core.hooksPath=/dev/null", "--no-pager"]


def norm_key(key):
    return key.strip().lstrip("-").replace("-", "_").lower()


def parse_argv(argv):
    opts = {}
    if len(argv) == 1 and argv[0].strip().startswith("{"):
        try:
            obj = json.loads(argv[0])
            if isinstance(obj, dict):
                return {norm_key(k): v for k, v in obj.items()}
        except ValueError:
            pass
    flags = {"no_import", "keep_adk_exec"}
    bool_words = {"true", "false", "1", "0", "yes", "no", "on", "off"}
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":  # run_skill_script puts positional_args after "--": treat them as test ids
            rest = " ".join(argv[i + 1:]).strip()
            if rest:
                opts["tests"] = (str(opts.get("tests") or "") + " " + rest).strip()
            break
        if arg.startswith("--"):
            key = arg
            if "=" in key:
                key, val = key.split("=", 1)
                opts[norm_key(key)] = val
            elif norm_key(key) in flags:
                # run_skill_script turns args {"no_import": true} into "--no_import True"
                if i + 1 < len(argv) and argv[i + 1].strip().lower() in bool_words:
                    opts[norm_key(key)] = truthy(argv[i + 1])
                    i += 1
                else:
                    opts[norm_key(key)] = True
            elif i + 1 >= len(argv):
                opts[norm_key(key)] = True
            else:
                opts[norm_key(key)] = argv[i + 1]
                i += 1
        elif re.match(r"^[A-Za-z_][\w-]*=", arg):
            key, val = arg.split("=", 1)
            opts[norm_key(key)] = val
        else:
            opts.setdefault("tests", "")
            opts["tests"] = (str(opts["tests"]) + " " + arg).strip()
        i += 1
    return opts


def truthy(value):
    return value is True or str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def find_root(explicit=None):
    if explicit and os.path.isdir(str(explicit)):
        return os.path.realpath(str(explicit))
    for cand in (os.environ.get("SWE_WORKSPACE"), os.getcwd(), "/workspace", os.environ.get("PWD")):
        if cand and os.path.isdir(os.path.join(cand, ".git")):
            return os.path.realpath(cand)
    return os.path.realpath(os.getcwd())


def tmp_base():
    """The temp dir the shell sees: the parent of the install dir (/tmp/swe -> /tmp), else /tmp."""
    here = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else ""
    return os.path.dirname(here) if os.path.basename(here) == "swe" else "/tmp"


def is_scratch(rel, root):
    if JUNK.search(rel):
        return True
    if not SCRATCH.match(os.path.basename(rel)):
        return False
    parent = os.path.dirname(rel)
    return not parent or not os.path.isfile(os.path.join(root, parent, "__init__.py"))


def run(cmd, root, timeout, env=None):
    try:
        proc = subprocess.run(cmd, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              stdin=subprocess.DEVNULL, timeout=max(1.0, timeout))
        return proc.returncode, proc.stdout.decode("utf-8", "replace"), proc.stderr.decode("utf-8", "replace")
    except subprocess.TimeoutExpired as exc:
        out = (exc.stdout or b"").decode("utf-8", "replace") if isinstance(exc.stdout, bytes) else ""
        return None, out, "timed out after %.0fs" % timeout
    except OSError as exc:
        return None, "", str(exc)


def git(root, *args):
    code, out, _err = run(GIT + list(args), root, 20)
    return out if code == 0 else ""


def module_for(rel):
    mod = rel[:-3]
    parts = mod.split("/")
    if parts[-1] == "__init__":
        parts = parts[:-1]
    if len(parts) > 1 and parts[0] in ("src", "lib"):
        parts = parts[1:]
    return ".".join(parts)


def tail(text, count, width=170):
    lines = [ln.rstrip()[:width] for ln in (text or "").splitlines() if ln.strip()]
    return lines[-count:]


def pytest_summary(text):
    """The final 'N passed, M failed ...' line of a pytest -q run, or ''."""
    for ln in reversed((text or "").splitlines()):
        if re.search(r"\b\d+ (passed|failed|errors?|skipped|deselected|xfailed|xpassed)\b|no tests ran", ln):
            return ln.strip().strip("=").strip()[:160]
    return ""


def main(argv):
    opts = parse_argv(argv)
    root = find_root(opts.get("root"))
    started = time.time()
    deadline = DEADLINE_S
    if opts.get("time_left") not in (None, True):
        try:
            deadline = max(15.0, min(DEADLINE_S, float(opts["time_left"]) - 25.0))
        except (TypeError, ValueError):
            pass
    left = lambda: deadline - (time.time() - started)
    share = lambda cap: min(cap, max(3.0, (left() - 5.0) * 0.2))  # import/repro share of what is left
    out, problems, warnings = [], [], []
    env = dict(os.environ, PYTHONSAFEPATH="1", PYTHONNOUSERSITE="1", PYTHONDONTWRITEBYTECODE="1")

    if not os.path.isdir(os.path.join(root, ".git")):
        print("check: %s is not a git checkout; pass --root /workspace" % root)
        return 2
    base = "_swegemma_baseline" if git(root, "rev-parse", "-q", "--verify", "_swegemma_baseline^{commit}").strip() else "HEAD"

    # Leftover harness copies of skill scripts would enter the patch through `git add -N .`.
    untracked = [p for p in git(root, "ls-files", "--others", "--exclude-standard").splitlines() if p.strip()]
    removed = []
    if not truthy(opts.get("keep_adk_exec", False)):
        for rel in list(untracked):
            if os.path.basename(rel).startswith(".adk_exec"):
                try:
                    os.unlink(os.path.join(root, rel))
                    removed.append(rel)
                    untracked.remove(rel)
                except OSError:
                    pass
    changed = [p for p in git(root, "diff", "--name-only", base).splitlines() if p.strip()]
    if opts.get("files") and opts.get("files") is not True:
        targets = [f.strip().lstrip("/") for f in re.split(r"[,\s]+", str(opts["files"])) if f.strip()]
        targets = [f[len("workspace/"):] if f.startswith("workspace/") else f for f in targets]
    else:
        targets = changed + [u for u in untracked if u.endswith(".py")]  # new modules too, even scratch-like
    source_targets = [f for f in targets if f.endswith(".py") and not PROTECTED.search(f)
                      and os.path.isfile(os.path.join(root, f))]

    # 1. Compile in memory.
    compile_bad = []
    for rel in source_targets:
        try:
            with open(os.path.join(root, rel), "rb") as handle:
                compile(handle.read(), rel, "exec", dont_inherit=True)
        except SyntaxError as exc:
            compile_bad.append("%s:%s: %s" % (rel, exc.lineno, exc.msg))
        except (OSError, ValueError) as exc:
            compile_bad.append("%s: %s" % (rel, exc))
    out.append("COMPILE %s (%d file(s))" % ("FAIL" if compile_bad else "ok", len(source_targets)))
    out.extend("  " + x for x in compile_bad)
    problems += ["syntax error"] if compile_bad else []

    # 2. Import each changed module the way Phase 2 does (scratch scripts are compiled, never imported).
    import_targets = [f for f in source_targets if not is_scratch(f, root)]
    if truthy(opts.get("no_import", False)):
        out.append("IMPORT skipped")
    elif compile_bad:
        out.append("IMPORT skipped (fix the syntax error first)")
    elif import_targets:
        mods = [m for m in (module_for(rel) for rel in import_targets[:8])
                if m and m.split(".")[0] not in ("docs", "docs_src", "examples", "scripts")]
        probe = ("import importlib, sys, traceback\n"
                 "for name in sys.argv[1:]:\n"
                 "    try:\n"
                 "        importlib.import_module(name)\n"
                 "    except BaseException as exc:\n"
                 "        print('IMPORTFAIL %s: %s: %s' % (name, type(exc).__name__, str(exc)[:200]))\n")
        failures = []
        if mods:
            code, so, se = run([sys.executable, "-s", "-c", probe] + mods, root, share(20.0), env)
            failures = [ln[len("IMPORTFAIL "):] for ln in so.splitlines() if ln.startswith("IMPORTFAIL ")]
            missing_top = [f for f in failures if "No module named '%s'" % f.split(":")[0].split(".")[0] in f]
            if missing_top:
                # Not installed as a package (e.g. a top-level script dir): retry from the repository root.
                code, so, se = run([sys.executable, "-s", "-c", probe] + mods, root, share(20.0), dict(env, PYTHONPATH=root))
                failures = [ln[len("IMPORTFAIL "):] for ln in so.splitlines() if ln.startswith("IMPORTFAIL ")]
            if code is None:
                failures.append("import timed out")
        out.append("IMPORT %s (%d module(s))" % ("FAIL" if failures else "ok", len(mods)))
        out.extend("  " + f for f in failures[:6])
        problems += ["import error"] if failures else []
    else:
        out.append("IMPORT skipped (no changed source module)")

    # 3. Reproduction (the same temp dir the shell wrote it to).
    repro = opts.get("repro")
    if repro is None and os.path.isfile(os.path.join(tmp_base(), "repro.py")):
        repro = os.path.join(tmp_base(), "repro.py")
    if repro and repro is not True:
        code, so, se = run([sys.executable, "-s", str(repro)], root, share(15.0), env)
        out.append("REPRO exit=%s (%s)" % (code, repro))
        out.extend("  " + ln for ln in tail(so, 6) + tail(se, 6))
        if code != 0:
            problems.append("repro exits %s" % code)

    # 4. Tests with the Phase 2 flags, whole files, no -x.
    tests = opts.get("tests")
    if tests and tests is not True:
        ids = [t for t in re.split(r"[,\s]+", str(tests)) if t]
        ids = [t[len("/workspace/"):] if t.startswith("/workspace/") else t for t in ids]
        bad = [t for t in ids if not re.match(r"^[\w./\[\]:-]+$", t) or ".." in t.split("/")]
        if bad:
            out.append("TESTS skipped: invalid target(s) %s" % " ".join(bad)[:200])
            problems.append("invalid test ids")
        else:
            try:
                limit = min(float(opts.get("timeout", 60)), 150.0)
            except (TypeError, ValueError):
                limit = 60.0
            limit = max(5.0, min(limit, left() - 5))
            cmd = [sys.executable, "-s", "-m", "pytest", *ids, "-q", "-p", "no:anyio", "-p", "no:cacheprovider",
                   "-o", "timeout=0", "-o", "python_classes=Test* *Test", "--tb=short", "-rfE"]
            code, so, se = run(cmd, root, limit, env)
            if code == 1 and "No module named pytest" in se:
                code = "no-pytest"
            meaning = {0: "PASS", 1: "FAIL (tests failed)", 2: "INTERRUPTED (collection error?)", 3: "INTERNAL ERROR",
                       4: "USAGE ERROR (bad path or node id)", 5: "NO TESTS COLLECTED",
                       None: "TIMEOUT after %.0fs (raise --timeout up to 150 if time allows, or pass fewer files)" % limit,
                       "no-pytest": "ERROR (pytest is not importable by %s)" % sys.executable}.get(code, "exit %s" % code)
            counts = pytest_summary(so)
            out.append("TESTS %s%s: %s" % (meaning, " [%s]" % counts if counts else "", " ".join(ids)[:300]))
            text = so + "\n" + se
            errors = [ln.strip() for ln in text.splitlines() if ln.startswith("E ")][:6]
            out.extend("  " + ln[:170] for ln in errors)
            out.extend("  " + ln for ln in tail(so, 14 if code else 3))
            if code != 0:
                problems.append("tests not passing" if code is not None else "tests timed out")
            if any("::" in t for t in ids):
                warnings.append("node ids cover only part of a file; grading runs whole test files, so pass the file paths")
    else:
        out.append("TESTS none given (pass --tests with the test files tests.py lists)")

    # 5. Hygiene.
    diff = git(root, "diff", base)
    numstat = git(root, "diff", "--numstat", base)
    stat = git(root, "diff", "--stat", base)
    protected = sorted({f for f in changed + untracked if PROTECTED.search(f)})
    leftovers = [u for u in untracked if not PROTECTED.search(u)]
    scratch = [u for u in leftovers if is_scratch(u, root)]
    debug, current = [], None
    for ln in diff.splitlines():
        if ln.startswith("+++ "):
            current = ln[6:] if ln.startswith("+++ b/") else None
            continue
        if current and DEBUG.search(ln) and not DEBUG_SKIP.match(current) and not PROTECTED.search(current):
            debug.append("%s: %s" % (current, ln[1:].strip()[:100]))
    binary = [ln.split("\t")[-1] for ln in numstat.splitlines() if ln.startswith("-\t-\t")]
    source_changed = [f for f in changed if not PROTECTED.search(f)] + [u for u in leftovers if u not in scratch]
    out.append("HYGIENE base=%s" % base)
    if removed:
        out.append("  removed harness temp file(s): %s" % ", ".join(removed))
    if leftovers:
        out.append("  untracked file(s) that WILL be in the patch: %s" % ", ".join(leftovers[:12]))
    if scratch:
        out.append("  delete scratch file(s) before submit_patch: rm %s" % " ".join(scratch[:12]))
        problems.append("scratch files in /workspace")
    if protected:
        out.append("  protected test/config edits (stripped before grading, so they cannot help): %s" % ", ".join(protected[:10]))
        if any(p.endswith(("pytest.ini", "conftest.py")) for p in protected):
            problems.append("harness pytest.ini/conftest.py modified")
    if debug:
        warnings.append("debug output added to library code; remove it unless the task needs it: %s" % " | ".join(debug[:4]))
    if binary:
        out.append("  binary change(s): %s" % ", ".join(binary[:5]))
        problems.append("binary files in diff")
    if not source_changed:
        out.append("  no source change yet: the patch would be empty")
        problems.append("empty patch")
    out.extend("  " + ln for ln in tail(stat, 8))
    out.extend("WARN " + w for w in warnings)

    out.append("Gate (from analysis-qa-checklist): the change answers the task title; the repro now shows the expected "
               "behaviour; edge cases named in the task are covered; public API stays compatible; diff is minimal.")
    if problems:
        out.append("NOT READY: " + "; ".join(dict.fromkeys(problems)))
    elif not (tests and tests is not True) and not (repro and repro is not True):
        out.append("READY (unverified: no repro or tests were run): run the closest tests if time allows, "
                   "then call submit_patch.")
    else:
        out.append("READY%s: call submit_patch now (it is free) and then reply with a one-sentence summary." % (
            " (check the WARN lines first)" if warnings else ""))
    out.append("(%.1fs)" % (time.time() - started))
    text, used = [], 0
    for line in out:
        if used + len(line) + 1 > OUTPUT_CAP:
            text.append("... [output truncated]")
            break
        text.append(line)
        used += len(line) + 1
    print("\n".join(text))
    return 0  # the verdict is in the text; exit 0 keeps it in stdout


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except Exception as exc:
        print("check error: %s: %s" % (type(exc).__name__, str(exc)[:300]))
        sys.exit(1)
