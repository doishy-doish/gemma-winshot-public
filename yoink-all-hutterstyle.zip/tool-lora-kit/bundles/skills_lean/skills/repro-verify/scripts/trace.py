#!/usr/bin/env python3
"""trace: run a reproduction and list the repository functions it executes.

  --script /tmp/repro.py   run a script (write it with a shell heredoc under /tmp)
  -c / --code "CODE"       or run a short code string
  --timeout S              child time limit in seconds (default 20, max 60)
  --max N                  functions to list (default 60)
  --root DIR               repository root (default: the git checkout, usually /workspace)

The reproduction runs in a child Python process with PYTHONSAFEPATH=1 and
PYTHONNOUSERSITE=1 (as in Phase 2 grading), cwd set to the repository. Python
3.12+ uses sys.monitoring (PY_START and RAISE events, disabled per code object
outside the repository, so it stays fast); older versions fall back to
sys.setprofile. Coroutines and threads are covered, so async FastAPI handlers
and TestClient calls show up. Output: repository functions in first-call
order with call counts, exceptions raised inside the repository (handled or
not), the uncaught traceback, and the tail of the repro output. Nothing is
written under the repository; one temporary JSON file in the temp directory is
deleted afterwards. Output stays under the 5,000-character command cap.
"""
import json
import os
import re
import signal
import subprocess
import sys
import tempfile
import time

OUTPUT_CAP = 4500

CHILD = r"""
import json, os, sys, threading, time, traceback, runpy
root, kind, target, out_path, soft = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], float(sys.argv[5])
prefix = os.path.realpath(root) + os.sep
calls, raised, order = {}, [], [0]
lock = threading.Lock()
def note(code):
    filename = code.co_filename
    if not filename.startswith(prefix):
        return False
    key = (filename[len(prefix):], getattr(code, "co_qualname", code.co_name), code.co_firstlineno)
    with lock:
        entry = calls.get(key)
        if entry is None:
            calls[key] = [order[0], 1]
            order[0] += 1
        else:
            entry[1] += 1
    return True
def dump(status, tb=None):
    data = {"status": status, "tb": tb,
            "calls": sorted(([k[0], k[1], k[2], v[0], v[1]] for k, v in list(calls.items())), key=lambda r: r[3]),
            "raised": raised[:40], "elapsed": time.time() - started,
            "engine": engine}
    with open(out_path, "w") as handle:
        json.dump(data, handle)
engine = "setprofile"
mon = getattr(sys, "monitoring", None)
tool = None
if mon is not None:
    for candidate in (mon.PROFILER_ID, mon.OPTIMIZER_ID, 4, 3):
        try:
            mon.use_tool_id(candidate, "swe-trace")
            tool = candidate
            break
        except (ValueError, Exception):
            continue
if tool is not None:
    engine = "sys.monitoring"
    E = mon.events
    def on_start(code, offset):
        if not note(code):
            return mon.DISABLE
    def on_raise(code, offset, exc):
        filename = code.co_filename
        if filename.startswith(prefix) and len(raised) < 40:
            raised.append([filename[len(prefix):], getattr(code, "co_qualname", code.co_name),
                           code.co_firstlineno, type(exc).__name__, str(exc)[:160]])
    mon.register_callback(tool, E.PY_START, on_start)
    mon.register_callback(tool, E.RAISE, on_raise)
    mon.set_events(tool, E.PY_START | E.RAISE)
else:
    def profiler(frame, event, arg):
        if event == "call":
            note(frame.f_code)
    sys.setprofile(profiler)
    threading.setprofile(profiler)
def stop():
    if tool is not None:
        mon.set_events(tool, 0)
        mon.free_tool_id(tool)
    else:
        sys.setprofile(None)
        threading.setprofile(None)
def soft_deadline():
    try:
        stop()
        dump("timeout")
    finally:
        os._exit(124)
timer = threading.Timer(soft, soft_deadline)
timer.daemon = True
started = time.time()
timer.start()
status, tb = "ok", None
try:
    if kind == "script":
        sys.argv = [target]
        runpy.run_path(target, run_name="__main__")
    else:
        sys.argv = ["-c"]
        exec(compile(target, "<repro>", "exec"), {"__name__": "__main__"})
except SystemExit as exc:
    code = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
    status = "exit %d" % code
except BaseException as exc:
    status = "uncaught %s" % type(exc).__name__
    frames = traceback.extract_tb(exc.__traceback__)
    keep = [f for f in frames if f.filename.startswith(prefix) or f.filename in ("<repro>", target)]
    tb = ["%s:%d in %s: %s" % (f.filename[len(prefix):] if f.filename.startswith(prefix) else f.filename,
                               f.lineno, f.name, (f.line or "").strip()[:100]) for f in keep[-12:]]
    tb.append("%s: %s" % (type(exc).__name__, str(exc)[:300]))
timer.cancel()
stop()
dump(status, tb)
"""


def norm_key(key):
    return key.strip().lstrip("-").replace("-", "_").lower()


def parse_argv(argv):
    opts = {}
    if len(argv) == 1 and argv[0].strip().startswith("{"):
        try:
            obj = json.loads(argv[0])
            if isinstance(obj, dict):
                return {norm_key(k): v for k, v in obj.items()}
        except ValueError:
            pass
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":  # run_skill_script puts positional_args after "--"
            rest = [a for a in argv[i + 1:] if a.endswith(".py")]
            if rest and "script" not in opts:
                opts["script"] = rest[0]
            break
        if arg.startswith("-") and len(arg) > 1:
            if "=" in arg and arg.startswith("--"):
                key, val = arg.split("=", 1)
                opts[norm_key(key)] = val
            elif i + 1 < len(argv):
                opts[norm_key(arg)] = argv[i + 1]
                i += 1
        elif re.match(r"^[A-Za-z_][\w-]*=", arg):
            key, val = arg.split("=", 1)
            opts[norm_key(key)] = val
        elif "script" not in opts and arg.endswith(".py"):
            opts["script"] = arg
        i += 1
    return opts


def find_root(explicit=None):
    """An explicit --root, else the first git checkout among SWE_WORKSPACE, cwd, /workspace, PWD, else None."""
    if explicit and os.path.isdir(str(explicit)):
        return os.path.realpath(str(explicit))
    for cand in (os.environ.get("SWE_WORKSPACE"), os.getcwd(), "/workspace", os.environ.get("PWD")):
        if cand and os.path.isdir(os.path.join(cand, ".git")):
            return os.path.realpath(cand)
    return None


def temp_dir(root):
    """The same temp base as check.py: the parent of the install dir (/tmp/swe -> /tmp), else /tmp."""
    here = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else ""
    real = os.path.realpath(os.path.dirname(here) if os.path.basename(here) == "swe" else "/tmp")
    if real == root or real.startswith(root + os.sep) or not os.path.isdir(real):
        real = "/tmp"
    return real


def tail(text, count):
    lines = [ln for ln in (text or "").splitlines() if ln.strip()]
    return lines[-count:]


def main(argv):
    opts = parse_argv(argv)
    code = opts.get("c") or opts.get("code")
    script = opts.get("script") or opts.get("file")
    if not code and not script:
        print("usage: trace.py --script /tmp/repro.py | -c 'CODE' [--timeout 20] [--max 60] [--root DIR]")
        return 2
    root = find_root(opts.get("root"))
    if root is None:
        print("trace: no git checkout found (checked SWE_WORKSPACE, the current directory and /workspace); "
              "pass --root DIR, or run the repro directly with python3 from /workspace.")
        return 2
    try:
        timeout = max(2.0, min(float(opts.get("timeout", 20)), 60.0))
        limit = max(5, min(int(opts.get("max", 60)), 200))
    except (TypeError, ValueError):
        timeout, limit = 20.0, 60
    if script:
        script = os.path.realpath(str(script))
        if not os.path.isfile(script):
            print("trace: script not found: %s (create it under /tmp with a heredoc first)" % script)
            return 2
    fd, out_path = tempfile.mkstemp(prefix="swe_trace_", suffix=".json", dir=temp_dir(root))
    os.close(fd)
    env = dict(os.environ, PYTHONSAFEPATH="1", PYTHONNOUSERSITE="1", PYTHONDONTWRITEBYTECODE="1")
    cmd = [sys.executable, "-s", "-c", CHILD, root, "script" if script else "code", script or str(code),
           out_path, str(timeout)]
    started = time.time()
    status_note = ""
    try:
        proc = subprocess.Popen(cmd, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                stdin=subprocess.DEVNULL, start_new_session=True)
        try:
            stdout, stderr = proc.communicate(timeout=timeout + 5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except OSError:
                proc.kill()
            stdout, stderr = proc.communicate()
            status_note = " (killed after %.0fs)" % (timeout + 5)
        try:
            with open(out_path) as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            data = {"status": "no trace data (child exit %s)" % proc.returncode, "calls": [], "raised": [], "tb": None,
                    "engine": "?", "elapsed": time.time() - started}
    finally:
        try:
            os.unlink(out_path)
        except OSError:
            pass
    out = []
    calls = data.get("calls") or []
    out.append("TRACE status=%s%s child_exit=%s time=%.1fs engine=%s; %d repository function(s) executed" % (
        data.get("status"), status_note, proc.returncode, data.get("elapsed", 0.0), data.get("engine"), len(calls)))
    if calls:
        out.append("First-call order (path:line  qualified name  xcalls):")
        for rel, qual, line, _order, count in calls[:limit]:
            tag = "  [test]" if re.search(r"(^|/)(tests?|testing)/|(^|/)test_[^/]*\.py$", rel) else ""
            out.append("  %s:%d  %s  x%d%s" % (rel, line, qual, count, tag))
        if len(calls) > limit:
            out.append("  ... %d more" % (len(calls) - limit))
    raised = data.get("raised") or []
    if raised:
        out.append("Raised inside the repository (handled or not):")
        seen = set()
        for rel, qual, line, exc_type, message in raised:
            key = (rel, qual, exc_type)
            if key in seen:
                continue
            seen.add(key)
            out.append("  %s:%d  %s -> %s: %s" % (rel, line, qual, exc_type, message[:120]))
            if len(seen) >= 8:
                break
    if data.get("tb"):
        out.append("Uncaught (repository and repro frames):")
        out.extend("  " + ln for ln in data["tb"])
    so, se = tail(stdout.decode("utf-8", "replace"), 12), tail(stderr.decode("utf-8", "replace"), 8)
    if so:
        out.append("repro stdout (tail):")
        out.extend("  " + ln[:160] for ln in so)
    if se and not data.get("tb"):
        out.append("repro stderr (tail):")
        out.extend("  " + ln[:160] for ln in se)
    if not calls:
        out.append("No repository function ran: the repro may not import the package from this checkout.")
    else:
        out.append("Edit a function on this executed path, then trace again to confirm the change.")
    text, used = [], 0
    for line in out:
        if used + len(line) + 1 > OUTPUT_CAP:
            text.append("... [output truncated]")
            break
        text.append(line)
        used += len(line) + 1
    print("\n".join(text))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except Exception as exc:
        print("trace error: %s: %s" % (type(exc).__name__, str(exc)[:300]))
        sys.exit(1)
