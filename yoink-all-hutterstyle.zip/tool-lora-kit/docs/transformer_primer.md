# How the LoRA adapter changes Gemma 4: tokens, embeddings and attention

The classic Transformer, as described in *Attention Is All You Need* (Vaswani et al., 2017), works like this:

- subword tokens are embedded into vectors;
- sinusoidal positional encodings are added to those vectors;
- each layer applies scaled dot-product self-attention, softmax(QKᵀ/√d_k)·V, across many heads;
- residual connections and LayerNorm wrap each sub-layer;
- the model is pre-trained with an objective such as causal (next-token) language modelling.

This page maps that picture onto the model this dataset's adapters target, **Gemma 4 31B** (`google/gemma-4-31b-it-qat-w4a16-ct`). It also explains what the adapters change. Every number below comes from the checkpoint's own `config.json`, `tokenizer.json` and `transformers` 5.17 `modeling_gemma4.py`. These were read on 2026-10-17.

## 1. Where Gemma 4 differs from the 2017 description

| Concept | Classic Transformer | Gemma 4 31B | Why it matters for this agent |
|---|---|---|---|
| Tokenizer | WordPiece / BPE | **BPE with byte fallback**: 262,144 tokens, 514,906 merges, SentencePiece-style `▁` space marker | Code identifiers split into many pieces (see §3) |
| Token embeddings | Learned table | 5,376-dim, **tied** with the output head | LoRA leaves embeddings frozen, so no new tokens are learned |
| Position information | Sinusoidal encodings added to the input | **RoPE** (rotary) inside attention. Sliding layers use θ = 10⁴. Global layers use θ = 10⁶ "proportional" and rotate only 25% of each head's dims | Long contexts (32k in the harness) stay usable |
| Attention span | Every layer sees the whole sequence | **50 of 60 layers use a 1,024-token sliding window**. Only 10 layers (every 6th, starting at layer 5) attend over the full context | See §4: what the agent can still "see" late in a long run |
| Heads | Multi-head, one K/V per head | 32 query heads with **grouped-query attention**: 16 K/V heads (head_dim 256) in sliding layers, 4 K/V heads (head_dim 512) in global layers. Global layers have **K = V** (`attention_k_eq_v`), so they have no `v_proj` | The adapter has 410 targets, not 420 |
| Normalisation | LayerNorm | **RMSNorm** (eps 1e-6), applied before and after each sub-layer | No effect on the adapter (norms are frozen) |
| Feed-forward | ReLU MLP | **GeGLU** (`gelu_pytorch_tanh`): 5,376 → 21,504 → 5,376 through `gate_proj`, `up_proj`, `down_proj` | The adapter adapts all three projections |
| Output | Softmax over the vocabulary | Logits soft-capped at 30.0 before the softmax | Training uses a chunked cross-entropy, because full logits at 16k tokens would need about 43 GB |
| Pre-training | MLM, causal or encoder-decoder | **Causal LM** (decoder-only). The vision tower uses bidirectional attention but is unused here | The fine-tune keeps the same next-token objective |

## 2. What the LoRA adapter actually trains

LoRA freezes every original weight W and learns a low-rank update ΔW = (α/r)·B·A, with r = 16 and α = 32. The update sits on these projections in each of the 60 language-model layers:

- **`q_proj`, `k_proj`, `v_proj`** reshape which tokens attend to which. For example, a tool response that contains a symbol id can draw more attention from the step that writes the next call. Full-attention layers have no `v_proj` (K = V).
- **`o_proj`** recombines the heads.
- **`gate_proj`, `up_proj`, `down_proj`** adjust the per-token transformation in the MLP.

That gives 50 × 7 + 10 × 6 = **410 adapted projections**, 122.4 M trainable parameters and about 234 MiB in bf16. The base model, its embeddings and its knowledge stay unchanged. The adapter shifts **behaviour**: which tool to call, with which arguments, and when to stop.

The loss is the same next-token (causal LM) objective used in pre-training, but applied only to the assistant's own tokens: its reasoning, its tool calls and its final message. Tool outputs, the system prompt and the task text are masked out. The model is never trained to "predict" a file it read or a test log.

## 3. Tokens and exact symbol ids

The graph tools need an exact dotted symbol id. Here is how a few ids and commands tokenize (Gemma 4 tokenizer, measured):

| Text | Tokens |
|---|---|
| `fastapi.routing.get_request_handler` | 10: `fast` `api` `.` `routing` `.` `get` `_` `request` `_` `handler` |
| `rich.console.Console.print` | 7 |
| `tests.test_tutorial.test_main` | 9 |
| `git grep -n "def get_request_handler"` | 12: … `def` `▁get` `_` `request` `_` `handler` … |

The same identifier begins with **`get`** inside a dotted id but with **`▁get`** (with the space marker) after `def ` in grep output. Turning a grep hit into a graph query is therefore not a literal token copy. The model has to rebuild `module.path` from the file path and append the qualified name. The training data teaches exactly this step: the "required graph step" trajectories, rendered under the shipping prompt.

## 4. Why the adapter is taught to restate symbols close to where it uses them

Only 10 of the 60 layers can attend beyond the last 1,024 tokens. A typical agent run in this competition fills 8k–16k tokens before its edit, and the harness compacts history at 14,336 tokens. A symbol id printed by an early `git grep` is therefore reachable only through those 10 global layers by the time the agent writes its patch. The effects on training:

- **Selection favours trajectories where the agent carries the exact id forward**, in its reasoning or in the next call's arguments, so the id stays within the local window.
- **One graph call per task** keeps the context short: every tool output costs up to 5,000 characters, roughly 1,200–1,500 tokens.

## 5. The two different "embeddings"

| | LLM token embeddings | Competition code embeddings (`embeddings/*.npz`) |
|---|---|---|
| What | Gemma 4's 262,144 × 5,376 input table | One 256-dim vector per code symbol (function, method or class) per commit |
| Produced by | Gemma 4 pre-training | A separate, undocumented encoder |
| Used by | Every forward pass | Only the `search_similar_code` tool, by cosine similarity |
| Queried with | Tokens | A **symbol name**. Free text is not embedded at inference, and multi-word queries fall back to lexical matching |
| Adapter's effect | None (frozen) | None. The adapter only learns **when and how** to call the tool (exact id, k = 3–5) |

The code embeddings are strongly anisotropic: random symbol pairs have a cosine similarity of about 0.83–0.94. Their *ranking* carries some signal, but raw similarity values near 0.9 carry little. The shipped prompt and the training data treat them as rank-only.

## 6. Where to look next

- Adapter format, rank and serving flags: `examples/` (vLLM + LoRA) and the recipe `gemma4_31b_peft_recipe.md`.
- Multi-agent use, with different adapters per agent in one ADK hierarchy: `examples/` (the ADK multi-agent example).
