"""Build a CPU submission notebook that writes /kaggle/working/submission.zip from an embedded bundle.
Usage: make_submit_nb.py <bundle.json> <bundle_name> <out_dir> <kernel_slug>"""
import json, sys
from pathlib import Path

bundle_path, bundle_name, out_dir, slug = sys.argv[1:5]
bundle = json.load(open(bundle_path))
out = Path(out_dir)
out.mkdir(parents=True, exist_ok=True)
code = '''import hashlib, json, zipfile
from pathlib import Path

BUNDLE_NAME = %r
BUNDLE = json.loads(%r)
WORK = Path("/kaggle/working") if Path("/kaggle/working").exists() else Path("kaggle_working")
ALLOWED = {".yaml", ".yml", ".md", ".txt", ".py", ".json", ".safetensors"}
stage = WORK / "submission_bundle"
for rel, text in BUNDLE.items():
    p = stage / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)
files = sorted(p for p in stage.rglob("*") if p.is_file())
assert (stage / "agent.yaml").is_file() and all(p.suffix in ALLOWED for p in files)
models = {l.split(":", 1)[1].strip() for p in files if p.suffix in (".yaml", ".yml") for l in p.read_text().splitlines() if l.strip().startswith("model:")}
assert models == {"gemma-4-31b-it-qat-w4a16-ct"}, models
zp = WORK / "submission.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for p in files:
        zi = zipfile.ZipInfo(p.relative_to(stage).as_posix(), date_time=(2026, 1, 1, 0, 0, 0))
        zi.compress_type, zi.external_attr = zipfile.ZIP_DEFLATED, 0o644 << 16
        z.writestr(zi, p.read_bytes())
with zipfile.ZipFile(zp) as z:
    names = z.namelist()
    assert z.testzip() is None and "agent.yaml" in names and not any(n.endswith("/") for n in names)
print(BUNDLE_NAME, names, hashlib.sha256(zp.read_bytes()).hexdigest()[:16])
print((stage / "agent.yaml").read_text())
''' % (bundle_name, json.dumps(bundle))
nb = {"cells": [{"cell_type": "markdown", "id": "m0", "metadata": {}, "source": f"# Gemma 4 Developer Agent: submission ({bundle_name})\nWrites `/kaggle/working/submission.zip` for the bundle `{bundle_name}`."},
                {"cell_type": "code", "id": "c0", "metadata": {}, "execution_count": None, "outputs": [], "source": code}],
      "metadata": {"kernelspec": {"name": "python3", "display_name": "Python 3", "language": "python"}, "language_info": {"name": "python"}},
      "nbformat": 4, "nbformat_minor": 5}
name = slug.split("/")[1]
(out / f"{name}.ipynb").write_text(json.dumps(nb))
(out / "kernel-metadata.json").write_text(json.dumps({
    "id": slug, "title": name, "code_file": f"{name}.ipynb", "language": "python", "kernel_type": "notebook", "is_private": True,
    "enable_gpu": False, "enable_tpu": False, "enable_internet": False, "dataset_sources": [], "competition_sources": ["gemma-4-developer-agent"],
    "kernel_sources": [], "model_sources": []}, indent=1))
print(out, name)
