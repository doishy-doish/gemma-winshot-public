"""Rejection sampling for the tool-use LoRA (recipe section 2: Data).

Runs the A1 bundle in the real swegemma harness on the competition's 4x L4 setup and records every
model call through a logging proxy, so the training script sees the exact request (messages + tools)
and the exact response (reasoning + tool calls) that vLLM served.

Runs, in order, while the time guard allows:
  train_s0, train_s1 : repo-train fold (fastapi + requests + httpx, 81 tasks), T=0.7  -> training data
  val_base           : repo-val fold (rich, 48 tasks), shipped A1 sampling (T=0.2)    -> baseline
"""
import glob, importlib, json, logging, os, re, shutil, subprocess, sys, threading, time, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

T0 = time.time()
TIME_LIMIT_H = float(os.environ.get("TIME_LIMIT_H", "10.5"))
CONCURRENCY = int(os.environ.get("CONCURRENCY", "2"))
for k, v in {
    "TRANSFORMERS_NO_TF": "1", "TRANSFORMERS_NO_FLAX": "1", "TRANSFORMERS_OFFLINE": "1", "VLLM_NO_USAGE_STATS": "1",
    "VLLM_WORKER_MULTIPROC_METHOD": "spawn", "VLLM_ENGINE_READY_TIMEOUT_S": "1800", "NCCL_DEBUG": "WARN",
    "LITELLM_LOCAL_MODEL_COST_MAP": "True", "LITELLM_TELEMETRY": "False", "LITELLM_LOG": "WARNING",
    "OPENAI_API_KEY": "EMPTY", "LOCAL_API_KEY": "EMPTY", "PYTORCH_CUDA_ALLOC_CONF": "expandable_segments:True",
    "OTEL_SDK_DISABLED": "true", "OTEL_PYTHON_DISABLED": "true",
}.items():
    os.environ.setdefault(k, v)


def log(*a):
    print(f"[{(time.time() - T0) / 60:6.1f} min]", *a, flush=True)


def first(*cands):
    return next((Path(c) for c in cands if Path(c).exists()), None)


WHEELHOUSE = first("/kaggle/input/datasets/metric/gemma-4-developer-agent-wheelhouse", "/kaggle/input/gemma-4-developer-agent-wheelhouse")
DATA_DIR = first("/kaggle/input/competitions/gemma-4-developer-agent", "/kaggle/input/gemma-4-developer-agent")
MODEL_PATH = first("/kaggle/input/models/google/gemma-4/other/gemma-4-31b-it-qat-w4a16-ct/2",
                   *glob.glob("/kaggle/input/**/gemma-4-31b-it-qat-w4a16-ct/2", recursive=True))
WORK = Path("/kaggle/working")
log("wheelhouse", WHEELHOUSE, "| data", DATA_DIR, "| model", MODEL_PATH)
log(subprocess.run("nvidia-smi --query-gpu=name,memory.total --format=csv,noheader", shell=True, capture_output=True, text=True).stdout.strip())
log("cpus", os.cpu_count())

for pth in glob.glob("/usr/local/lib/python*/dist-packages/*cutlass*.pth"):
    try:
        os.unlink(pth)
    except OSError:
        pass
tmp = Path("/tmp/wheelhouse")
tmp.mkdir(exist_ok=True)
for w in WHEELHOUSE.glob("*.whl"):
    if "cutlass" in w.name.lower():
        continue
    t = tmp / (w.name.replace("cu128", "+cu128") if ("cu128" in w.name and "+" not in w.name) else w.name)
    if not t.exists():
        os.symlink(w, t)
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--no-deps", "--force-reinstall", *sorted(map(str, tmp.glob("*.whl")))], check=True)
importlib.invalidate_caches()
log("wheelhouse installed")

for name in ("LiteLLM", "LiteLLM Router", "litellm", "httpx", "httpcore", "openai", "urllib3"):
    logging.getLogger(name).setLevel(logging.WARNING)

import asyncio
import torch
import yaml
import litellm
from adk_submission import VllmConfig, VllmServer, discover_adapters
from google.adk.agents.context_cache_config import ContextCacheConfig
from google.adk.apps._configs import EventsCompactionConfig
from swegemma.config import ALLOWED_ADAPTER_EXTENSIONS, EvalConfig, build_submission_limits
from swegemma.evaluate import Evaluator
from swegemma.models import load_tasks

litellm.drop_params = True

# ---------------------------------------------------------------- bundle A1
A1 = json.loads('{"agent.yaml": "name: swe_tool_selection_agent\\nmodel: gemma-4-31b-it-qat-w4a16-ct\\ninstruction: !include prompts/system.md\\ntools:\\n  - run_command\\n  - read_file\\n  - edit_file\\n  - write_file\\n  - get_status\\n  - submit_patch\\n  - get_code_neighbors\\n  - search_similar_code\\n  - get_code_subgraph\\ngenerate_content_config: !include configs/sampling.yaml\\n", "configs/sampling.yaml": "temperature: 0.2\\ntop_p: 0.95\\nmax_output_tokens: 8192\\nthinking_config:\\n  thinking_budget: 4096\\n  include_thoughts: true\\n", "eval_config.yaml": "# Generation budgets: the community \\"Budget-Fit\\" settings (8 min, 28 calls, 240 s) plus 4 calls of headroom for\\n# graph tools, since this bundle is designed to exercise them.\\nevaluation:\\n  timeout_seconds: 240\\n  max_tool_calls: 32\\n  max_time_minutes: 8\\n  max_turns: 80\\n", "prompts/system.md": "You are an expert software engineer resolving one task in the repository at `/workspace`. Work quickly and precisely, then submit a minimal source-code patch.\\n\\n## Read the task correctly\\nThe first line of the task is usually the **pull-request title**. It names the change to make, for example \\"Fix parsing extra non-body parameter list\\". Treat it as the specification. Pull out its identifiers (backticked names, function, class, module and file names, error strings) and search for those first.\\n\\n## Choose the right tool for each step\\n\\n| Need | Tool | How |\\n|---|---|---|\\n| Find where an identifier or string lives | `run_command` | `git grep -n` on the identifier (exact command below). This is always the first step. If nothing matches, grep distinctive words from the title (error text, option or parameter names). |\\n| See a file\'s outline before reading it | `run_command` | `grep -n \\"def \\\\|class \\" <file>` |\\n| Read code | `read_file` | 60\\u201380-line windows around the grep hit. Never read whole large files. |\\n| Who calls a function, what it calls, or near-duplicate siblings | `get_code_neighbors` | `node` must be an **exact dotted id** copied from code you have seen, e.g. `fastapi.routing.get_request_handler` or `rich.console.Console.print`. The neighbour list has **no direction**: callers and callees are mixed. |\\n| Read a symbol\'s body without knowing its file, or find near-duplicate siblings | `search_similar_code` | `query` must be a dotted id or `Class.method`, never a sentence. Use `k` 2 for FastAPI, 3 elsewhere. Similarity scores near 0.9 carry little meaning, so rank only. |\\n| Check whether 3\\u20138 candidate symbols are connected | `get_code_subgraph` | Pass the exact dotted ids as a list |\\n| Find the existing tests for a function | `run_command` | `git grep -ln` on the function name under `tests/` (exact command below) |\\n| Check remaining budget | `get_status` | Free; use it when unsure how many calls remain |\\n\\nExact search commands (the `|| true` keeps \\"no match\\" from looking like an error):\\n```\\ngit grep -n \\"<identifier>\\" -- \'*.py\' | head -n 40 || true\\ngit grep -ln \\"<function name>\\" -- \'tests/*.py\' | head -n 10 || true\\n```\\n\\n### Graph tool rules\\n- Use a graph tool only **after** you have a concrete symbol id from grep or `read_file` output. Never query the graph with prose or bare short names like `app`, `send` or `__init__`; they resolve to an arbitrary node.\\n- Dotted ids are the module path plus the class chain and the name: `package.module.Class.method`. Test functions look like `tests.test_module.test_name`. FastAPI tutorial files under `docs_src/` appear as top-level modules, such as `dependencies.tutorial008d_an_py310.main`.\\n- The graph does **not** contain `async def` functions, module-level constants, or files that do not exist yet. For these, use `git grep` and `read_file` instead.\\n- Spend at most 3 graph calls per task. If a graph call returns an error or an unrelated node, do not retry it with variations. Fall back to `git grep`.\\n\\n## Workflow\\n1. **Localize** with `git grep` on the title\'s identifiers, then read the relevant window.\\n2. **Expand** only if needed: one graph call on the target symbol for callers or siblings that may need the same change.\\n3. **Edit early.** Make the first `edit_file` change by about tool call 12. Keep `old_string` short and unique, and change only what the task needs.\\n4. **Verify the whole test file.** The grader runs entire test files, so a failure anywhere in the file for the module you changed counts against you. Run it the way the grader does: `python -m pytest tests/test_x.py -q -p no:anyio -o timeout=0`. If a test in that file fails because of your change, fix the code or revert. Never run bare `pytest` or the whole suite.\\n5. **Submit.** Call `submit_patch`, check that `files_changed > 0`, and finish with a one-sentence summary.\\n\\n## Rules\\n- Never create, modify or delete test files (`test_*.py`, `*_test.py`, `tests/`, `conftest.py`) or config files (`pytest.ini`, `pyproject.toml`, `setup.cfg`, `tox.ini`). Those edits are discarded before grading.\\n- `write_file` and `edit_file` work only inside `/workspace`. Create scratch files only with a `run_command` heredoc under `/tmp` (for example `cat > /tmp/repro.py <<\'PY\'` \\u2026 `PY`, then `cd /tmp && python repro.py`), so they never enter the patch.\\n- The environment is offline and all dependencies are installed. Do not run pip.\\n- Do not search outside `/workspace`.\\n- Pre-existing unrelated test failures in other files are expected. Ignore them.\\n- Never finish without a non-empty patch. If time is running out, submit your best partial fix.\\n\\n## Graph decision (write it before your first edit)\\nBefore your first `edit_file`, write exactly one line in your visible reply, in one of these forms:\\n- `GRAPH: call get_code_neighbors <exact dotted id> | callers`\\n- `GRAPH: call search_similar_code <exact dotted id> | siblings`\\n- `GRAPH: skip | <short reason>`\\n\\nWrite `call` only when the function or method you will change is a plain `def` that you located with `git grep` (not `async def`, not module-level code, not a new file), you still need cross-file information (who calls it, or near-duplicate siblings that may need the same change), and at least 10 tool calls remain. Otherwise write `skip` with the reason, for example `GRAPH: skip | async function, not in the graph` or `GRAPH: skip | single-file fix, nothing cross-file`.\\nAfter a `call` line, make that one call next: `get_code_neighbors` with `max_neighbors` 20, or `search_similar_code` with `k` 2 for FastAPI and 3 elsewhere. Then read the most relevant returned caller or sibling before you edit. Build the dotted id from the file path and the qualified name: `rich/text.py` + `Text.wrap` \\u2192 `rich.text.Text.wrap`.\\n"}')


GRAPH_FIRST = json.loads('{"agent.yaml": "name: swe_tool_selection_agent\\nmodel: gemma-4-31b-it-qat-w4a16-ct\\ninstruction: !include prompts/system.md\\ntools:\\n  - run_command\\n  - read_file\\n  - edit_file\\n  - write_file\\n  - get_status\\n  - submit_patch\\n  - get_code_neighbors\\n  - search_similar_code\\n  - get_code_subgraph\\ngenerate_content_config: !include configs/sampling.yaml\\n", "configs/sampling.yaml": "temperature: 0.2\\ntop_p: 0.95\\nmax_output_tokens: 4096\\nthinking_config:\\n  thinking_budget: 2048\\n  include_thoughts: true\\n", "eval_config.yaml": "# A1 budgets (8 min, 32 calls, 80 turns, 240 s per command)\\nevaluation:\\n  timeout_seconds: 240\\n  max_tool_calls: 32\\n  max_time_minutes: 8\\n  max_turns: 80\\n", "prompts/system.md": "You are an expert software engineer resolving one task in the repository at `/workspace`. Work quickly and precisely, then submit a minimal source-code patch.\\n\\n## Read the task correctly\\nThe first line of the task is usually the **pull-request title**. It names the change to make, for example \\"Fix parsing extra non-body parameter list\\". Treat it as the specification. Pull out its identifiers (backticked names, function, class, module and file names, error strings) and search for those first.\\n\\n## Use the code graph to cut file reading\\nThe repository comes with a pre-computed code graph and node embeddings. One graph call returns the code of several related symbols at once (siblings that often need the same change, or implement the same pattern), which replaces several `read_file` calls on other files. Use it to save time.\\n\\n| Need | Tool | How |\\n|---|---|---|\\n| Find where an identifier or string lives | `run_command` | `git grep -n` on the identifier (exact command below). Always the first call. |\\n| Read the target\'s code | `read_file` | one 60\\u201380-line window around the grep hit |\\n| See the code of the target\'s closest relatives without opening their files | `search_similar_code` | `query` = the exact dotted id, e.g. `rich.text.Text.wrap` (file path + qualified name), `k` 3. Results are other symbols (with their code), never the query itself. |\\n| Who calls the function you will change (callers may need the same fix) | `get_code_neighbors` | `node` = exact dotted id, `max_neighbors` 20. Callers and callees are mixed. |\\n| Check whether 3\\u20138 candidate symbols are connected | `get_code_subgraph` | exact dotted ids as a list |\\n| Find the tests for a function | `run_command` | `git grep -ln` on the function name under `tests/` (exact command below) |\\n| Check remaining budget | `get_status` | free |\\n\\nExact search commands (the `|| true` keeps \\"no match\\" from looking like an error):\\n```\\ngit grep -n \\"<identifier>\\" -- \'*.py\' | head -n 40 || true\\ngit grep -ln \\"<function name>\\" -- \'tests/*.py\' | head -n 10 || true\\n```\\n\\nDotted ids: module path + class chain + name (`rich/text.py` + `Text.wrap` -> `rich.text.Text.wrap`; tests look like `tests.test_text.test_wrap`; FastAPI `docs_src/` files are top-level modules). Never query the graph with prose or bare short names such as `app` or `__init__`. If a graph call returns an error, an empty list or an unrelated symbol, do not retry it; use `read_file`.\\n\\n## Workflow (aim to finish in about 15 tool calls)\\n1. **Localize:** one `git grep` on the title\'s identifiers.\\n2. **Read:** one `read_file` window on the best hit. Then, for a plain `def` (the graph has no `async def`, module constants or new files), one graph call instead of opening more files: `get_code_neighbors` if callers may need the same change, or `search_similar_code` if sibling implementations may.\\n3. **Edit early:** make the first `edit_file` change by tool call 8. Keep `old_string` short and unique.\\n4. **Verify the whole test file** the way the grader does: `python -m pytest tests/test_x.py -q -p no:anyio -o timeout=0`. Fix or revert if your change breaks it. Never run bare `pytest`.\\n5. **Submit:** call `submit_patch`, check `files_changed > 0`, and finish with one sentence.\\n\\nKeep your reasoning short: decide, call the tool, move on.\\n\\n## Rules\\n- Never create, modify or delete test files (`test_*.py`, `*_test.py`, `tests/`, `conftest.py`) or config files (`pytest.ini`, `pyproject.toml`, `setup.cfg`, `tox.ini`). Those edits are discarded before grading.\\n- `write_file` and `edit_file` work only inside `/workspace`. Create scratch files only with a `run_command` heredoc under `/tmp` (for example `cat > /tmp/repro.py <<\'PY\'` \\u2026 `PY`, then `cd /tmp && python repro.py`), so they never enter the patch.\\n- The environment is offline and all dependencies are installed. Do not run pip.\\n- Do not search outside `/workspace`.\\n- Pre-existing unrelated test failures in other files are expected. Ignore them.\\n- Never finish without a non-empty patch. If time is running out, submit your best partial fix.\\n"}')


def write_bundle(dst: Path, temperature: float) -> Path:
    shutil.rmtree(dst, ignore_errors=True)
    for rel, text in (GRAPH_FIRST if "graph" in dst.name else A1).items():
        p = dst / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        if rel == "configs/sampling.yaml":
            text = re.sub(r"^temperature:.*$", f"temperature: {temperature}", text, flags=re.M)

        p.write_text(text)
    return dst


# ---------------------------------------------------------------- logging proxy
VLLM_PORT, PROXY_PORT = 8001, 8000
CALLS = WORK / "calls"
CALLS.mkdir(exist_ok=True)
STATE = {"run": "warmup"}
_lock = threading.Lock()


class Proxy(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _forward(self, body: bytes | None):
        req = urllib.request.Request(f"http://127.0.0.1:{VLLM_PORT}{self.path}", data=body, method=self.command)
        for h in ("Content-Type", "Authorization", "Accept"):
            if self.headers.get(h):
                req.add_header(h, self.headers[h])
        t = time.time()
        try:
            with urllib.request.urlopen(req, timeout=3600) as r:
                status, data, ctype = r.status, r.read(), r.headers.get("Content-Type", "application/json")
        except urllib.error.HTTPError as e:
            status, data, ctype = e.code, e.read(), e.headers.get("Content-Type", "application/json")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
        return status, data, time.time() - t

    def do_GET(self):
        self._forward(None)

    def do_POST(self):
        body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        status, data, dt = self._forward(body)
        if self.path.endswith("/chat/completions"):
            try:
                rec = {"run": STATE["run"], "t": time.time(), "latency": round(dt, 3), "status": status,
                       "request": json.loads(body), "response": json.loads(data) if not data.startswith(b"data:") else data.decode()[:200000]}
                with _lock, open(CALLS / f"{STATE['run']}.jsonl", "a") as f:
                    f.write(json.dumps(rec) + "\n")
            except Exception as e:
                log("proxy log error", e)


proxy = ThreadingHTTPServer(("127.0.0.1", PROXY_PORT), Proxy)
threading.Thread(target=proxy.serve_forever, daemon=True).start()

# ---------------------------------------------------------------- vLLM (competition settings)
seed_bundle = write_bundle(WORK / "bundle_seed", 0.7)
adapters = discover_adapters(str(seed_bundle), adapter_extensions=ALLOWED_ADAPTER_EXTENSIONS)
cfg = VllmConfig(
    model=str(MODEL_PATH), port=VLLM_PORT, host="127.0.0.1", tool_call_parser="gemma4", reasoning_parser="gemma4",
    default_chat_template_kwargs={"enable_thinking": True}, max_model_len=32768, dtype="bfloat16",
    gpu_memory_utilization=0.80, enable_auto_tool_choice=True, enable_lora=False,
    tensor_parallel_size=min(4, max(1, torch.cuda.device_count())), startup_timeout=60 * 30,
)
server = VllmServer(cfg, adapter_manifest=adapters)
server.start()
log("vLLM up on", server.base_url)
type(server).base_url = property(lambda s: f"http://127.0.0.1:{PROXY_PORT}/v1")
models = server.create_model_registry(aliases=["gemma-4-31b-it-qat-w4a16-ct"], model_prefix="openai/", api_key="EMPTY")

TASKS_PATH = DATA_DIR / "tasks.jsonl"
tasks = load_tasks(TASKS_PATH)
TRAIN_IDS = [t.instance_id for t in tasks if t.repo in ("fastapi/fastapi", "psf/requests", "encode/httpx")]
VAL_IDS = [t.instance_id for t in tasks if t.repo == "Textualize/rich"]
log(len(TRAIN_IDS), "train-fold tasks,", len(VAL_IDS), "val-fold tasks")
limits, gen_constraints = build_submission_limits()


def run_sync(fn):
    import concurrent.futures
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(fn())
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(lambda: asyncio.run(fn())).result()


def run(name: str, ids: list[str], temperature: float, est_min: float) -> dict | None:
    elapsed_h = (time.time() - T0) / 3600
    if elapsed_h + est_min / 60 > TIME_LIMIT_H:
        log(f"skip {name}: {elapsed_h:.2f} h used, needs ~{est_min:.0f} min")
        return None
    bundle = write_bundle(WORK / f"bundle_{name}", temperature)
    ev = yaml.safe_load((bundle / "eval_config.yaml").read_text())["evaluation"]
    STATE["run"] = name
    out = WORK / "runs" / name
    ec = EvalConfig(
        tasks_path=TASKS_PATH, snapshots_dir=DATA_DIR / "snapshots", results_dir=out, submission_dir=bundle, models=models,
        sandbox="subprocess", timeout_seconds=int(ev["timeout_seconds"]), verification_timeout_seconds=300,
        max_time_minutes=float(ev["max_time_minutes"]), max_tool_calls=int(ev["max_tool_calls"]), max_turns=int(ev["max_turns"]),
        limits=limits, generation_constraints=gen_constraints, adapter_manifest=adapters,
        context_cache_config=ContextCacheConfig(min_tokens=2048, ttl_seconds=1800, cache_intervals=10),
        events_compaction_config=EventsCompactionConfig(compaction_interval=5, overlap_size=2, token_threshold=14336, event_retention_size=5),
        graph_dir=str(DATA_DIR / "graphs"), embeddings_dir=str(DATA_DIR / "embeddings"), wheels_dir=DATA_DIR / "wheels",
        verbose=False, task_ids=ids, concurrency=CONCURRENCY, display_mode="quiet",
    )
    t = time.time()
    res = run_sync(Evaluator(ec).run)
    rows = res.task_results
    n_res = sum(bool(r.resolved) for r in rows)
    summ = {"run": name, "tasks": len(rows), "resolved": n_res, "rate": round(n_res / max(1, len(rows)), 4),
            "temperature": temperature, "minutes": round((time.time() - t) / 60, 1),
            "median_tool_calls": sorted(int(r.tool_calls or 0) for r in rows)[len(rows) // 2] if rows else None}
    log("RUN", json.dumps(summ))
    (out / "run_summary.json").write_text(json.dumps(summ, indent=1))
    return summ


summaries = []
for name, ids, temp, est in (("val_base_c2", VAL_IDS, 0.2, 130), ("val_graph_c2", VAL_IDS, 0.2, 130)):
    s = run(name, ids, temp, est)
    if s:
        rows = [json.loads(l) for l in open(WORK / "runs" / name / "task_results.jsonl")]
        d = sorted(float(r["duration_seconds"]) for r in rows)
        s["duration_s"] = {"p50": d[len(d) // 2], "p90": d[int(len(d) * 0.9)], "max": d[-1], "sum": round(sum(d))}
        s["timeouts"] = sum("timeout" in (r.get("error") or "") for r in rows)
        log("DURATIONS", name, s["duration_s"], "timeouts", s["timeouts"])
        summaries.append(s)
(WORK / "eval_summary.json").write_text(json.dumps(summaries, indent=1))
server.stop()
proxy.shutdown()
n_calls = {p.stem: sum(1 for _ in open(p)) for p in CALLS.glob("*.jsonl")}
log("logged model calls per run:", n_calls)
for d in WORK.glob("bundle_*"):
    shutil.rmtree(d, ignore_errors=True)
log("done in", round((time.time() - T0) / 3600, 2), "h")
