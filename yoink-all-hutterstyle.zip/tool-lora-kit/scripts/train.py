"""Tool-use LoRA for gemma-4-31b-it-qat-w4a16-ct, following recipe/gemma4_31b_peft_recipe.md (mapping A, 4x L4).

1. Build turn-mode SFT samples from the rejection-sampling run (resolved train-fold trajectories only).
2. Train LoRA r=16 / alpha=32 / dropout 0.05 on the 410 language-model projections, assistant tokens only.
3. Gates: effect gate (adapter changes logits), teacher-forced next-tool accuracy on the held-out rich fold.
4. Export an HF PEFT adapter with the key layout the competition's vLLM loader expects.
5. Behaviour check: serve the adapter with vLLM and run the A1 bundle + adapter on the rich fold.
"""
import gc, glob, importlib, json, math, os, random, re, shutil, subprocess, sys, time
from collections import Counter, defaultdict
from pathlib import Path

T0 = time.time()
TIME_LIMIT_H = float(os.environ.get("TIME_LIMIT_H", "11.3"))
TRAIN_BUDGET_H = float(os.environ.get("TRAIN_BUDGET_H", "4.5"))
VAL_EVAL_MIN = 130
MAX_LEN = int(os.environ.get("MAX_LEN", "16384"))
MAX_TURNS_PER_TRAJ = 8
MAX_RUNS_PER_TASK = 2
EPOCHS = 2
GLOBAL_BATCH = 16
LR, WARMUP_FRAC, CLIP, SEED = 1e-4, 0.03, 1.0, 42
LORA_R, LORA_ALPHA, LORA_DROPOUT = 16, 32, 0.05
TOOLS = ["run_command", "read_file", "edit_file", "write_file", "get_status", "submit_patch",
         "get_code_neighbors", "search_similar_code", "get_code_subgraph"]
GRAPH_TOOLS = {"get_code_neighbors", "search_similar_code", "get_code_subgraph"}
COMPETITION_MODEL = "gemma-4-31b-it-qat-w4a16-ct"
random.seed(SEED)
for k, v in {"TRANSFORMERS_NO_TF": "1", "TRANSFORMERS_NO_FLAX": "1", "TRANSFORMERS_OFFLINE": "1", "VLLM_NO_USAGE_STATS": "1",
             "VLLM_WORKER_MULTIPROC_METHOD": "spawn", "VLLM_ENGINE_READY_TIMEOUT_S": "1800", "NCCL_DEBUG": "WARN",
             "LITELLM_LOCAL_MODEL_COST_MAP": "True", "LITELLM_TELEMETRY": "False", "LITELLM_LOG": "WARNING",
             "OPENAI_API_KEY": "EMPTY", "LOCAL_API_KEY": "EMPTY", "PYTORCH_CUDA_ALLOC_CONF": "expandable_segments:True",
             "OTEL_SDK_DISABLED": "true", "OTEL_PYTHON_DISABLED": "true"}.items():
    os.environ.setdefault(k, v)
WORK = Path("/kaggle/working")
METRICS = {"recipe": "gemma4_31b_peft_config, mapping A (HF PEFT) on 4x L4", "seed": SEED}


def log(*a):
    print(f"[{(time.time() - T0) / 60:6.1f} min]", *a, flush=True)


def save_metrics():
    (WORK / "metrics.json").write_text(json.dumps(METRICS, indent=1, default=str))


def first(*cands):
    return next((Path(c) for c in cands if c and Path(c).exists()), None)


def find_one(pattern):
    hits = sorted(glob.glob(pattern, recursive=True))
    return Path(hits[0]) if hits else None


WHEELHOUSE = first("/kaggle/input/datasets/metric/gemma-4-developer-agent-wheelhouse", "/kaggle/input/gemma-4-developer-agent-wheelhouse")
DATA_DIR = first("/kaggle/input/competitions/gemma-4-developer-agent", "/kaggle/input/gemma-4-developer-agent")
SERVE_MODEL = find_one("/kaggle/input/**/gemma-4-31b-it-qat-w4a16-ct/2")
TRAIN_MODEL = find_one("/kaggle/input/**/gemma-4-31b-it-qat-q4_0-unquantized/2")
SAMPLING = find_one("/kaggle/input/**/calls")
SAMPLING = SAMPLING.parent if SAMPLING else None
log("serve model", SERVE_MODEL, "| train model", TRAIN_MODEL, "| sampling output", SAMPLING, "| data", DATA_DIR)
log(subprocess.run("nvidia-smi --query-gpu=name,memory.total --format=csv,noheader", shell=True, capture_output=True, text=True).stdout.strip())

# ---------------------------------------------------------------- packages (offline: competition wheelhouse)
for pth in glob.glob("/usr/local/lib/python*/dist-packages/*cutlass*.pth"):
    try:
        os.unlink(pth)
    except OSError:
        pass
tmp = Path("/tmp/wheelhouse")
tmp.mkdir(exist_ok=True)
for w in WHEELHOUSE.glob("*.whl"):
    if "cutlass" in w.name.lower():
        continue
    t = tmp / (w.name.replace("cu128", "+cu128") if ("cu128" in w.name and "+" not in w.name) else w.name)
    if not t.exists():
        os.symlink(w, t)
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--no-deps", "--force-reinstall", *sorted(map(str, tmp.glob("*.whl")))], check=True)
importlib.invalidate_caches()
import torch, transformers, peft
log("torch", torch.__version__, "| transformers", transformers.__version__, "| peft", peft.__version__)
METRICS["versions"] = {"torch": torch.__version__, "transformers": transformers.__version__, "peft": peft.__version__}
from transformers import AutoTokenizer

tok = AutoTokenizer.from_pretrained(str(SERVE_MODEL))
tok.chat_template = (SERVE_MODEL / "chat_template.jinja").read_text()


# ---------------------------------------------------------------- 1. samples from the rejection-sampling run
def jl(p):
    return [json.loads(l) for l in open(p) if l.strip()]


def fmt_arg(v):
    if isinstance(v, str):
        return '<|"|>' + v + '<|"|>'
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, dict):
        return "{" + ",".join(f"{k}:{fmt_arg(v[k])}" for k in sorted(v)) + "}"
    if isinstance(v, (list, tuple)):
        return "[" + ",".join(fmt_arg(x) for x in v) + "]"
    return str(v)


def parse_args(a):
    if isinstance(a, dict):
        return a
    try:
        return json.loads(a or "{}")
    except ValueError:
        return {"_raw": a}


def norm_messages(msgs):
    out = []
    for m in msgs:
        m = dict(m)
        if m.get("tool_calls"):
            m["tool_calls"] = [{**tc, "function": {**tc["function"], "arguments": parse_args(tc["function"].get("arguments"))}} for tc in m["tool_calls"]]
        out.append(m)
    return out


def target_text(msg):
    """Assistant turn exactly as the model emits it: thought channel, visible text, tool calls, then the stop token."""
    reasoning = msg.get("reasoning_content") or msg.get("reasoning") or ""
    content = (msg.get("content") or "").strip()
    calls = msg.get("tool_calls") or []
    s = ""
    if calls:
        if reasoning:
            s += "<|channel>thought\n" + reasoning.strip() + "\n<channel|>"
        s += content
        for tc in calls:
            args = parse_args(tc["function"].get("arguments"))
            s += "<|tool_call>call:" + tc["function"]["name"] + "{" + ",".join(f"{k}:{fmt_arg(args[k])}" for k in sorted(args)) + "}<tool_call|>"
        return s + "<|tool_response>"
    return content + "<turn|>"


def trace_calls(path):
    d = json.load(open(path))
    out = []
    for st in d.get("steps", []):
        for tc in st.get("tool_calls") or []:
            out.append((tc.get("tool_call_id"), tc.get("function_name"), json.dumps(tc.get("arguments"), sort_keys=True)))
    return out


def tool_result_text(req_msgs, call_id):
    for m in req_msgs:
        if m.get("role") == "tool" and m.get("tool_call_id") == call_id:
            c = m.get("content")
            return c if isinstance(c, str) else json.dumps(c)
    return None


GRAPH_FAIL = re.compile(r"error|not found|no node|unknown node|does not exist|0 neighbors|no results", re.I)


def load_run(run):
    rdir = SAMPLING / "runs" / run
    calls_path = SAMPLING / "calls" / f"{run}.jsonl"
    if not (rdir / "task_results.jsonl").exists() or not calls_path.exists():
        return None
    results = {r["instance_id"]: r for r in jl(rdir / "task_results.jsonl")}
    by_id, by_args = {}, defaultdict(set)
    for tp in glob.glob(str(rdir / "traces" / "trace_*.json")):
        iid = Path(tp).stem[len("trace_"):]
        for cid, name, args in trace_calls(tp):
            if cid:
                by_id[cid] = iid
            by_args[(name, args)].add(iid)
    recs = [r for r in jl(calls_path) if r.get("status") == 200 and isinstance(r.get("response"), dict)]
    # 1) anchor: a response whose tool call (name + args) occurs in exactly one task's trace
    anchor = {}
    for i, r in enumerate(recs):
        for tc in r["response"]["choices"][0]["message"].get("tool_calls") or []:
            iid = by_id.get(tc.get("id"))
            if not iid:
                cand = by_args.get((tc["function"]["name"], json.dumps(parse_args(tc["function"].get("arguments")), sort_keys=True)), set())
                iid = next(iter(cand)) if len(cand) == 1 else None
            if iid:
                anchor[i] = iid
                break
    # 2) link: a request whose history contains a tool-call id that an earlier response produced is the same session
    parent = list(range(len(recs)))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    made_by = {}
    for i, r in enumerate(recs):
        for tc in r["response"]["choices"][0]["message"].get("tool_calls") or []:
            if tc.get("id"):
                made_by[tc["id"]] = i
    for i, r in enumerate(recs):
        for m in r["request"]["messages"]:
            for tc in m.get("tool_calls") or []:
                j = made_by.get(tc.get("id"))
                if j is not None:
                    parent[root(i)] = root(j)
            if m.get("role") == "tool" and made_by.get(m.get("tool_call_id")) is not None:
                parent[root(i)] = root(made_by[m["tool_call_id"]])
    votes = defaultdict(Counter)
    for i, iid in anchor.items():
        votes[root(i)][iid] += 1
    comp_task = {c: v.most_common(1)[0][0] for c, v in votes.items() if v.most_common(1)[0][1] >= 0.8 * sum(v.values())}
    per_task, unmatched = defaultdict(list), 0
    for i, r in enumerate(recs):
        iid = comp_task.get(root(i))
        if iid is None:
            unmatched += 1
            continue
        per_task[iid].append(r)
    for v in per_task.values():
        v.sort(key=lambda r: r["t"])
    return results, per_task, unmatched, len(recs)


def traj_features(calls):
    names, graph_ok = [], 0
    for i, r in enumerate(calls):
        for tc in r["response"]["choices"][0]["message"].get("tool_calls") or []:
            names.append(tc["function"]["name"])
            if tc["function"]["name"] in GRAPH_TOOLS:
                nxt = next((c for c in calls[i + 1:] if tool_result_text(c["request"]["messages"], tc.get("id")) is not None), None)
                txt = tool_result_text(nxt["request"]["messages"], tc.get("id")) if nxt else None
                graph_ok += int(bool(txt) and not GRAPH_FAIL.search(txt[:400]))
    return {"n_calls": len(names), "graph_ok": graph_ok, "names": names}


def pick_turns(calls):
    """At most 8 turns per trajectory: graph-call turns, the first two turns, the first edit, the submit, then spread."""
    idx_name = [(i, [tc["function"]["name"] for tc in (r["response"]["choices"][0]["message"].get("tool_calls") or [])]) for i, r in enumerate(calls)]
    order = [i for i, n in idx_name if GRAPH_TOOLS & set(n)]
    order += [0, 1]
    order += [next((i for i, n in idx_name if "edit_file" in n), None), next((i for i, n in idx_name if "submit_patch" in n), None)]
    rest = [i for i, _ in idx_name if i not in order]
    step = max(1, len(rest) // MAX_TURNS_PER_TRAJ)
    order += rest[::step]
    seen, out = set(), []
    for i in order:
        if i is not None and i < len(calls) and i not in seen:
            seen.add(i)
            out.append(i)
    return out[:MAX_TURNS_PER_TRAJ]


def render(rec):
    req = rec["request"]
    msgs, tools = norm_messages(req["messages"]), req.get("tools")
    prompt = tok.apply_chat_template(msgs, tools=tools, add_generation_prompt=True, tokenize=False, enable_thinking=True)
    tgt = target_text(rec["response"]["choices"][0]["message"])
    p_ids = tok(prompt, add_special_tokens=False)["input_ids"]
    t_ids = tok(tgt, add_special_tokens=False)["input_ids"]
    served = (rec["response"].get("usage") or {}).get("prompt_tokens")
    return p_ids, t_ids, served


def build_samples(runs):
    samples, stats = [], {"runs": {}, "prompt_token_match": Counter()}
    chosen = defaultdict(list)
    for run in runs:
        loaded = load_run(run)
        if not loaded:
            continue
        results, per_task, unmatched, n = loaded
        stats["runs"][run] = {"calls": n, "unmatched_calls": unmatched, "tasks": len(results),
                              "resolved": sum(bool(r["resolved"]) for r in results.values())}
        for iid, calls in per_task.items():
            if results.get(iid, {}).get("resolved"):
                chosen[iid].append((run, calls, traj_features(calls)))
    for iid, lst in chosen.items():
        lst.sort(key=lambda x: (-x[2]["graph_ok"], x[2]["n_calls"]))
        for run, calls, feat in lst[:MAX_RUNS_PER_TASK]:
            rendered = {}
            for ti, rec in enumerate(calls):
                p_ids, t_ids, served = render(rec)
                if served is not None:
                    d = len(p_ids) - served
                    stats["prompt_token_match"]["exact" if d == 0 else ("within_1pct" if abs(d) <= 0.01 * served else "off")] += 1
                if t_ids and len(p_ids) + len(t_ids) <= MAX_LEN:
                    rendered[ti] = (p_ids, t_ids)
                else:
                    stats["skipped_too_long"] = stats.get("skipped_too_long", 0) + 1
            fitting = [calls[i] for i in sorted(rendered)]
            idx = sorted(rendered)
            for k in pick_turns(fitting):
                ti = idx[k]
                p_ids, t_ids = rendered[ti]
                name = (calls[ti]["response"]["choices"][0]["message"].get("tool_calls") or [{"function": {"name": "final"}}])[0]["function"]["name"]
                samples.append({"iid": iid, "run": run, "turn": ti, "tool": name, "ids": p_ids + t_ids, "n_prompt": len(p_ids)})
    stats["prompt_token_match"] = dict(stats["prompt_token_match"])
    stats["samples"] = len(samples)
    stats["tasks_with_samples"] = len({s["iid"] for s in samples})
    stats["tool_mix"] = dict(Counter(s["tool"] for s in samples))
    stats["tokens"] = sum(len(s["ids"]) for s in samples)
    stats["supervised_tokens"] = sum(len(s["ids"]) - s["n_prompt"] for s in samples)
    return samples, stats


train_samples, sstats = build_samples(["train_s0", "train_s1"])
log("SAMPLES", json.dumps(sstats))
METRICS["samples"] = sstats
save_metrics()
assert train_samples, "no resolved trajectories to train on"


def val_decisions(run="val_base", limit=200):
    """Held-out rich-fold decision points from the base run: prompt and the tool the base agent chose."""
    loaded = load_run(run)
    if not loaded:
        return []
    results, per_task, _, _ = loaded
    out = []
    for iid, calls in per_task.items():
        for r in calls:
            msg = r["response"]["choices"][0]["message"]
            if not msg.get("tool_calls"):
                continue
            p_ids, _, _ = render(r)
            if len(p_ids) > MAX_LEN - 64:
                continue
            reasoning = msg.get("reasoning_content") or msg.get("reasoning") or ""
            pre = ("<|channel>thought\n" + reasoning.strip() + "\n<channel|>" if reasoning else "") + (msg.get("content") or "").strip() + "<|tool_call>call:"
            pre_ids = tok(pre, add_special_tokens=False)["input_ids"]
            out.append({"iid": iid, "resolved": bool(results.get(iid, {}).get("resolved")), "ids": p_ids + pre_ids,
                        "tool": msg["tool_calls"][0]["function"]["name"]})
    random.Random(SEED).shuffle(out)
    return out[:limit]


val_dec = val_decisions()
log(len(val_dec), "held-out decision points (rich fold)")
TOOL_IDS = {t: tok(t, add_special_tokens=False)["input_ids"] for t in TOOLS}
assert len({tuple(v) for v in TOOL_IDS.values()}) == len(TOOLS), TOOL_IDS

# ---------------------------------------------------------------- 2. model + LoRA
from peft import LoraConfig, get_peft_model, get_peft_model_state_dict
from transformers import AutoModelForCausalLM, BitsAndBytesConfig

# The 10 global-attention layers have head_dim 512, which SDPA's fused kernels do not take, so SDPA falls back to the
# math kernel and materializes heads x L x L scores (about 16 GiB at 16k). Query-chunked attention, recomputed per chunk
# in backward, keeps that to about 2 GiB with identical results (checked against plain SDPA on a small Gemma 4 config).
try:
    from transformers import AttentionInterface
    from transformers.integrations.sdpa_attention import sdpa_attention_forward
    from transformers.masking_utils import AttentionMaskInterface, sdpa_mask

    ATTN_CHUNK = 2048


    def chunked_sdpa(module, query, key, value, attention_mask, dropout=0.0, scaling=None, is_causal=None, **kw):
        q_len, kv_len = query.shape[2], key.shape[2]
        if q_len <= ATTN_CHUNK:
            return sdpa_attention_forward(module, query, key, value, attention_mask, dropout=dropout, scaling=scaling, is_causal=is_causal, **kw)
        outs = []
        for s in range(0, q_len, ATTN_CHUNK):
            e = min(q_len, s + ATTN_CHUNK)
            if attention_mask is not None:
                m = attention_mask[:, :, s:e, :]
            else:
                qi = torch.arange(s, e, device=query.device)[:, None] + (kv_len - q_len)
                m = (torch.arange(kv_len, device=query.device)[None, :] <= qi)[None, None]

            def f(q, k, v, mm):
                return sdpa_attention_forward(module, q, k, v, mm, dropout=dropout, scaling=scaling, is_causal=False, **kw)[0]

            if torch.is_grad_enabled():
                outs.append(torch.utils.checkpoint.checkpoint(f, query[:, :, s:e], key, value, m, use_reentrant=False))
            else:
                outs.append(f(query[:, :, s:e], key, value, m))
        return torch.cat(outs, dim=1), None


    AttentionInterface.register("chunked_sdpa", chunked_sdpa)
    AttentionMaskInterface.register("chunked_sdpa", sdpa_mask)
    ATTN_IMPL = "chunked_sdpa"
except Exception as e:
    log("chunked attention unavailable, falling back to sdpa with MAX_LEN 6144:", e)
    ATTN_IMPL, MAX_LEN = "sdpa", 6144
    train_samples = [s for s in train_samples if len(s["ids"]) <= MAX_LEN]
    val_dec = [d for d in val_dec if len(d["ids"]) <= MAX_LEN]
METRICS["attention"] = {"impl": ATTN_IMPL, "chunk": 2048, "max_len": MAX_LEN}


ngpu = torch.cuda.device_count()
max_memory = {i: "20GiB" for i in range(ngpu)}
bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=torch.bfloat16,
                         llm_int8_skip_modules=["vision_tower", "audio_tower", "embed_vision", "embed_audio", "lm_head", "multi_modal_projector"])
t = time.time()
base = AutoModelForCausalLM.from_pretrained(str(TRAIN_MODEL), device_map="balanced", max_memory=max_memory, quantization_config=bnb,
                                            dtype=torch.bfloat16, attn_implementation=ATTN_IMPL)
log(f"base loaded in {time.time() - t:.0f}s:", type(base).__name__, {i: round(torch.cuda.memory_allocated(i) / 2**30, 1) for i in range(ngpu)})
base.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
base.enable_input_require_grads()
for p in base.parameters():
    p.requires_grad_(False)
TARGET = r".*language_model\.layers\.\d+\.(self_attn\.(q|k|v|o)_proj|mlp\.(gate|up|down)_proj)$"
if not any(re.match(TARGET, n) for n, _ in base.named_modules()):
    TARGET = r".*model\.layers\.\d+\.(self_attn\.(q|k|v|o)_proj|mlp\.(gate|up|down)_proj)$"
lcfg = LoraConfig(r=LORA_R, lora_alpha=LORA_ALPHA, lora_dropout=LORA_DROPOUT, bias="none", target_modules=TARGET, task_type="CAUSAL_LM")
model = get_peft_model(base, lcfg)
n_wrapped = sum(1 for n, m in model.named_modules() if hasattr(m, "lora_A") and "default" in getattr(m, "lora_A", {}))
log("LoRA-wrapped projections:", n_wrapped)
METRICS["lora"] = {"r": LORA_R, "alpha": LORA_ALPHA, "dropout": LORA_DROPOUT, "wrapped_projections": n_wrapped, "target_regex": TARGET}
for n, p in model.named_parameters():
    if p.requires_grad:
        p.data = p.data.float()
# PEFT would cast every activation to fp32 to match the fp32 LoRA weights (about 2x activation memory). Instead keep
# fp32 master weights and run the forward under bf16 autocast, so the LoRA matmuls see bf16 inputs.
n_nocast = 0
for m in model.modules():
    if hasattr(m, "cast_input_dtype_enabled"):
        m.cast_input_dtype_enabled = False
        n_nocast += 1
log("PEFT input casting disabled on", n_nocast, "modules; forward under bf16 autocast")
inner = model.get_base_model()
text_cfg = inner.config.get_text_config() if hasattr(inner.config, "get_text_config") else inner.config
SOFTCAP = getattr(text_cfg, "final_logit_softcapping", None)
lm_head = inner.get_output_embeddings()
decoder = inner.model
CE_CHUNK = 512


def head(h):
    z = lm_head(h.to(lm_head.weight.device)).float()
    return torch.tanh(z / SOFTCAP) * SOFTCAP if SOFTCAP else z


def dec(**kw):
    with torch.autocast("cuda", dtype=torch.bfloat16):
        return decoder(**kw)


def hidden(ids):
    dev = model.get_input_embeddings().weight.device
    return dec(input_ids=torch.tensor(ids, device=dev)[None]).last_hidden_state[0]


def sample_nll(s):
    h = hidden(s["ids"])
    ids = torch.tensor(s["ids"], device=h.device)
    pos = torch.arange(s["n_prompt"] - 1, len(s["ids"]) - 1, device=h.device)
    tot = 0.0
    for a in range(0, len(pos), CE_CHUNK):
        pp = pos[a:a + CE_CHUNK]
        tot = tot + torch.utils.checkpoint.checkpoint(
            lambda hh, tt: torch.nn.functional.cross_entropy(head(hh), tt.to(lm_head.weight.device), reduction="sum"),
            h[pp], ids[pp + 1], use_reentrant=False)
    return tot, len(pos)


@torch.no_grad()
def greedy_tool(ids):
    """Greedy walk over the tool-name token trie: the tool greedy decoding would call at this decision point."""
    dev = model.get_input_embeddings().weight.device
    out = dec(input_ids=torch.tensor(ids, device=dev)[None], use_cache=True)
    past, h = out.past_key_values, out.last_hidden_state[0, -1:]
    prefix = []
    while True:
        cands = [t for t in TOOLS if TOOL_IDS[t][:len(prefix)] == prefix]
        if len(cands) == 1 and len(prefix) >= 1:
            return cands[0]
        nxt = sorted({TOOL_IDS[t][len(prefix)] for t in cands if len(TOOL_IDS[t]) > len(prefix)})
        done = [t for t in cands if len(TOOL_IDS[t]) == len(prefix)]
        if not nxt:
            return done[0]
        logits = head(h)[0]
        tid = nxt[int(logits[torch.tensor(nxt, device=logits.device)].argmax())]
        prefix.append(tid)
        out = dec(input_ids=torch.tensor([[tid]], device=dev), past_key_values=past, use_cache=True)
        past, h = out.past_key_values, out.last_hidden_state[0, -1:]


@torch.no_grad()
def tool_acc(decs):
    model.eval()
    hit = n = 0
    per = Counter()
    for d in decs:
        pred = greedy_tool(d["ids"])
        hit += pred == d["tool"]
        n += 1
        per[(d["tool"], pred)] += 1
    model.train()
    return hit / max(n, 1), {f"{a}->{b}": c for (a, b), c in per.most_common(12)}


def with_adapter(enabled, fn, *a):
    if enabled:
        return fn(*a)
    with model.disable_adapter():
        return fn(*a)


# timing probe on the heaviest samples (recipe 5.1)
train_samples.sort(key=lambda s: -len(s["ids"]))
model.train()
def probe(samples):
    pt, ptok = 0.0, 0
    for s in samples:
        torch.cuda.synchronize()
        t = time.time()
        nll, k = sample_nll(s)
        (nll / k).backward()
        torch.cuda.synchronize()
        pt += time.time() - t
        ptok += len(s["ids"])
    model.zero_grad(set_to_none=True)
    return pt, ptok


def fits(L):
    cand = [x for x in train_samples if len(x["ids"]) <= L]
    if not cand:
        return False
    ok = True
    try:
        probe([max(cand, key=lambda x: len(x["ids"]))])
    except torch.cuda.OutOfMemoryError:
        ok = False
    model.zero_grad(set_to_none=True)
    gc.collect()
    torch.cuda.empty_cache()
    log(f"fit probe at {L} tokens: {'ok' if ok else 'OOM'}", {i: round(torch.cuda.max_memory_allocated(i) / 2**30, 1) for i in range(ngpu)})
    for i in range(ngpu):
        torch.cuda.reset_peak_memory_stats(i)
    return ok


before = len(train_samples)
MAX_LEN = next((L for L in (16384, 12288, 8192, 6144, 4096) if L <= MAX_LEN and fits(L)), None)
assert MAX_LEN, "no context length fits"
train_samples = [x for x in train_samples if len(x["ids"]) <= MAX_LEN]
val_dec = [d for d in val_dec if len(d["ids"]) <= MAX_LEN]
train_samples.sort(key=lambda x: -len(x["ids"]))
METRICS["max_len"] = {"max_len": MAX_LEN, "kept": len(train_samples), "of": before}
log("MAX_LEN", METRICS["max_len"])
probe_t, probe_tok = probe(train_samples[:2] + train_samples[-2:])
sec_per_tok = probe_t / probe_tok
peak = {i: round(torch.cuda.max_memory_allocated(i) / 2**30, 1) for i in range(ngpu)}
log(f"probe: {sec_per_tok * 1000:.2f} ms/token, peak GiB {peak}, longest sample {len(train_samples[0]['ids'])} tokens")
METRICS["fit_probe"] = {"ms_per_token": round(sec_per_tok * 1000, 3), "peak_alloc_gib": peak, "longest_tokens": len(train_samples[0]["ids"])}

budget_s = min(TRAIN_BUDGET_H * 3600, (TIME_LIMIT_H * 3600 - (time.time() - T0)) - (VAL_EVAL_MIN + 40) * 60)
random.Random(SEED).shuffle(train_samples)
need = EPOCHS * sum(len(s["ids"]) for s in train_samples) * sec_per_tok
if need > budget_s:
    by_task = defaultdict(list)
    for s in train_samples:
        by_task[s["iid"]].append(s)
    keep, tok_budget = [], budget_s / (EPOCHS * sec_per_tok)
    rr = [sorted(v, key=lambda s: len(s["ids"])) for v in by_task.values()]
    used = 0
    while any(rr) and used < tok_budget:
        for v in rr:
            if v and used + len(v[0]["ids"]) <= tok_budget:
                s = v.pop(0)
                keep.append(s)
                used += len(s["ids"])
            elif v:
                v.clear()
    log(f"time box: kept {len(keep)}/{len(train_samples)} samples ({used} tokens) to fit {budget_s / 3600:.2f} h")
    train_samples = keep
METRICS["train_set"] = {"samples": len(train_samples), "tokens": sum(len(s["ids"]) for s in train_samples),
                        "supervised_tokens": sum(len(s["ids"]) - s["n_prompt"] for s in train_samples),
                        "tasks": len({s["iid"] for s in train_samples}), "est_hours": round(EPOCHS * sum(len(s["ids"]) for s in train_samples) * sec_per_tok / 3600, 2)}
log("TRAIN SET", METRICS["train_set"])
save_metrics()

# baseline numbers before any update
base_acc, base_conf = with_adapter(False, tool_acc, val_dec)
log(f"held-out next-tool accuracy, base: {base_acc:.3f}")
METRICS["heldout_tool_acc"] = {"base": round(base_acc, 4), "base_confusions": base_conf, "n": len(val_dec)}
save_metrics()

# ---------------------------------------------------------------- 4. export (HF PEFT, competition key layout)
from safetensors.torch import save_file

KEY = re.compile(r"layers\.(\d+)\.(self_attn|mlp)\.(\w+_proj)\.lora_(A|B)(?:\.default)?\.weight$")


def export_adapter(dst):
    sd = get_peft_model_state_dict(model)
    out_sd = {}
    for k, v in sd.items():
        m = KEY.search(k)
        assert m, k
        out_sd[f"base_model.model.model.language_model.layers.{m[1]}.{m[2]}.{m[3]}.lora_{m[4]}.weight"] = v.detach().to(torch.bfloat16).cpu().contiguous()
    del sd
    shutil.rmtree(dst, ignore_errors=True)
    dst.mkdir(parents=True)
    save_file(out_sd, str(dst / "adapter_model.safetensors"), metadata={"format": "pt"})
    acfg = {"peft_type": "LORA", "task_type": "CAUSAL_LM", "base_model_name_or_path": "google/gemma-4-31b-it-qat-w4a16-ct",
            "r": LORA_R, "lora_alpha": LORA_ALPHA, "lora_dropout": LORA_DROPOUT, "bias": "none", "fan_in_fan_out": False,
            "inference_mode": True, "init_lora_weights": True, "use_dora": False, "use_rslora": False, "modules_to_save": None,
            "target_modules": sorted({re.search(r"\.(\w+_proj)\.", k)[1] for k in out_sd}), "layers_to_transform": None,
            "layers_pattern": None, "rank_pattern": {}, "alpha_pattern": {}, "revision": None}
    (dst / "adapter_config.json").write_text(json.dumps(acfg, indent=1))
    proj = {k.rsplit(".lora_", 1)[0] for k in out_sd}
    size = (dst / "adapter_model.safetensors").stat().st_size
    log(f"adapter exported to {dst}: {len(proj)} projections, {len(out_sd)} tensors, {size / 2**20:.1f} MiB")
    return {"projections": len(proj), "tensors": len(out_sd), "mib": round(size / 2**20, 1), "target_modules": acfg["target_modules"]}


# ---------------------------------------------------------------- training loop
params = [p for p in model.parameters() if p.requires_grad]
opt = torch.optim.AdamW(params, lr=LR, weight_decay=0.0)
steps = math.ceil(len(train_samples) * EPOCHS / GLOBAL_BATCH)
warm = max(1, round(WARMUP_FRAC * steps))
sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: (s + 1) / warm if s < warm else 0.5 * (1 + math.cos(math.pi * (s - warm) / max(1, steps - warm))))
log(f"{steps} optimizer steps, warmup {warm}")
hist, step, last_ckpt = [], 0, time.time()
ADIR = WORK / "adapter_ckpt"
model.train()
for ep in range(EPOCHS):
    order = list(range(len(train_samples)))
    random.Random(SEED + ep).shuffle(order)
    acc_loss, acc_tok, micro = 0.0, 0, 0
    for j, i in enumerate(order):
        s = train_samples[i]
        nll, k = sample_nll(s)
        if not torch.isfinite(nll):
            raise FloatingPointError(f"non-finite loss on sample {i}")
        (nll / k / GLOBAL_BATCH).backward()
        acc_loss += nll.item()
        acc_tok += k
        micro += 1
        if micro == GLOBAL_BATCH or j == len(order) - 1:
            gn = torch.nn.utils.clip_grad_norm_(params, CLIP)
            opt.step()
            sched.step()
            opt.zero_grad(set_to_none=True)
            step += 1
            hist.append({"step": step, "epoch": ep, "loss": round(acc_loss / acc_tok, 4), "grad_norm": round(float(gn), 4),
                         "lr": sched.get_last_lr()[0], "min": round((time.time() - T0) / 60, 1)})
            log("step", hist[-1])
            acc_loss, acc_tok, micro = 0.0, 0, 0
            if time.time() - last_ckpt > 25 * 60:
                model.save_pretrained(ADIR)
                last_ckpt = time.time()
            METRICS["train_history"] = hist
            save_metrics()
    if ep == 0 and EPOCHS > 1:
        METRICS["export_epoch1"] = export_adapter(WORK / "adapter_epoch1" / "main_lora")
        save_metrics()
METRICS["train_history"] = hist
first_losses = [h["loss"] for h in hist[:3]]
last_losses = [h["loss"] for h in hist[-3:]]
METRICS["loss_sentinel"] = {"finite": all(math.isfinite(h["loss"]) for h in hist), "first3": first_losses, "last3": last_losses,
                            "decreased": sum(last_losses) / len(last_losses) < sum(first_losses) / len(first_losses)}
log("loss sentinel", METRICS["loss_sentinel"])

# ---------------------------------------------------------------- 3. gates
with torch.no_grad():
    model.eval()
    probe_ids = val_dec[0]["ids"] if val_dec else train_samples[0]["ids"]
    h_on = head(hidden(probe_ids)[-8:])
    with model.disable_adapter():
        h_off = head(hidden(probe_ids)[-8:])
    effect = float((h_on - h_off).abs().max())
log(f"effect gate: max |logit(adapter) - logit(base)| = {effect:.4f}")
ad_acc, ad_conf = with_adapter(True, tool_acc, val_dec)
log(f"held-out next-tool accuracy: base {base_acc:.3f} -> adapter {ad_acc:.3f}")
METRICS["effect_gate"] = {"max_abs_logit_delta": effect, "pass": effect > 1e-3}
METRICS["heldout_tool_acc"].update({"adapter": round(ad_acc, 4), "adapter_confusions": ad_conf})
save_metrics()

ADAPTER = WORK / "adapter" / "main_lora"
METRICS["export"] = export_adapter(ADAPTER)
shutil.rmtree(ADIR, ignore_errors=True)
save_metrics()

# ---------------------------------------------------------------- 5. behaviour check with vLLM + LoRA on the rich fold
del model, base, inner, decoder, lm_head, opt, params
gc.collect()
torch.cuda.empty_cache()
remaining_min = TIME_LIMIT_H * 60 - (time.time() - T0) / 60
A1 = json.loads('{"agent.yaml": "name: swe_tool_selection_agent\\nmodel: gemma-4-31b-it-qat-w4a16-ct\\ninstruction: !include prompts/system.md\\ntools:\\n  - run_command\\n  - read_file\\n  - edit_file\\n  - write_file\\n  - get_status\\n  - submit_patch\\n  - get_code_neighbors\\n  - search_similar_code\\n  - get_code_subgraph\\ngenerate_content_config: !include configs/sampling.yaml\\n", "configs/sampling.yaml": "temperature: 0.2\\ntop_p: 0.95\\nmax_output_tokens: 8192\\nthinking_config:\\n  thinking_budget: 4096\\n  include_thoughts: true\\n", "eval_config.yaml": "# Generation budgets: the community \\"Budget-Fit\\" settings (8 min, 28 calls, 240 s) plus 4 calls of headroom for\\n# graph tools, since this bundle is designed to exercise them.\\nevaluation:\\n  timeout_seconds: 240\\n  max_tool_calls: 32\\n  max_time_minutes: 8\\n  max_turns: 80\\n", "prompts/system.md": "You are an expert software engineer resolving one task in the repository at `/workspace`. Work quickly and precisely, then submit a minimal source-code patch.\\n\\n## Read the task correctly\\nThe first line of the task is usually the **pull-request title**. It names the change to make, for example \\"Fix parsing extra non-body parameter list\\". Treat it as the specification. Pull out its identifiers (backticked names, function, class, module and file names, error strings) and search for those first.\\n\\n## Choose the right tool for each step\\n\\n| Need | Tool | How |\\n|---|---|---|\\n| Find where an identifier or string lives | `run_command` | `git grep -n` on the identifier (exact command below). This is always the first step. If nothing matches, grep distinctive words from the title (error text, option or parameter names). |\\n| See a file\'s outline before reading it | `run_command` | `grep -n \\"def \\\\|class \\" <file>` |\\n| Read code | `read_file` | 60\\u201380-line windows around the grep hit. Never read whole large files. |\\n| Who calls a function, what it calls, or near-duplicate siblings | `get_code_neighbors` | `node` must be an **exact dotted id** copied from code you have seen, e.g. `fastapi.routing.get_request_handler` or `rich.console.Console.print`. The neighbour list has **no direction**: callers and callees are mixed. |\\n| Read a symbol\'s body without knowing its file, or find near-duplicate siblings | `search_similar_code` | `query` must be a dotted id or `Class.method`, never a sentence. Use `k` 2 for FastAPI, 3 elsewhere. Similarity scores near 0.9 carry little meaning, so rank only. |\\n| Check whether 3\\u20138 candidate symbols are connected | `get_code_subgraph` | Pass the exact dotted ids as a list |\\n| Find the existing tests for a function | `run_command` | `git grep -ln` on the function name under `tests/` (exact command below) |\\n| Check remaining budget | `get_status` | Free; use it when unsure how many calls remain |\\n\\nExact search commands (the `|| true` keeps \\"no match\\" from looking like an error):\\n```\\ngit grep -n \\"<identifier>\\" -- \'*.py\' | head -n 40 || true\\ngit grep -ln \\"<function name>\\" -- \'tests/*.py\' | head -n 10 || true\\n```\\n\\n### Graph tool rules\\n- Use a graph tool only **after** you have a concrete symbol id from grep or `read_file` output. Never query the graph with prose or bare short names like `app`, `send` or `__init__`; they resolve to an arbitrary node.\\n- Dotted ids are the module path plus the class chain and the name: `package.module.Class.method`. Test functions look like `tests.test_module.test_name`. FastAPI tutorial files under `docs_src/` appear as top-level modules, such as `dependencies.tutorial008d_an_py310.main`.\\n- The graph does **not** contain `async def` functions, module-level constants, or files that do not exist yet. For these, use `git grep` and `read_file` instead.\\n- Spend at most 3 graph calls per task. If a graph call returns an error or an unrelated node, do not retry it with variations. Fall back to `git grep`.\\n\\n## Workflow\\n1. **Localize** with `git grep` on the title\'s identifiers, then read the relevant window.\\n2. **Expand** only if needed: one graph call on the target symbol for callers or siblings that may need the same change.\\n3. **Edit early.** Make the first `edit_file` change by about tool call 12. Keep `old_string` short and unique, and change only what the task needs.\\n4. **Verify the whole test file.** The grader runs entire test files, so a failure anywhere in the file for the module you changed counts against you. Run it the way the grader does: `python -m pytest tests/test_x.py -q -p no:anyio -o timeout=0`. If a test in that file fails because of your change, fix the code or revert. Never run bare `pytest` or the whole suite.\\n5. **Submit.** Call `submit_patch`, check that `files_changed > 0`, and finish with a one-sentence summary.\\n\\n## Rules\\n- Never create, modify or delete test files (`test_*.py`, `*_test.py`, `tests/`, `conftest.py`) or config files (`pytest.ini`, `pyproject.toml`, `setup.cfg`, `tox.ini`). Those edits are discarded before grading.\\n- `write_file` and `edit_file` work only inside `/workspace`. Create scratch files only with a `run_command` heredoc under `/tmp` (for example `cat > /tmp/repro.py <<\'PY\'` \\u2026 `PY`, then `cd /tmp && python repro.py`), so they never enter the patch.\\n- The environment is offline and all dependencies are installed. Do not run pip.\\n- Do not search outside `/workspace`.\\n- Pre-existing unrelated test failures in other files are expected. Ignore them.\\n- Never finish without a non-empty patch. If time is running out, submit your best partial fix.\\n\\n## Graph decision (write it before your first edit)\\nBefore your first `edit_file`, write exactly one line in your visible reply, in one of these forms:\\n- `GRAPH: call get_code_neighbors <exact dotted id> | callers`\\n- `GRAPH: call search_similar_code <exact dotted id> | siblings`\\n- `GRAPH: skip | <short reason>`\\n\\nWrite `call` only when the function or method you will change is a plain `def` that you located with `git grep` (not `async def`, not module-level code, not a new file), you still need cross-file information (who calls it, or near-duplicate siblings that may need the same change), and at least 10 tool calls remain. Otherwise write `skip` with the reason, for example `GRAPH: skip | async function, not in the graph` or `GRAPH: skip | single-file fix, nothing cross-file`.\\nAfter a `call` line, make that one call next: `get_code_neighbors` with `max_neighbors` 20, or `search_similar_code` with `k` 2 for FastAPI and 3 elsewhere. Then read the most relevant returned caller or sibling before you edit. Build the dotted id from the file path and the qualified name: `rich/text.py` + `Text.wrap` \\u2192 `rich.text.Text.wrap`.\\n"}')
SUB = WORK / "submission"
shutil.rmtree(SUB, ignore_errors=True)
for rel, text in A1.items():
    p = SUB / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    if rel == "agent.yaml":
        text = text.replace("model: gemma-4-31b-it-qat-w4a16-ct\n", "model: gemma-4-31b-it-qat-w4a16-ct\nadapter: main_lora\n")
    p.write_text(text)
shutil.copytree(ADAPTER, SUB / "adapters" / "main_lora")
log("submission bundle:", sorted(str(p.relative_to(SUB)) for p in SUB.rglob("*") if p.is_file()))
if remaining_min < VAL_EVAL_MIN + 25:
    log(f"skipping the vLLM behaviour check: {remaining_min:.0f} min left")
    METRICS["val_adapter"] = {"skipped": True, "minutes_left": round(remaining_min)}
    save_metrics()
else:
    import asyncio, concurrent.futures, logging, yaml, litellm
    from adk_submission import VllmConfig, VllmServer, discover_adapters
    from google.adk.agents.context_cache_config import ContextCacheConfig
    from google.adk.apps._configs import EventsCompactionConfig
    from swegemma.config import ALLOWED_ADAPTER_EXTENSIONS, EvalConfig, build_submission_limits
    from swegemma.evaluate import Evaluator
    from swegemma.models import load_tasks

    litellm.drop_params = True
    for name in ("LiteLLM", "litellm", "httpx", "httpcore", "openai"):
        logging.getLogger(name).setLevel(logging.WARNING)
    adapters = discover_adapters(str(SUB), adapter_extensions=ALLOWED_ADAPTER_EXTENSIONS)
    log("discovered adapters:", list((getattr(adapters, "adapters", None) or {}).keys()))
    cfg = VllmConfig(model=str(SERVE_MODEL), port=8000, host="127.0.0.1", tool_call_parser="gemma4", reasoning_parser="gemma4",
                     default_chat_template_kwargs={"enable_thinking": True}, max_model_len=32768, dtype="bfloat16",
                     gpu_memory_utilization=0.80, enable_auto_tool_choice=True, enable_lora=True, max_loras=1, max_lora_rank=LORA_R,
                     tensor_parallel_size=min(4, ngpu), startup_timeout=60 * 30)
    server = VllmServer(cfg, adapter_manifest=adapters)
    server.start()
    models = server.create_model_registry(aliases=[COMPETITION_MODEL], model_prefix="openai/", api_key="EMPTY")
    tasks = load_tasks(DATA_DIR / "tasks.jsonl")
    val_ids = [t.instance_id for t in tasks if t.repo == "Textualize/rich"]
    ev = yaml.safe_load((SUB / "eval_config.yaml").read_text())["evaluation"]
    limits, gen_constraints = build_submission_limits()
    ec = EvalConfig(tasks_path=DATA_DIR / "tasks.jsonl", snapshots_dir=DATA_DIR / "snapshots", results_dir=WORK / "runs" / "val_adapter",
                    submission_dir=SUB, models=models, sandbox="subprocess", timeout_seconds=int(ev["timeout_seconds"]),
                    verification_timeout_seconds=300, max_time_minutes=float(ev["max_time_minutes"]), max_tool_calls=int(ev["max_tool_calls"]),
                    max_turns=int(ev["max_turns"]), limits=limits, generation_constraints=gen_constraints, adapter_manifest=adapters,
                    context_cache_config=ContextCacheConfig(min_tokens=2048, ttl_seconds=1800, cache_intervals=10),
                    events_compaction_config=EventsCompactionConfig(compaction_interval=5, overlap_size=2, token_threshold=14336, event_retention_size=5),
                    graph_dir=str(DATA_DIR / "graphs"), embeddings_dir=str(DATA_DIR / "embeddings"), wheels_dir=DATA_DIR / "wheels",
                    verbose=False, task_ids=val_ids, concurrency=2, display_mode="quiet")

    def run_sync(fn):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(fn())
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(lambda: asyncio.run(fn())).result()

    t = time.time()
    res = run_sync(Evaluator(ec).run)
    rows = res.task_results
    base_rows = jl(SAMPLING / "runs" / "val_base" / "task_results.jsonl") if (SAMPLING / "runs" / "val_base" / "task_results.jsonl").exists() else []
    base_res = {r["instance_id"]: bool(r["resolved"]) for r in base_rows}
    ad_res = {r.instance_id: bool(r.resolved) for r in rows}
    both = sorted(set(base_res) & set(ad_res))
    b01 = sum(1 for i in both if not base_res[i] and ad_res[i])
    b10 = sum(1 for i in both if base_res[i] and not ad_res[i])
    METRICS["val_adapter"] = {"tasks": len(rows), "resolved": sum(ad_res.values()), "base_resolved": sum(base_res.values()),
                              "paired_tasks": len(both), "gained": b01, "lost": b10, "minutes": round((time.time() - t) / 60, 1),
                              "median_tool_calls": sorted(int(r.tool_calls or 0) for r in rows)[len(rows) // 2] if rows else None}
    log("VAL ADAPTER", METRICS["val_adapter"])
    server.stop()
    save_metrics()
log("done in", round((time.time() - T0) / 3600, 2), "h")
