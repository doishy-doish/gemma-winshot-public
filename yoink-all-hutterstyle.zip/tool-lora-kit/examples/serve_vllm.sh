#!/usr/bin/env bash
# Serve the W4A16 Gemma 4 base plus this dataset's LoRA adapter(s) with vLLM, using the same settings the
# swegemma scorer uses (HARNESS_README L163-L169, L202, L208):
#   tensor_parallel_size=4 on 4x L4, gpu_memory_utilization=0.90, max_model_len=32768,
#   scheduler_reserve_full_isl=False, enable_auto_tool_choice + tool_call_parser gemma4 + reasoning_parser gemma4,
#   reasoning_config <|channel> ... <channel|>, enable_lora, max_loras=len(adapters), max_lora_rank=max(r).
# The flag spellings are the ones the author's trajectory generator passed to vLLM 0.19.1 on single-GPU Colab runs
# (12B and 31B, TP=1, no LoRA); their vllm.log lists the non-LoRA flags below as non-default args (author-side
# logs, not shipped). VERIFY: --tensor-parallel-size 4, --enable-lora, --max-loras, --max-lora-rank and
# --lora-modules were not exercised by those runs.
# --default-chat-template-kwargs is a community setting the generator adds; it is NOT among the scorer settings in
# HARNESS_README L163-L170. swegemma sets enable_thinking per request from thinking_config (L148), so it matters
# only for clients that send no chat_template_kwargs [inferred]. Set NO_THINKING_KWARGS=1 to leave it out.
#
# Usage: BASE=/path/to/gemma-4-31b-it-qat-w4a16-ct DATA=/kaggle/input/gemma4-31b-swe-agent-lora bash serve_vllm.sh
# Optional: TP=1 for a single large GPU, WITH_TOOL_LORA=1 to also serve adapters/tool_lora (opt-in, only if it
# exists), NO_THINKING_KWARGS=1, PORT=8000.
set -euo pipefail

BASE="${BASE:?set BASE to the gemma-4-31b-it-qat-w4a16-ct checkpoint dir (not bundled in this dataset)}"
DATA="${DATA:-/kaggle/input/gemma4-31b-swe-agent-lora}"   # VERIFY: the slug once the dataset exists
SERVED="${SERVED:-gemma-4-31b-it-qat-w4a16-ct}"            # the registry alias the harness serves (L202)
PORT="${PORT:-8000}"
TP="${TP:-4}"                                               # 4x L4 on the scorer (L164)

LORA_ARGS=(main_lora="$DATA/adapters/main_lora")
MAX_LORAS=1
if [ "${WITH_TOOL_LORA:-0}" = 1 ]; then
  LORA_ARGS+=(tool_lora="$DATA/adapters/tool_lora")
  MAX_LORAS=2
fi

# max_lora_rank: the harness takes max(detected r) (L169, L208). adk_submission rounds it up to a vLLM bucket
# (1, 8, 16, 32, 64, 128, ...), which is 16 for this recipe's r=16 adapters.
MAX_LORA_RANK="${MAX_LORA_RANK:-16}"

THINKING_ARGS=(--default-chat-template-kwargs '{"enable_thinking": true}')   # community setting, see above
if [ "${NO_THINKING_KWARGS:-0}" = 1 ]; then
  THINKING_ARGS=()
fi

exec python3 -m vllm.entrypoints.openai.api_server \
  --model "$BASE" \
  --served-model-name "$SERVED" \
  --host 127.0.0.1 --port "$PORT" \
  --dtype bfloat16 \
  --max-model-len 32768 \
  --tensor-parallel-size "$TP" \
  --gpu-memory-utilization 0.90 \
  --no-scheduler-reserve-full-isl \
  --enable-auto-tool-choice --tool-call-parser gemma4 \
  --reasoning-parser gemma4 \
  --reasoning-config '{"reasoning_start_str": "<|channel>", "reasoning_end_str": "<channel|>"}' \
  "${THINKING_ARGS[@]}" \
  --enable-lora --max-loras "$MAX_LORAS" --max-lora-rank "$MAX_LORA_RANK" \
  --lora-modules "${LORA_ARGS[@]}"

# For gemma-4-12b-it-qat-w4a16-ct the harness also passes (L170):
#   --hf-overrides '{"architectures": ["Gemma4ForCausalLM"], "model_type": "gemma4"}'
# A 12B adapter needs the Gemma4ForCausalLM module layout. The 31B adapters in this dataset do NOT fit 12B.
# VERIFY: an end-to-end LoRA serve of main_lora on 4x L4 (TP=4). LoRA support on Gemma4ForConditionalGeneration in
# the competition vLLM 0.19.1 wheel was verified on a Colab VM; this exact adapter has not been served yet.
