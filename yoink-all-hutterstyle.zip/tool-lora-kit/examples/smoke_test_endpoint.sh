#!/usr/bin/env bash
# Smoke-test a server started by serve_vllm.sh: are the LoRA names served, and does a tool call come back as a
# structured tool_calls entry (gemma4 tool parser), not as raw "<|tool_call>" text?
set -euo pipefail
URL="${URL:-http://127.0.0.1:8000/v1}"
MODEL="${MODEL:-main_lora}"   # the harness routes an agent with `adapter: main_lora` to openai/main_lora (L208)

curl -fsS "$URL/models" | python3 -c 'import json,sys; print("served:", [m["id"] for m in json.load(sys.stdin)["data"]])'

curl -fsS "$URL/chat/completions" -H 'Content-Type: application/json' -d @- <<JSON | python3 -c '
import json, sys
r = json.load(sys.stdin)["choices"][0]
msg = r["message"]
print("finish_reason:", r.get("finish_reason"))
print("tool_calls:", json.dumps(msg.get("tool_calls"), indent=1)[:800])
print("content starts:", (msg.get("content") or "")[:200])
assert msg.get("tool_calls"), "no structured tool call: check --tool-call-parser gemma4 and the adapter"
'
{
  "model": "$MODEL",
  "max_tokens": 1024,
  "temperature": 0.2,
  "messages": [
    {"role": "system", "content": "You fix bugs in the repository at /workspace. Always answer with a tool call."},
    {"role": "user", "content": "Find where the function parse_header is defined."}
  ],
  "tools": [{
    "type": "function",
    "function": {
      "name": "run_command",
      "description": "Run a bash command in /workspace and return stdout, stderr and the exit code.",
      "parameters": {"type": "object", "properties": {"command": {"type": "string"}}, "required": ["command"]}
    }
  }],
  "chat_template_kwargs": {"enable_thinking": true},
  "thinking_token_budget": 512
}
JSON
# VERIFY: thinking_token_budget is the extra_body field swegemma forwards for thinking_config.thinking_budget (L148).
