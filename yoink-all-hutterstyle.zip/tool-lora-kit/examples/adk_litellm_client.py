#!/usr/bin/env python3
"""Run a coder + analyzer ADK multi-agent against the vLLM endpoint from serve_vllm.sh, one LoRA per agent.

This mirrors what the swegemma harness builds from a declarative bundle (HARNESS_README L202, L208): an agent
with `adapter: <name>` gets LiteLlm(model="openai/<name>", api_base="http://127.0.0.1:8000/v1"). The 9 swegemma
tools exist only inside the harness, so this demo gives both agents two small local tools over the directory
passed with --repo. Both tools are read-only: they never write, delete or execute anything in that directory.

Requires: pip install "google-adk==1.36.1" litellm   (VERIFY: 1.36.1 is what the Colab VM used)

Usage:
  python3 adk_litellm_client.py --list-models                      # are the names this run will use served?
  python3 adk_litellm_client.py --dry-run --repo . --task "..."    # build the agents, print them, no network
  python3 adk_litellm_client.py --repo /path/to/checkout --task "Fix parsing of extra non-body parameter list"
      [--coder-model main_lora] [--analyzer-model gemma-4-31b-it-qat-w4a16-ct | tool_lora] [--max-llm-calls 30]

The analyzer runs on the base alias by default. tool_lora is opt-in: pass --analyzer-model tool_lora only
when serve_vllm.sh was started with WITH_TOOL_LORA=1 and the dataset ships adapters/tool_lora.
"""
import argparse
import asyncio
import json
import os
import re
import sys
import urllib.request

BASE_URL = os.environ.get("VLLM_BASE_URL", "http://127.0.0.1:8000/v1")
BASE_ALIAS = "gemma-4-31b-it-qat-w4a16-ct"

ANALYZER_PROMPT = """You are code_analyzer, a read-only localization specialist. You never modify files.
The task is:

{problem_description}

Use grep_repo with identifiers from the task, then read_file around the hits (at most 150 lines per call).
Use at most 6 tool calls, then answer in at most 200 words:
LOCATION: path:start-end (function or class)
ROOT CAUSE: one or two sentences
FIX PLAN: the concrete change
CONFIDENCE: high, medium or low"""

CODER_PROMPT = """You are an expert software engineer. First call code_analyzer once with the task title.
Verify its LOCATION with read_file, then reply with the exact unified diff you would apply and a
one-sentence justification. This demo has no write tools, so describe the edit instead of making it."""


def make_tools(repo):
    root = os.path.realpath(repo)

    def resolve(path):
        full = os.path.realpath(os.path.join(root, str(path).lstrip("/")))
        if full != root and not full.startswith(root + os.sep):
            raise ValueError("path escapes the repository")
        return full

    def read_file(filepath: str, start_line: int = 1, end_line: int = 150) -> dict:
        """Read lines start_line..end_line (1-based, inclusive, at most 150 lines) of a repository file."""
        try:
            with open(resolve(filepath), encoding="utf-8", errors="replace") as handle:
                lines = handle.read().splitlines()
        except (OSError, ValueError) as exc:
            return {"status": "error", "error_type": type(exc).__name__, "error_message": str(exc)}
        start = max(1, int(start_line))
        end = min(len(lines), int(end_line), start + 149)
        text = "\n".join("%d: %s" % (i, lines[i - 1]) for i in range(start, end + 1))[:10000]
        return {"status": "ok", "filepath": filepath, "content": text, "start_line": start, "end_line": end,
                "total_lines": len(lines), "is_truncated": end < len(lines)}

    def grep_repo(pattern: str, max_hits: int = 40) -> dict:
        """Search the repository's Python files for a regular expression; returns 'path:line: text' hits."""
        try:
            regex = re.compile(pattern)
        except re.error:
            regex = re.compile(re.escape(pattern))
        hits = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in ("__pycache__", "node_modules")]
            for name in filenames:
                if not name.endswith(".py"):
                    continue
                path = os.path.join(dirpath, name)
                try:
                    with open(path, encoding="utf-8", errors="replace") as handle:
                        for number, line in enumerate(handle, 1):
                            if regex.search(line):
                                hits.append("%s:%d: %s" % (os.path.relpath(path, root), number, line.strip()[:120]))
                                if len(hits) >= int(max_hits):
                                    return {"status": "ok", "hits": hits, "is_truncated": True}
                except OSError:
                    continue
        return {"status": "ok", "hits": hits, "is_truncated": False}

    return read_file, grep_repo


def vllm_model(name, thinking_budget):
    """LiteLlm bound to one served name: the base alias or a LoRA name from --lora-modules."""
    from google.adk.models.lite_llm import LiteLlm
    # vLLM-specific request fields travel in extra_body. swegemma translates thinking_config.thinking_budget
    # into the same two fields (L148). VERIFY with your litellm version that extra_body is forwarded unchanged.
    return LiteLlm(model="openai/" + name, api_base=BASE_URL, api_key="EMPTY",
                   extra_body={"chat_template_kwargs": {"enable_thinking": thinking_budget > 0},
                               "thinking_token_budget": thinking_budget})


def build_agents(args):
    from google.adk.agents import LlmAgent
    from google.adk.tools.agent_tool import AgentTool
    from google.genai import types
    read_file, grep_repo = make_tools(args.repo)
    analyzer = LlmAgent(
        name="code_analyzer",
        model=vllm_model(args.analyzer_model, 1024),
        description="Read-only code navigator: returns LOCATION, ROOT CAUSE and FIX PLAN for the task.",
        instruction=ANALYZER_PROMPT,
        tools=[read_file, grep_repo],
        generate_content_config=types.GenerateContentConfig(temperature=0.2, top_p=0.95, max_output_tokens=6144, seed=42),
    )
    coder = LlmAgent(
        name="swe_coder",
        model=vllm_model(args.coder_model, 4096),
        description="Software engineer that turns the analyzer's plan into a minimal diff.",
        instruction=CODER_PROMPT,
        tools=[read_file, AgentTool(agent=analyzer, skip_summarization=True)],
        generate_content_config=types.GenerateContentConfig(temperature=0.2, top_p=0.95, max_output_tokens=8192, seed=42),
    )
    return coder, analyzer


def list_models(args):
    """Check that every model name this run would send (coder, analyzer) is served."""
    with urllib.request.urlopen(BASE_URL + "/models", timeout=10) as resp:
        ids = [m["id"] for m in json.load(resp)["data"]]
    print("served model names:", ids)
    missing = 0
    for role, want in (("coder", args.coder_model), ("analyzer", args.analyzer_model)):
        ok = want in ids
        missing += not ok
        print("  %-8s %-28s %s" % (role, want, "OK" if ok else "MISSING (check --served-model-name / --lora-modules)"))
    return 1 if missing else 0


async def run(args):
    from google.adk.agents.run_config import RunConfig
    from google.adk.runners import InMemoryRunner
    from google.genai import types
    coder, _ = build_agents(args)
    runner = InMemoryRunner(agent=coder, app_name="swe_demo")
    # Same state key the harness sets (L297-L301); the analyzer's instruction templates it.
    session = await runner.session_service.create_session(app_name="swe_demo", user_id="demo",
                                                          state={"problem_description": args.task})
    message = types.Content(role="user", parts=[types.Part(text="Problem Statement:\n" + args.task)])
    async for event in runner.run_async(user_id="demo", session_id=session.id, new_message=message,
                                        run_config=RunConfig(max_llm_calls=args.max_llm_calls)):
        for part in (event.content.parts if event.content and event.content.parts else []):
            if getattr(part, "function_call", None):
                print("[%s] call %s %s" % (event.author, part.function_call.name, json.dumps(part.function_call.args)[:200]))
            elif getattr(part, "function_response", None):
                print("[%s] result %s" % (event.author, str(part.function_response.response)[:200]))
            elif part.text and not getattr(part, "thought", False):
                print("[%s] %s" % (event.author, part.text.strip()[:2000]))


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--repo", default=".")
    ap.add_argument("--task", default="")
    ap.add_argument("--coder-model", default="main_lora", help="LoRA name or the base alias")
    ap.add_argument("--analyzer-model", default=BASE_ALIAS,
                    help="the base alias (default), or tool_lora if it is trained and served (WITH_TOOL_LORA=1)")
    ap.add_argument("--max-llm-calls", type=int, default=30)
    ap.add_argument("--list-models", action="store_true")
    ap.add_argument("--dry-run", action="store_true", help="build and print the agents without calling the server")
    args = ap.parse_args()
    if args.list_models:
        return list_models(args)
    if args.dry_run:
        coder, analyzer = build_agents(args)
        for agent in (coder, analyzer):
            print(agent.name, "->", agent.model.model, "| tools:", [getattr(t, "name", getattr(t, "__name__", t)) for t in agent.tools])
        return 0
    if not args.task:
        ap.error("--task is required unless --list-models or --dry-run")
    asyncio.run(run(args))
    return 0


if __name__ == "__main__":
    sys.exit(main())
