# Examples: serving the LoRA and deploying it in an ADK multi-agent setup

| File | What it shows | Verified so far |
|---|---|---|
| `serve_vllm.sh` | vLLM with the scorer's settings plus `--enable-lora --lora-modules main_lora=...` (and optionally `tool_lora`) | The non-LoRA flags match the non-default args that the author's single-GPU Colab runs logged with vLLM 0.19.1 (12B and 31B, TP=1, no LoRA). `--tensor-parallel-size 4` and the LoRA flags were not part of those runs: VERIFY. A LoRA serve of this exact adapter is still VERIFY. |
| `smoke_test_endpoint.sh` | `/v1/models` lists the LoRA names, and a tool call comes back as structured `tool_calls` (gemma4 parser) | VERIFY (needs a running server) |
| `adk_multi_agent/` | Declarative bundle for the swegemma harness: one base model, the coder on `main_lora`, the analyzer on the base model | The author's static checker (not shipped) passes on this directory plus a synthetic `adapters/main_lora` in the 31B key layout. A harness run is VERIFY. |
| `adk_litellm_client.py` | The same topology in Python: google-adk `LlmAgent` + `AgentTool` + `LiteLlm` against the vLLM endpoint | `--dry-run` with google-adk 1.36.1 builds both agents: `openai/main_lora` for the coder and `openai/gemma-4-31b-it-qat-w4a16-ct` for the analyzer. The dry run only constructs the agents, so `{problem_description}` templating and a live call are VERIFY. By code inspection, the two demo tools are read-only and resolve paths inside `--repo`. |

## How the harness maps the declarative bundle to models (HARNESS_README L202, L208)

    agent.yaml          model: gemma-4-31b-it-qat-w4a16-ct   adapter: main_lora
      -> vLLM --lora-modules main_lora=<bundle>/adapters/main_lora
      -> LiteLlm(model="openai/main_lora", api_base="http://127.0.0.1:8000/v1")
    code_analyzer.yaml  model: gemma-4-31b-it-qat-w4a16-ct   (no adapter line)
      -> LiteLlm(model="openai/gemma-4-31b-it-qat-w4a16-ct", ...)
    (opt-in: with `adapter: tool_lora` and adapters/tool_lora shipped, the analyzer gets openai/tool_lora)

Rules that apply to every deployment:
- **One base model:** every agent declares the same base alias (L187-L189). Adapters can differ per agent (L205).
- **Adapter files:** `adapters/<name>/` holds exactly `adapter_config.json` and `adapter_model.safetensors`, bf16, `r <= 128`.
- **No unused adapters:** every adapter dir is loaded even if no agent references it (L208), so ship only the ones in use.
- **Validate in the topology you ship:** `main_lora` is trained on single-coder trajectories (9 tools, no skills, no agent_tool),
  so a bundle like this one is outside its training distribution until a paired eval shows otherwise.
- **Read-only analyzer:** the analyzer is an `agent_tool` with `skip_summarization: true` and no write or shell tools (L689-L690). Its
  instruction templates `{problem_description}`, because an agent_tool does not see the root agent's conversation. The root also
  keeps a `## Task` copy, because ADK compaction can summarize the first user message (L568-L574) [inferred].

## Assembling `adk_multi_agent/` into a submission

Run from the dataset's root directory (in a notebook, the attached dataset under `/kaggle/input/`). `OUT` is a new, empty
working directory:

    OUT=/kaggle/working/submission
    mkdir -p "$OUT/adapters"
    cp -r examples/adk_multi_agent/. "$OUT/"
    cp -r adapters/main_lora "$OUT/adapters/"
    (cd "$OUT" && zip -qr ../submission.zip .)

`agent.yaml` references `adapters/main_lora`, so ship that directory, or delete the `adapter: main_lora` line to run the coder on
the base model: an adapter name without its directory cannot be routed (L206-L208) [inferred]. A second adapter for the analyzer is
opt-in: add `adapter: tool_lora` to `code_analyzer.yaml` and copy `adapters/tool_lora` only if that adapter exists.

The skill scripts match the author's lean bundle. Here the py-locate and test-scout SKILL.md describe only `run_skill_script`,
because in this topology those skills belong to the analyzer, which has no shell. `repro-verify/scripts/install.py` embeds
`pyloc.py` and `tests.py` and checks every helper against a SHA-256 recorded when it was built, so after editing any skill script
update its `SOURCES` and `SHA256` entries (the author's generator for it is not part of this dataset).
