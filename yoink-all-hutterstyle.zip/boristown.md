# scratch/gemma/yoink/boristown-pull.json v23 cells=15

# Gemma 4 Flagship (`31B-QAT`) V23: Fail-Fast Stop-Loss + High-ROI Overtime Reallocation + 5 Lean Tools + `thinking_budget=2048` + Single-Shot `submit_patch` & 2-Pace `/dev/shm` Clock (`<540 / >=540`)

**Gemma 4 旗舰冲榜实战（V23 止损快退 + 高 ROI 加班 + 5 精简工具版）：融合 V21 60 题实机取证、V22 4 题冒烟验证与 ARC-AGI 3 动力学分析 —— 压低无解/迷路题耗时（Fail-Fast 止损），将节省的算力与时间精准倾斜给有明确复现断言的高 ROI 难题（最多 3 轮迭代验证），同时根除 `write_file` 滥用、`submit_patch` 43–51 轮死循环与 `100–230s` 单轮长思考黑洞！**

---

### V21 (`21/60`, LB `0.15–0.17`) $	o$ V22 冒烟验证 $	o$ V23 完整 60 题 (`30 Public + 30 Private`) 升级清单

1. **5 精简工具（移除 `write_file`）**：彻底消除 V21 中 `102` 次仓库内新建 `repro.py` 污补丁及 `fastapi_15661` 连续 8 轮缺失 `filepath` 的 `0B` 死循环（V22 冒烟实测 `fastapi_15661` 正常产出 `2,101B` 补丁、`rich_4075` 转 PASS）。
2. **收紧思考与输出上限（`thinking_budget: 4096 -> 2048`, `max_output_tokens: 8192 -> 4096`）**：砍掉 V21 中 49 次单轮 `>=40s`（最高 `230.2s` / 合计 `57.9m` = 20.8% GPU 耗时）的过度思考黑洞。
3. **修复 `submit_patch` 无限循环**：明确要求调用 `submit_patch` 一次，收到 `status: ok` 后立刻停止调用工具并输出一句纯文本总结结束会话（V22 冒烟 `submit_calls/task` 全部 `<= 1`）。
4. **Fail-Fast 止损 + High-ROI 加班重分配（V23 核心策略）**：
   - 针对 V21 实测 `FAIL (300.1s) > PASS (238.0s)` 的倒挂浪费：
     - **Call 10 定位止损门**：若 Call 10 仍无法锁定明确根因，禁止空耗剩余 26 次调用，在 Call 10–12 落最稳妥最小候选补丁并于 Call 14 前验证提交，释放 3–5 分钟给后续高价值题。
     - **重复报错止损**：连续 2 次修改产生相同报错且无新线索时立即停止空转，保留最干净的可编译非空 diff 直接提交。
     - **High-ROI 有条件加班（最多 3 轮）**：仅当存在明确可复现的 `AssertionError`/单测失败且免费 `get_status()` 确认 `time_seconds_remaining > 120`、`tool_calls_remaining >= 6`、`CLOCK_MIN < 540` 时，最多投入 3 轮精准迭代修复边界条件。
5. **保留两档全局时钟（`CLOCK_MIN <540 / >=540`）与 `36c / 7.5m / 80t / 240s` 硬护栏 + Step 6 `compaction_interval=5` 1:1 官方对齐**。


---

---
## Step 1: Hardware Diagnostics, `vLLM (tp=4)` Environment Flags & Offline Wheelhouse Installation
**EN**: Following the official `adk_submission.VllmServer` (`tp=4`) startup pattern (`ziadsamer/fork-of-generation-all-shards-gpu`), we configure `VLLM_WORKER_MULTIPROC_METHOD=spawn`, `VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1`, and `VLLM_ENGINE_READY_TIMEOUT_S=1200` **before** importing `torch`, install the offline competition wheelhouse, and initialize both our 120-task competition model and 60-task live evaluation benchmark.  
**CN**: 第一步在导入 `torch` 前设置 `vLLM 0.19.1` 四卡张量并行（`tp=4`）必需的环境变量，离线安装官方 `wheelhouse`，并初始化 120 题全局竞争模型与 60 题实机验证基准。


---

```python
# ==============================================================================
# Step 1: Environment Setup, vLLM (tp=4) Flags, Offline Wheelhouse & Competition Model
# 第一步：环境初始化、vLLM 四卡并行环境变量配置、离线轮子安装与 120 题竞争建模
# ==============================================================================
import glob
import hashlib
import importlib
import json
import math
import os
import platform
import random
import re
import shutil
import subprocess
import sys
import time
import zipfile
from collections import Counter, defaultdict
from pathlib import Path, PurePosixPath

import numpy as np

# [EN] Critical vLLM (tp=4) & ADK environment variables (must be set before wheelhouse install & torch.cuda init)
# [CN] 启动 4x-L4 vLLM (tensor_parallel_size=4) 必需的底层环境变量
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["TRANSFORMERS_NO_ADVISORY_WARNINGS"] = "1"
os.environ["TRANSFORMERS_NO_TF"] = "1"
os.environ["TRANSFORMERS_NO_FLAX"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
os.environ["VLLM_WORKER_MULTIPROC_METHOD"] = "spawn"
os.environ["VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS"] = "1"
os.environ["VLLM_ENGINE_READY_TIMEOUT_S"] = "1200"
os.environ["VLLM_NO_USAGE_STATS"] = "1"
os.environ["OTEL_SDK_DISABLED"] = "true"
os.environ["LITELLM_LOCAL_MODEL_COST_MAP"] = "True"
os.environ["OPENAI_API_KEY"] = "EMPTY"
os.environ["LOCAL_API_KEY"] = "EMPTY"

IS_KAGGLE = Path("/kaggle/working").is_dir()
IS_COMPETITION_RERUN = os.environ.get("KAGGLE_IS_COMPETITION_RERUN", "").strip().lower() in ("1", "true", "yes")
WORKING_DIR = Path("/kaggle/working") if IS_KAGGLE else Path("kaggle_working_04")
WORKING_DIR.mkdir(parents=True, exist_ok=True)
TMP_BUILD_DIR = Path("/tmp/swegemma_v18_build") if IS_KAGGLE else (WORKING_DIR / "_tmp_v18_build")
TMP_BUILD_DIR.mkdir(parents=True, exist_ok=True)

# [EN] Install offline competition wheelhouse on Kaggle BEFORE importing torch / google.adk / swegemma / adk_submission
# [CN] 在 Kaggle 环境下必须在导入 torch / google.adk 之前首先离线安装官方 wheelhouse
WHEELHOUSE_CANDIDATES = [
    Path("/kaggle/input/datasets/metric/gemma-4-developer-agent-wheelhouse"),
    Path("/kaggle/input/gemma-4-developer-agent-wheelhouse"),
]
wheelhouse_dir = next((p for p in WHEELHOUSE_CANDIDATES if p.is_dir()), None)
if IS_KAGGLE and wheelhouse_dir is not None:
    for pth in glob.glob("/usr/local/lib/python*/dist-packages/*cutlass*.pth") + glob.glob("/usr/local/lib/python*/site-packages/*cutlass*.pth"):
        try:
    
```

---
## Step 2: Compact 6-Tool Prompt (`4.8 KB`) + Smooth 2-Pace `/dev/shm` Clock (`<540 / >=540`) + `36c / 7.5m / 240s` Config & Immediate `submission.zip`
**EN**: Building directly on V20's live `60`-task forensic log (`21/60`, `52/60` compaction hits, `9` premature `28`-call `BudgetExceeded` kills), V21 delivers four precision upgrades in Step 2:
1. **`-52%` Compact Action-Focused System Prompt (`10,101 -> 4,804` chars)**: Cuts system prompt volume by more than half inside the `14,336`-token ADK context window and enforces strict bounded `read_file` slices (`start_line`/`end_line`, 40–90 lines max) plus an early mandatory first edit (Pace 1: Calls 7–10, hard stop Call 12; Pace 2: Call 6).
2. **Smooth 2-Pace Dynamic Time (`CLOCK_MIN < 540` vs `>= 540`) + Free `get_status()` ROI**: Uses a strictly non-negative `/dev/shm/.t0` probe always chained with Call 1 `git grep` / `sed -n` (`0` wasted turns), preserves Fast-Exit Surplus Donation + up to 2 Conditional Overtime retries (`time_seconds_remaining > 120`), and shifts to rapid single-check conservation after `540` min (`9.0h`) with zero blind unverified commits.
3. **Competition Cap Expansion (`max_tool_calls: 28 -> 36`, `timeout_seconds: 180 -> 240`, `max_time_minutes: 7.5`, `max_turns: 80`)**: Eliminates premature `BudgetExceeded` kills before editing while keeping Phase-2 whole-file verification safe (`240s`) and trapping infinite-loop agent commands via `timeout 20 python3 -c`.
4. **Scope-Aligned 6 Lean Tools (`edit_file`, repo-only `write_file`, `run_command` with `|| true` grep, `get_status`, `submit_patch`)**: Clean separation of concerns without brittle `/tmp` path traversal errors.  
**CN**: 第二步直接基于 V20 实机 `60` 题诊断升级为 **V21 精简动态控时方案**：将提示词大幅瘦身 `-52%`（`4.8 KB`）并强制局部切片读取以防止 `14K` 摘要失忆；保留并加固 `/dev/shm/.t0` 非负全球时钟探测与零费 `get_status()` 动态超池策略（`<540m` 正常超池与有条件 2 次重试，`>=540m` 切入快速单检保底提交）；同步将单题上限放宽至 `36 calls / 7.5 min / 240s` 消除编辑前 `BudgetExceeded` 误杀！

---

```python
# ==============================================================================
# Step 2: V21 Compact 6-Tool Configs (-52% Prompt) + 2-Pace /dev/shm Clock (<540/>=540) + 36c/7.5m/240s & Immediate submission.zip
# 第二步：V21 精简 6 工具配置（提示词体积 -52%）+ 两档动态控时（CLOCK_MIN <540 / >=540 + get_status）+ 36c/7.5m/240s 配额与即时打包
# ==============================================================================
ADAPTER_NAME = "surgical_top12_lora"
ATTACH_SURGICAL_LORA_IN_SUBMISSION = False  # [EN] False on 31B for 100% native W4A16 speed; set True on E4B small-model track!

_adapter_line = f"adapter: {ADAPTER_NAME}\n" if ATTACH_SURGICAL_LORA_IN_SUBMISSION else ""
AGENT_CONFIG_YAML = f"""name: swe_agent
model: {TARGET_MODEL}
{_adapter_line}instruction: !include prompts/system.md
tools:
  - run_command
  - read_file
  - edit_file
  - get_status
  - submit_patch
generate_content_config: !include configs/sampling.yaml
"""

SAMPLING_CONFIG_YAML = """temperature: 0.2
top_p: 0.95
max_output_tokens: 4096
thinking_config:
  thinking_budget: 2048
  include_thoughts: true
"""

EVAL_CONFIG_YAML = """evaluation:
  timeout_seconds: 240
  max_tool_calls: 36
  max_time_minutes: 7.5
  max_turns: 80
"""

# [EN] V23 Asymmetric Dynamic Time Prompt: Fail-Fast Stop-Loss + High-ROI Overtime + 5 Lean Tools + Single-Shot submit_patch
SYSTEM_PROMPT_MD = """You are an expert autonomous software engineer resolving a GitHub issue in a Python repository cleanly and decisively. Your changes are collected via `git diff` and graded by hidden tests written from the issue specification.

## Core Rules & Asymmetric Dynamic Time Budget (`36` Calls / `7.5` Min + `/dev/shm` Clock)
- **Zero Code Echoing & Strict Bounded Reads**: Keep reasoning concise (1-3 short sentences stating the next check or edit; NEVER paste or summarize code you read). NEVER call `read_file` without `start_line` and `end_line` (40-90 lines max per call) — unbounded reads fill the 14K context window and trigger compaction amnesia.
- **2-Pace Global Clock (`CLOCK_MIN`) + Fail-Fast Stop-Loss & High-ROI Overtime**:
  - **Call 1 Clock + Locate Combined (Zero Extra Calls)**: In your VERY FIRST `run_command`, ALWAYS prepend the clock probe AND chain your first `git grep` or `sed -n` slice right after `;` (NEVER run the clock probe alone):
    `[ -s /dev/shm/.t0 ] || date +%s > /dev/shm/.t0 2>/dev/null; t0=$(cat /dev/shm/.t0 2>/dev/null); now=$(date +%s); [ "$t0" -gt 0 ] 2>/dev/null && [ "$now" -ge "$t0" ] && echo CLOCK_MIN=$(( (now - t0) / 60 )) || 
```

---
## Step 3: Distilling V17's `18` Authentic `4x-L4` Winning Trajectories (`rich_3521`, `rich_2725`, `fastapi_14360`, `requests_6644`, `fastapi_9753`) for 5-Tool Surgical Action-Head LoRA
**EN**: How does V18 further refine the LoRA SFT dataset over V17?
1. **Strict 5-Tool Hygiene (`0` `write_file` Scratch Calls, `0` `/workspace/` Prefixes)**:
   - Calibrates exclusively on clean 5-tool (`run_command`, `read_file`, `edit_file`, `get_status`, `submit_patch`) trajectories distilled from V17's `18` live `4x-L4` PASS winners (including `rich_3521` newly solved in V17 Overtime, `rich_2725`, `fastapi_14360`, `requests_6644`, `fastapi_9753`, `fastapi_14301`, `rich_3905`, `fastapi_15589`).
2. **Action-Span Token Weighting (`1.5x` on `<|tool_call>`)**: Focuses gradient updates on clean tool-call syntax rather than over-constraining `<|channel>thought` reasoning!  
**CN**: 第三步将 LoRA 蒸馏语料升级为 V17 实机满分通关的 **`18` 条真实轨迹**（含 V17 新攻克的 `rich_3521`），严格对齐 **5 极简工具集**（剔除一切 `write_file` 与 `/workspace/` 路径负向模式）！


---

```python
# ==============================================================================
# Step 3: V17 18-Winner Trajectory Distillation & 5-Tool Causality SFT Curation
# 第三步：V17 实机 18 题通关轨迹蒸馏与 5 极简工具因果门禁筛选
# ==============================================================================
MAX_SEQ_LENGTH = 7168
TRAIN_WINDOW_TOKENS = 1536
MAX_TRAIN_SAMPLES = 8        # 2 balanced optimizer steps x 4 SWE stages
MAX_VAL_SAMPLES = 4          # 4 held-out validation steps (1 per stage)

STAGE_QUOTAS = {
    "edit": 2,
    "submit": 2,
    "read": 2,
    "command": 2,
}

KIT_CANDIDATES = [
    Path("/kaggle/input/datasets/dmitriigluzdov/gemma-4-serving-and-lora-verification-kit"),
    Path("/kaggle/input/gemma-4-serving-and-lora-verification-kit"),
    Path("docs/community_oct29/kits/dmitrii"),
]
kit_dir = next((p for p in KIT_CANDIDATES if p.is_dir()), None)

LEAN6_TOOLS = {"run_command", "read_file", "edit_file", "write_file", "get_status", "submit_patch"}
BROKEN_GRAPH_TOOLS = {"search_similar_code", "get_code_neighbors", "get_code_subgraph"}
TOOL_CALL_START_TOKEN_ID = 48  # Gemma 4 exact token ID for `<|tool_call>`


def verify_v18_surgical_step(prefix_text: str, completion_text: str) -> tuple[bool, str, str]:
    """Enforce 6-Tool Scope Hygiene + Relative-Path Causality (allow repo-relative `write_file`, reject `/tmp` & `/workspace/`!)."""
    tools = re.findall(r"call:([a-zA-Z0-9_]+)\{", completion_text)
    if not tools:
        return False, "none", "no_tool_call"
    tool_name = tools[0]
    if tool_name in BROKEN_GRAPH_TOOLS or tool_name not in LEAN6_TOOLS:
        return False, tool_name, "disallowed_tool"
    if tool_name == "write_file" and ("/tmp" in completion_text or "repro" in completion_text or "filepath:" not in completion_text):
        return False, tool_name, "write_file_tmp_traversal_filtered"
    if "/workspace/" in completion_text:
        return False, tool_name, "hardcoded_workspace_prefix_filtered"
    if tool_name in ("read_file", "edit_file") and "filepath:" not in completion_text:
        return False, tool_name, "missing_filepath_arg"
    if tool_name == "run_command" and re.search(r"pytest\s*(?:\.|<\|\"\|>)\s*$", completion_text):
        return False, tool_name, "bare_pytest"

    if tool_name == "edit_file":
        parts = completion_text.split("old_string:")
        if len(parts) < 2:
            return False, tool_name, "malformed_edit"
        old_seg = parts[1].split("new_string:")[0]
        old_lines = [
            ln.strip()
     
```

---
## Step 4: Surgical Top-12 Upper-Layer Action-Head QAT LoRA (`Layers 48..59`, `q_proj` + `o_proj` = `24` Modules / `48` Tensors, `Scale = 0.25`)
**EN**: Why did V11's `300`-module (`600`-tensor) LoRA cause a `35%` vLLM Punica slowdown (`14.7h > 12h`), and how does V17 optimize LoRA?
- **Architectural Sparsity Breakthrough (`600` Tensors $\to$ `48` Tensors, `-92%` Punica Kernel Launches!)**:
  - In `60`-layer `Gemma 4 31B`, lower and middle layers (`0..47`) encode general Python syntax and repository semantics, whereas the **Top-12 Upper Decision Layers (`layers 48..59`, top `20%`)** directly govern tool-call formatting (`<|tool_call>`) and stopping decisions (`submit_patch`).
  - V17 freezes layers `0..47` (`0` adapter overhead!) and applies surgical QAT LoRA exclusively to `q_proj` and `o_proj` in `SURGICAL_LAYERS = [48..59]` (`12 layers * 2 = 24 modules = 48 tensors`, `r = 8, lora_alpha = 2 -> scale = 0.25 <= 1.0`), reducing Punica kernel launches by **92%** (`< 2.8%` latency impact) while preserving `>99.99%` logit cosine fidelity!  
**CN**: 第四步对 LoRA 结构进行外科手术式升级：冻结底层 `0..47` 通用语法表征层，仅在顶层决策区 **`Layers 48..59` 的 `q_proj` 与 `o_proj`（共 `24` 个模块 / `48` 个张量，较旧版 `600` 张量减少 `92%` 算子开销！）** 进行精准动作头校准（`r=8, alpha=2, scale=0.25 <= 1.0`），并保持主进程 `0 MiB` 显存占用以确保 Step 6 的 `VllmServer (tp=4)` 独占全部 `88.1 GiB` 显存满速运行！


---

```python
# ==============================================================================
# Step 4: Surgical Top-12 Upper-Layer Action-Head QAT LoRA (24 Modules / 48 Tensors)
# 第四步：顶层 12 层（Layers 48..59）q_proj/o_proj 外科手术式 QAT LoRA 校准（算子开销降低 92%）
# ==============================================================================
try:
    from safetensors import safe_open
    from safetensors.torch import save_file as save_safetensors
    HAS_SAFETENSORS = True
except ImportError:
    safe_open = None
    save_safetensors = None
    HAS_SAFETENSORS = False

QAT_DIR = Path(MODEL_INFO["qat_path"])
HF_TRAIN_DIR = Path(MODEL_INFO["hf_train_path"])

if not QAT_DIR.exists() and IS_KAGGLE:
    cands = sorted(Path("/kaggle/input").rglob(f"*{MODEL_VARIANT}*w4a16*"))
    if cands:
        QAT_DIR = cands[-1]

NUM_TOTAL_LAYERS = int(MODEL_INFO["layers"])
SURGICAL_TOP_K = min(12, NUM_TOTAL_LAYERS)
SURGICAL_LAYERS = list(range(NUM_TOTAL_LAYERS - SURGICAL_TOP_K, NUM_TOTAL_LAYERS))  # [48..59] for 60-layer 31B
SURGICAL_LAYER_SET = set(SURGICAL_LAYERS)
TARGET_MODULES = ["q_proj", "o_proj"]  # Surgical Action-Head Attention Projections (24 modules = 48 tensors!)
LORA_R = 8
LORA_ALPHA = 2          # [EN] Sub-unit scale = 2/8 = 0.25 <= 1.0 (0 warnings in check_submission.py!)
LORA_DROPOUT = 0.0
TOOL_CALL_WEIGHT = 1.5

MAX_SAFE_ATTN_NORM = 2.4e-5
MAX_SAFE_MLP_NORM = 3.0e-5

qat_layer_shapes = {}
qat_safetensors_files = sorted(QAT_DIR.glob("*.safetensors")) if QAT_DIR.exists() else []

if qat_safetensors_files and HAS_SAFETENSORS:
    shape_pat = re.compile(
        r"^(model(?:\.language_model)?\.layers\.(\d+)\.self_attn\.(q_proj|o_proj))\.weight_shape$"
    )
    for sf_path in qat_safetensors_files:
        with safe_open(str(sf_path), framework="pt", device="cpu") as f:
            for key in f.keys():
                m = shape_pat.match(key)
                if m and int(m.group(2)) in SURGICAL_LAYER_SET:
                    mod_path = m.group(1)
                    dims = f.get_tensor(key).tolist()
                    qat_layer_shapes[mod_path] = (int(dims[0]), int(dims[1]))
    print(f"[OK] Discovered {len(qat_layer_shapes)} surgical Top-{SURGICAL_TOP_K} projections (layers {SURGICAL_LAYERS[0]}..{SURGICAL_LAYERS[-1]}) from: {QAT_DIR}")
else:
    h_dim = MODEL_INFO["hidden_size"]
    q_out = MODEL_INFO["q_out"]
    for layer_idx in SURGICAL_LAYERS:
        qat_layer_shapes[f"model.language_model.layers.{layer_idx}.self_attn.q_proj"] = (q_out, h_dim)
        qat_layer_shapes[f"model.la
```

---
## Step 5: Export Surgical Top-12 PEFT Adapter (`surgical_top12_lora_adapter`) & Verify Trust-Region Bounds
**EN**: We serialize `adapter_model.safetensors` and `adapter_config.json` (`layers_to_transform = [48..59]`, `target_modules = ["o_proj", "q_proj"]`, `r = 8`, `lora_alpha = 2`, `scale = 0.25 <= 1.0`) and verify every single one of the `24` surgical modules (`48` tensors):
1. **Zero perturbation on layers `0..47`** (`48` lower/middle layers remain `100%` bit-exact with `gemma-4-31b-it-qat-w4a16-ct`);
2. **Compliant sub-unit nominal scale** $\alpha / r = 2 / 8 = 0.25 \le 1.0$ (zero `check_submission.py` warnings);
3. **92% fewer Punica kernel launches** (`24` vs `300` modules), saving `~3.9 hours` over 120 tasks if attached in `agent.yaml` while preserving `>99.999%` logit cosine fidelity (`||dW||_F <= 5.0e-6`).  
**CN**: 第五步导出 V17 **顶层 12 层手术级 PEFT 适配器**（`48` 个 BF16 张量、`24` 个 `q_proj/o_proj` 投影，`layers_to_transform=[48..59]`，$\alpha/r = 0.25 \le 1.0$），验证第 `0..47` 层零扰动且全部顶层张量严格满足信赖域上界。


---

```python
# ==============================================================================
# Step 5: Export V17 Surgical Top-12 PEFT Adapter & Audit Layerwise Norms
# 第五步：导出 V17 顶层 12 层手术级 PEFT SafeTensors 适配器并审计逐层范数分布
# ==============================================================================
STAGING_DIR = TMP_BUILD_DIR / "sample_submission"
if STAGING_DIR.exists():
    shutil.rmtree(STAGING_DIR)
(STAGING_DIR / "configs").mkdir(parents=True, exist_ok=True)
(STAGING_DIR / "prompts").mkdir(parents=True, exist_ok=True)
(STAGING_DIR / "agent.yaml").write_text(AGENT_CONFIG_YAML, encoding="utf-8", newline="\n")
(STAGING_DIR / "eval_config.yaml").write_text(EVAL_CONFIG_YAML, encoding="utf-8", newline="\n")
(STAGING_DIR / "configs" / "sampling.yaml").write_text(SAMPLING_CONFIG_YAML, encoding="utf-8", newline="\n")
(STAGING_DIR / "prompts" / "system.md").write_text(SYSTEM_PROMPT_MD, encoding="utf-8", newline="\n")

ADAPTER_OUT_DIR = WORKING_DIR / "surgical_top12_lora_adapter"
ADAPTER_OUT_DIR.mkdir(parents=True, exist_ok=True)

import struct

adapter_config_dict = {
    "alpha_pattern": {},
    "auto_mapping": None,
    "base_model_name_or_path": f"google/{TARGET_MODEL}",
    "bias": "none",
    "fan_in_fan_out": False,
    "inference_mode": True,
    "init_lora_weights": True,
    "layer_replication": None,
    "layers_pattern": "layers",
    "layers_to_transform": SURGICAL_LAYERS,
    "loftq_config": {},
    "lora_alpha": LORA_ALPHA,
    "lora_dropout": LORA_DROPOUT,
    "megatron_config": None,
    "megatron_core": "megatron.core",
    "modules_to_save": None,
    "peft_type": "LORA",
    "r": LORA_R,
    "rank_pattern": {},
    "revision": None,
    "target_modules": sorted(TARGET_MODULES),
    "task_type": "CAUSAL_LM",
    "use_dora": False,
    "use_rslora": False,
}

adapter_cfg_path = ADAPTER_OUT_DIR / "adapter_config.json"
adapter_cfg_path.write_text(json.dumps(adapter_config_dict, indent=2) + "\n", encoding="utf-8")

safetensors_path = ADAPTER_OUT_DIR / "adapter_model.safetensors"
nom_scale = float(LORA_ALPHA) / float(LORA_R)
layer_proj_norms = {l_i: {p: 0.0 for p in TARGET_MODULES} for l_i in range(NUM_TOTAL_LAYERS)}
proj_summary = defaultdict(list)

if HAS_TORCH and HAS_SAFETENSORS:
    save_safetensors(trained_lora_state, str(safetensors_path))
    with safe_open(str(safetensors_path), framework="pt", device="cpu") as f:
        st_keys = sorted(f.keys())
        assert len(st_keys) == len(qat_layer_shapes) * 2, f"Expected {len(qat_layer_shapes)*2} keys, go
```

---
## Step 6: Live ~5.5-Hour `4x NVIDIA L4` 60-Task Benchmark (`30 Public + 30 Private`), 3-Generation Teaching Scoreboard & Inline Visual Dashboards
**EN**: Building on V17's live `4x-L4` benchmark (`18/60 = 30.0%`), V21 upgrades Step 6 (`compaction_interval=5` official parity + `inline_snapshot.Snapshot` shim) along four teaching & forensic axes:
1. **Official Competition Rerun Fast-Path (`IS_COMPETITION_RERUN == True`)**: Immediately skips local 60-task execution (`< 0.1s`) so the hidden 120-task competition harness receives `99.98%` of the 12-hour budget.
2. **True ~5.5-Hour Live `4x-L4` Evaluation (`IS_COMPETITION_RERUN == False`)**: Boots official `adk_submission.VllmServer (tp=4, max_model_len=32768)` + `swegemma.evaluate.Evaluator` (`7.5m / 36 calls / 80 turns / 240s`, `compaction_interval=5`) across **`30 Public Split (Tasks 01..30) + 30 Private Split (Tasks 31..60) = 60` real SWE repositories** (`Textualize/rich`, `fastapi/fastapi`, `psf/requests`), mirroring Kaggle's hidden `60 Public + 60 Private = 120` split.
3. **Unambiguous 3-Table Teaching Output (`V16 -> V17 -> V18` Forensic Progression)**:
   - **Table 1 — Single-Truth V21 60-Task Scoreboard**: Every task's live `PASS (1)` / `FAIL (0)`, `AP-BSSR v3 State`, `Turns`, `1stEdit Turn`, `Patch Bytes`, `Time (s)`, and `Shared Time Bank (m)`, with explicit `PUBLIC_30`, `PRIVATE_30`, and `OVERALL_60` subtotals.
   - **Table 2 — 3-Generation Forensic Diagnostic Comparison (`V16 Live [17/60]` vs. `V17 Live [18/60]` vs. `V21 Live`)**: Directly verifies the elimination of V17's `52` `FileWriteError`s, `25` `BudgetExceeded` kills, `3` `TimeoutExceeded` hangs, and `15` empty patches!
   - **Table 3 — Standalone Historical & 187-Notebook Public Leaderboard Census Reference**: Separately contextualizes `Unedited (0.00)`, `V9 (0.13)`, `flexonafft 8-run LB mean (0.150)`, `V16 LB (0.15)`, `Budget-Fit 10-run LB mean (0.172, peak 0.22)`, `honghanhhh (0.24)`, `V17 Live (0.300)`, and `V21 Live`.
4. **Two High-DPI Inline Visual Teaching Dashboards (`IPython.display.display`)**:
   - `/kaggle/working/v18_teaching_evaluation_dashboard.png` (**8-Panel 3-Generation Teaching Scoreboard & Telemetry Dashboard**, including a `2 x 30` `Public vs Private` visual task matrix!).
   - `/kaggle/working/lora_training_diagnostics.png` (**4-Panel Surgical Top-12 LoRA & `AP-BSSR v3` Anti-Shakeup Dashboard**).  
**CN**: 第六步在交互式 Kaggle `4x NVIDIA L4` 环境下启动官方 `VllmServer (tp=4)` 与 `Evaluator`（`7.5m / 36 calls / 80 turns / 240s`，同步对齐官方 `compaction_interval=5` 与 `inline_snapshot.Snapshot` 补丁），完整运行约 **5~6 小时**的 **`30 Public + 30 Private = 60` 题真实评测**（正式交卷重跑时 `<0.1s` 秒级跳过），输出 **V18 单真值主计分表 + `V16 -> V17 -> V18` 三代取证对比表 + 187 公开 Notebook 排行榜独立参照表**，并内联展示 **8 联教学总览大图 + 4 联手术级 LoRA 与防 Shake-up 诊断图**！


---

```python
# ==============================================================================
# Step 6: Live 4x-L4 GPU 60-Problem Multi-Turn SWE Agent Verification & Full Trajectory Logging
# 第六步：基于 Kaggle 4x NVIDIA L4 算力的 60 题实时多轮推理/工具执行完整验证、全轨迹日志记录与 6 联可视化看板
# ==============================================================================
import csv
import tempfile

SWE60_BENCH_DIR = (Path("/tmp/swe_60_bench") if IS_KAGGLE else (Path(tempfile.gettempdir()) / "swe_60_bench")).resolve()
if SWE60_BENCH_DIR.exists():
    shutil.rmtree(SWE60_BENCH_DIR, ignore_errors=True)
SWE60_BENCH_DIR.mkdir(parents=True, exist_ok=True)

ROWS_60_COMPACT = [
  [
    1,
    "ASFHyP3__hyp3-sdk-53",
    "asfhyp3/hyp3-sdk",
    "TIER_1_FAST_DONOR",
    1,
    1,
    1,
    1,
    "STATE1_SURPLUS_DONOR",
    10,
    2105,
    217.8,
    1.0,
    0.0,
    1.0
  ],
  [
    2,
    "asottile__yesqa-44",
    "asottile/yesqa",
    "TIER_3_SYMMETRY_BREAKING_CONTENDER",
    0,
    0,
    0,
    0,
    "STATE2_SYMMETRY_BROKEN_FAST_YIELD",
    11,
    2452,
    289.5,
    0.5667,
    0.504,
    0.0
  ],
  [
    3,
    "ivankorobkov__python-inject-66",
    "ivankorobkov/python-inject",
    "TIER_3_SYMMETRY_BREAKING_CONTENDER",
    0,
    0,
    0,
    0,
    "STATE2_SYMMETRY_BROKEN_FAST_YIELD",
    11,
    1491,
    291.5,
    0.5,
    0.5085,
    0.0
  ],
  [
    4,
    "KIT-IAI__pyWATTS-194",
    "kit-iai/pywatts",
    "TIER_1_FAST_DONOR",
    1,
    1,
    1,
    1,
    "STATE1_SURPLUS_DONOR",
    9,
    1445,
    220.8,
    1.0,
    0.0,
    1.0
  ],
  [
    5,
    "crossgl__crosstl-95",
    "crossgl/crosstl",
    "TIER_3_SYMMETRY_BREAKING_CONTENDER",
    0,
    0,
    0,
    0,
    "STATE2_SYMMETRY_BROKEN_FAST_YIELD",
    11,
    1684,
    285.5,
    0.5,
    0.5085,
    0.0
  ],
  [
    6,
    "joshtemple__lkml-97",
    "joshtemple/lkml",
    "TIER_3_SYMMETRY_BREAKING_CONTENDER",
    0,
    0,
    0,
    0,
    "STATE2_SYMMETRY_BROKEN_FAST_YIELD",
    8,
    5173,
    280.0,
    0.4,
    0.4983,
    0.4
  ],
  [
    7,
    "EltonChou__EorzeaEnv-15",
    "eltonchou/eorzeaenv",
    "TIER_1_FAST_DONOR",
    1,
    1,
    1,
    1,
    "STATE1_SURPLUS_DONOR",
    11,
    3119,
    222.0,
    1.0,
    0.0,
    1.0
  ],
  [
    8,
    "pycqa__pyflakes-448",
    "pycqa/pyflakes",
    "TIER_4_HARD_UNSOLVED_OR_TRAP",
    0,
    0,
    0,
    0,
    "STATE3B_RATCHET_ROLLBACK_GUARD",
    14,
    3425,
    357.3,
    0.0,
    0.0,
    0.0
  ],
  [
    9,
    "python-markdown__markdown-1303",
    "python-markdo
```


[CAP]